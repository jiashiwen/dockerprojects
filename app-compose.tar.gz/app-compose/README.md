### 构建镜像
请在root用户下执行buildimages.sh

### 启动容器
root用户下执行docker-compose up
