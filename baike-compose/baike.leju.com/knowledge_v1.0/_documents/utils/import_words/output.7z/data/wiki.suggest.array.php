<php
return array (
  0 => 
  array (
    '_id' => '房产类型',
    'word' => '房产类型',
    'hits' => 0,
    'score' => 0,
  ),
  1 => 
  array (
    '_id' => '房产税',
    'word' => '房产税',
    'hits' => 0,
    'score' => 0,
  ),
  2 => 
  array (
    '_id' => '房产证',
    'word' => '房产证',
    'hits' => 0,
    'score' => 0,
  ),
  3 => 
  array (
    '_id' => '房产证抵押',
    'word' => '房产证抵押',
    'hits' => 0,
    'score' => 0,
  ),
  4 => 
  array (
    '_id' => '房产证面积计算',
    'word' => '房产证面积计算',
    'hits' => 0,
    'score' => 0,
  ),
  5 => 
  array (
    '_id' => '房产证期限',
    'word' => '房产证期限',
    'hits' => 0,
    'score' => 0,
  ),
  6 => 
  array (
    '_id' => '房地产税',
    'word' => '房地产税',
    'hits' => 0,
    'score' => 0,
  ),
  7 => 
  array (
    '_id' => '房改房',
    'word' => '房改房',
    'hits' => 0,
    'score' => 0,
  ),
  8 => 
  array (
    '_id' => '公积金',
    'word' => '公积金',
    'hits' => 0,
    'score' => 0,
  ),
  9 => 
  array (
    '_id' => '公积金贷款',
    'word' => '公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  10 => 
  array (
    '_id' => '公积金提取',
    'word' => '公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  11 => 
  array (
    '_id' => '公积金贷款买车',
    'word' => '公积金贷款买车',
    'hits' => 0,
    'score' => 0,
  ),
  12 => 
  array (
    '_id' => '公积金还款',
    'word' => '公积金还款',
    'hits' => 0,
    'score' => 0,
  ),
  13 => 
  array (
    '_id' => '公积金利率',
    'word' => '公积金利率',
    'hits' => 0,
    'score' => 0,
  ),
  14 => 
  array (
    '_id' => '公积金买车',
    'word' => '公积金买车',
    'hits' => 0,
    'score' => 0,
  ),
  15 => 
  array (
    '_id' => '公积金贷款额度计算',
    'word' => '公积金贷款额度计算',
    'hits' => 0,
    'score' => 0,
  ),
  16 => 
  array (
    '_id' => 'CBD',
    'word' => 'CBD',
    'hits' => 0,
    'score' => 0,
  ),
  17 => 
  array (
    '_id' => '阿坝州公积金贷款',
    'word' => '阿坝州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  18 => 
  array (
    '_id' => '阿坝州住房公积金查询',
    'word' => '阿坝州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  19 => 
  array (
    '_id' => '阿坝州住房公积金提取',
    'word' => '阿坝州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  20 => 
  array (
    '_id' => '阿勒泰公积金贷款',
    'word' => '阿勒泰公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  21 => 
  array (
    '_id' => '阿勒泰住房公积金提取',
    'word' => '阿勒泰住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  22 => 
  array (
    '_id' => '安居房',
    'word' => '安居房',
    'hits' => 0,
    'score' => 0,
  ),
  23 => 
  array (
    '_id' => '安康住房公积金查询',
    'word' => '安康住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  24 => 
  array (
    '_id' => '安康住房公积金提取',
    'word' => '安康住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  25 => 
  array (
    '_id' => '安庆公积金贷款',
    'word' => '安庆公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  26 => 
  array (
    '_id' => '安全保安系统',
    'word' => '安全保安系统',
    'hits' => 0,
    'score' => 0,
  ),
  27 => 
  array (
    '_id' => '安全门',
    'word' => '安全门',
    'hits' => 0,
    'score' => 0,
  ),
  28 => 
  array (
    '_id' => '安顺住房公积金查询',
    'word' => '安顺住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  29 => 
  array (
    '_id' => '安阳住房公积金查询',
    'word' => '安阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  30 => 
  array (
    '_id' => '安阳住房公积金提取',
    'word' => '安阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  31 => 
  array (
    '_id' => '安置房',
    'word' => '安置房',
    'hits' => 0,
    'score' => 0,
  ),
  32 => 
  array (
    '_id' => '安置房房产证',
    'word' => '安置房房产证',
    'hits' => 0,
    'score' => 0,
  ),
  33 => 
  array (
    '_id' => '安置房和商品房的区别',
    'word' => '安置房和商品房的区别',
    'hits' => 0,
    'score' => 0,
  ),
  34 => 
  array (
    '_id' => '鞍山公积金贷款',
    'word' => '鞍山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  35 => 
  array (
    '_id' => '鞍山住房公积金查询',
    'word' => '鞍山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  36 => 
  array (
    '_id' => '鞍山住房公积金提取',
    'word' => '鞍山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  37 => 
  array (
    '_id' => '按揭房产证办理',
    'word' => '按揭房产证办理',
    'hits' => 0,
    'score' => 0,
  ),
  38 => 
  array (
    '_id' => '按揭买房',
    'word' => '按揭买房',
    'hits' => 0,
    'score' => 0,
  ),
  39 => 
  array (
    '_id' => '按揭买房首付多少',
    'word' => '按揭买房首付多少',
    'hits' => 0,
    'score' => 0,
  ),
  40 => 
  array (
    '_id' => '按揭买房注意事项',
    'word' => '按揭买房注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  41 => 
  array (
    '_id' => '暗盒',
    'word' => '暗盒',
    'hits' => 0,
    'score' => 0,
  ),
  42 => 
  array (
    '_id' => '暗线安装图',
    'word' => '暗线安装图',
    'hits' => 0,
    'score' => 0,
  ),
  43 => 
  array (
    '_id' => '巴彦淖尔住房公积金提取',
    'word' => '巴彦淖尔住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  44 => 
  array (
    '_id' => '巴中住房公积金提取',
    'word' => '巴中住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  45 => 
  array (
    '_id' => '巴州公积金贷款',
    'word' => '巴州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  46 => 
  array (
    '_id' => '巴州住房公积金查询',
    'word' => '巴州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  47 => 
  array (
    '_id' => '巴州住房公积金提取',
    'word' => '巴州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  48 => 
  array (
    '_id' => '吧台高度',
    'word' => '吧台高度',
    'hits' => 0,
    'score' => 0,
  ),
  49 => 
  array (
    '_id' => '吧台设计',
    'word' => '吧台设计',
    'hits' => 0,
    'score' => 0,
  ),
  50 => 
  array (
    '_id' => '吧台装修效果图',
    'word' => '吧台装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  51 => 
  array (
    '_id' => '把手',
    'word' => '把手',
    'hits' => 0,
    'score' => 0,
  ),
  52 => 
  array (
    '_id' => '白城公积金贷款',
    'word' => '白城公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  53 => 
  array (
    '_id' => '白城住房公积金提取',
    'word' => '白城住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  54 => 
  array (
    '_id' => '白乳胶',
    'word' => '白乳胶',
    'hits' => 0,
    'score' => 0,
  ),
  55 => 
  array (
    '_id' => '白山公积金贷款',
    'word' => '白山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  56 => 
  array (
    '_id' => '白银公积金贷款',
    'word' => '白银公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  57 => 
  array (
    '_id' => '白银住房公积金查询',
    'word' => '白银住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  58 => 
  array (
    '_id' => '百色住房公积金查询',
    'word' => '百色住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  59 => 
  array (
    '_id' => '百叶窗帘',
    'word' => '百叶窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  60 => 
  array (
    '_id' => '百叶门',
    'word' => '百叶门',
    'hits' => 0,
    'score' => 0,
  ),
  61 => 
  array (
    '_id' => '搬家风水',
    'word' => '搬家风水',
    'hits' => 0,
    'score' => 0,
  ),
  62 => 
  array (
    '_id' => '板楼和塔楼哪个好',
    'word' => '板楼和塔楼哪个好',
    'hits' => 0,
    'score' => 0,
  ),
  63 => 
  array (
    '_id' => '板楼与塔楼',
    'word' => '板楼与塔楼',
    'hits' => 0,
    'score' => 0,
  ),
  64 => 
  array (
    '_id' => '板塔结合',
    'word' => '板塔结合',
    'hits' => 0,
    'score' => 0,
  ),
  65 => 
  array (
    '_id' => '办公窗帘',
    'word' => '办公窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  66 => 
  array (
    '_id' => '办公家具',
    'word' => '办公家具',
    'hits' => 0,
    'score' => 0,
  ),
  67 => 
  array (
    '_id' => '办公建筑设计规范',
    'word' => '办公建筑设计规范',
    'hits' => 0,
    'score' => 0,
  ),
  68 => 
  array (
    '_id' => '办公楼设计',
    'word' => '办公楼设计',
    'hits' => 0,
    'score' => 0,
  ),
  69 => 
  array (
    '_id' => '办公室隔断',
    'word' => '办公室隔断',
    'hits' => 0,
    'score' => 0,
  ),
  70 => 
  array (
    '_id' => '办公室手绘效果图',
    'word' => '办公室手绘效果图',
    'hits' => 0,
    'score' => 0,
  ),
  71 => 
  array (
    '_id' => '办公室装饰',
    'word' => '办公室装饰',
    'hits' => 0,
    'score' => 0,
  ),
  72 => 
  array (
    '_id' => '办公室租赁',
    'word' => '办公室租赁',
    'hits' => 0,
    'score' => 0,
  ),
  73 => 
  array (
    '_id' => '办公室租赁合同',
    'word' => '办公室租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  74 => 
  array (
    '_id' => '办理房产证费用',
    'word' => '办理房产证费用',
    'hits' => 0,
    'score' => 0,
  ),
  75 => 
  array (
    '_id' => '办理房产证流程',
    'word' => '办理房产证流程',
    'hits' => 0,
    'score' => 0,
  ),
  76 => 
  array (
    '_id' => '办理土地证手续',
    'word' => '办理土地证手续',
    'hits' => 0,
    'score' => 0,
  ),
  77 => 
  array (
    '_id' => '半地下室',
    'word' => '半地下室',
    'hits' => 0,
    'score' => 0,
  ),
  78 => 
  array (
    '_id' => '蚌埠公积金贷款',
    'word' => '蚌埠公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  79 => 
  array (
    '_id' => '蚌埠住房公积金查询',
    'word' => '蚌埠住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  80 => 
  array (
    '_id' => '包工包料施工合同',
    'word' => '包工包料施工合同',
    'hits' => 0,
    'score' => 0,
  ),
  81 => 
  array (
    '_id' => '包清工合同范本',
    'word' => '包清工合同范本',
    'hits' => 0,
    'score' => 0,
  ),
  82 => 
  array (
    '_id' => '包头住房公积金查询',
    'word' => '包头住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  83 => 
  array (
    '_id' => '包镶梁头',
    'word' => '包镶梁头',
    'hits' => 0,
    'score' => 0,
  ),
  84 => 
  array (
    '_id' => '宝鸡住房公积金查询',
    'word' => '宝鸡住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  85 => 
  array (
    '_id' => '保定住房公积金查询',
    'word' => '保定住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  86 => 
  array (
    '_id' => '保亭住房公积金查询',
    'word' => '保亭住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  87 => 
  array (
    '_id' => '保修期',
    'word' => '保修期',
    'hits' => 0,
    'score' => 0,
  ),
  88 => 
  array (
    '_id' => '保障房',
    'word' => '保障房',
    'hits' => 0,
    'score' => 0,
  ),
  89 => 
  array (
    '_id' => '保障房申请条件',
    'word' => '保障房申请条件',
    'hits' => 0,
    'score' => 0,
  ),
  90 => 
  array (
    '_id' => '保障性住房',
    'word' => '保障性住房',
    'hits' => 0,
    'score' => 0,
  ),
  91 => 
  array (
    '_id' => '北海公积金贷款',
    'word' => '北海公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  92 => 
  array (
    '_id' => '北海住房公积金查询',
    'word' => '北海住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  93 => 
  array (
    '_id' => '北京公积金贷款',
    'word' => '北京公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  94 => 
  array (
    '_id' => '北京豪宅',
    'word' => '北京豪宅',
    'hits' => 0,
    'score' => 0,
  ),
  95 => 
  array (
    '_id' => '北京经济适用房',
    'word' => '北京经济适用房',
    'hits' => 0,
    'score' => 0,
  ),
  96 => 
  array (
    '_id' => '北京廉租房',
    'word' => '北京廉租房',
    'hits' => 0,
    'score' => 0,
  ),
  97 => 
  array (
    '_id' => '北京两限房',
    'word' => '北京两限房',
    'hits' => 0,
    'score' => 0,
  ),
  98 => 
  array (
    '_id' => '北京限购令',
    'word' => '北京限购令',
    'hits' => 0,
    'score' => 0,
  ),
  99 => 
  array (
    '_id' => '北京住房公积金提取',
    'word' => '北京住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  100 => 
  array (
    '_id' => '背景墙',
    'word' => '背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  101 => 
  array (
    '_id' => '背景墙设计',
    'word' => '背景墙设计',
    'hits' => 0,
    'score' => 0,
  ),
  102 => 
  array (
    '_id' => '被拆迁人',
    'word' => '被拆迁人',
    'hits' => 0,
    'score' => 0,
  ),
  103 => 
  array (
    '_id' => '本溪公积金贷款',
    'word' => '本溪公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  104 => 
  array (
    '_id' => '崩盘',
    'word' => '崩盘',
    'hits' => 0,
    'score' => 0,
  ),
  105 => 
  array (
    '_id' => '毕节公积金贷款',
    'word' => '毕节公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  106 => 
  array (
    '_id' => '毕节住房公积金查询',
    'word' => '毕节住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  107 => 
  array (
    '_id' => '毕节住房公积金提取',
    'word' => '毕节住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  108 => 
  array (
    '_id' => '壁灯',
    'word' => '壁灯',
    'hits' => 0,
    'score' => 0,
  ),
  109 => 
  array (
    '_id' => '壁柜',
    'word' => '壁柜',
    'hits' => 0,
    'score' => 0,
  ),
  110 => 
  array (
    '_id' => '壁画',
    'word' => '壁画',
    'hits' => 0,
    'score' => 0,
  ),
  111 => 
  array (
    '_id' => '变形缝',
    'word' => '变形缝',
    'hits' => 0,
    'score' => 0,
  ),
  112 => 
  array (
    '_id' => '标定地价',
    'word' => '标定地价',
    'hits' => 0,
    'score' => 0,
  ),
  113 => 
  array (
    '_id' => '标准层',
    'word' => '标准层',
    'hits' => 0,
    'score' => 0,
  ),
  114 => 
  array (
    '_id' => '别墅风水',
    'word' => '别墅风水',
    'hits' => 0,
    'score' => 0,
  ),
  115 => 
  array (
    '_id' => '别墅花园设计',
    'word' => '别墅花园设计',
    'hits' => 0,
    'score' => 0,
  ),
  116 => 
  array (
    '_id' => '别墅铜门',
    'word' => '别墅铜门',
    'hits' => 0,
    'score' => 0,
  ),
  117 => 
  array (
    '_id' => '别墅装修',
    'word' => '别墅装修',
    'hits' => 0,
    'score' => 0,
  ),
  118 => 
  array (
    '_id' => '别墅装修效果图',
    'word' => '别墅装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  119 => 
  array (
    '_id' => '滨州公积金贷款',
    'word' => '滨州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  120 => 
  array (
    '_id' => '滨州住房公积金查询',
    'word' => '滨州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  121 => 
  array (
    '_id' => '波普风格',
    'word' => '波普风格',
    'hits' => 0,
    'score' => 0,
  ),
  122 => 
  array (
    '_id' => '玻化砖和釉面砖的区别',
    'word' => '玻化砖和釉面砖的区别',
    'hits' => 0,
    'score' => 0,
  ),
  123 => 
  array (
    '_id' => '玻璃门锁',
    'word' => '玻璃门锁',
    'hits' => 0,
    'score' => 0,
  ),
  124 => 
  array (
    '_id' => '玻璃幕墙',
    'word' => '玻璃幕墙',
    'hits' => 0,
    'score' => 0,
  ),
  125 => 
  array (
    '_id' => '玻璃屏风',
    'word' => '玻璃屏风',
    'hits' => 0,
    'score' => 0,
  ),
  126 => 
  array (
    '_id' => '玻璃贴膜',
    'word' => '玻璃贴膜',
    'hits' => 0,
    'score' => 0,
  ),
  127 => 
  array (
    '_id' => '玻璃推拉门',
    'word' => '玻璃推拉门',
    'hits' => 0,
    'score' => 0,
  ),
  128 => 
  array (
    '_id' => '菠萝格木门',
    'word' => '菠萝格木门',
    'hits' => 0,
    'score' => 0,
  ),
  129 => 
  array (
    '_id' => '亳州住房公积金提取',
    'word' => '亳州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  130 => 
  array (
    '_id' => '博州公积金贷款',
    'word' => '博州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  131 => 
  array (
    '_id' => '博州住房公积金查询',
    'word' => '博州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  132 => 
  array (
    '_id' => '补充协议',
    'word' => '补充协议',
    'hits' => 0,
    'score' => 0,
  ),
  133 => 
  array (
    '_id' => '补交金土地出让',
    'word' => '补交金土地出让',
    'hits' => 0,
    'score' => 0,
  ),
  134 => 
  array (
    '_id' => '不动产',
    'word' => '不动产',
    'hits' => 0,
    'score' => 0,
  ),
  135 => 
  array (
    '_id' => '不动产证',
    'word' => '不动产证',
    'hits' => 0,
    'score' => 0,
  ),
  136 => 
  array (
    '_id' => '不交物业费',
    'word' => '不交物业费',
    'hits' => 0,
    'score' => 0,
  ),
  137 => 
  array (
    '_id' => '不满五年二手房税费',
    'word' => '不满五年二手房税费',
    'hits' => 0,
    'score' => 0,
  ),
  138 => 
  array (
    '_id' => '不锈钢防盗窗',
    'word' => '不锈钢防盗窗',
    'hits' => 0,
    'score' => 0,
  ),
  139 => 
  array (
    '_id' => '不锈钢合页',
    'word' => '不锈钢合页',
    'hits' => 0,
    'score' => 0,
  ),
  140 => 
  array (
    '_id' => '不锈钢护栏',
    'word' => '不锈钢护栏',
    'hits' => 0,
    'score' => 0,
  ),
  141 => 
  array (
    '_id' => '不锈钢拉手',
    'word' => '不锈钢拉手',
    'hits' => 0,
    'score' => 0,
  ),
  142 => 
  array (
    '_id' => '不锈钢淋浴房',
    'word' => '不锈钢淋浴房',
    'hits' => 0,
    'score' => 0,
  ),
  143 => 
  array (
    '_id' => '不锈钢水管',
    'word' => '不锈钢水管',
    'hits' => 0,
    'score' => 0,
  ),
  144 => 
  array (
    '_id' => '布衣柜',
    'word' => '布衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  145 => 
  array (
    '_id' => '布衣柜安装方法',
    'word' => '布衣柜安装方法',
    'hits' => 0,
    'score' => 0,
  ),
  146 => 
  array (
    '_id' => '布艺窗帘',
    'word' => '布艺窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  147 => 
  array (
    '_id' => '财神爷摆放位置',
    'word' => '财神爷摆放位置',
    'hits' => 0,
    'score' => 0,
  ),
  148 => 
  array (
    '_id' => '财政政策',
    'word' => '财政政策',
    'hits' => 0,
    'score' => 0,
  ),
  149 => 
  array (
    '_id' => '采光',
    'word' => '采光',
    'hits' => 0,
    'score' => 0,
  ),
  150 => 
  array (
    '_id' => '彩钢瓦',
    'word' => '彩钢瓦',
    'hits' => 0,
    'score' => 0,
  ),
  151 => 
  array (
    '_id' => '彩色混凝土',
    'word' => '彩色混凝土',
    'hits' => 0,
    'score' => 0,
  ),
  152 => 
  array (
    '_id' => '餐厅背景墙',
    'word' => '餐厅背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  153 => 
  array (
    '_id' => '餐厅吊灯',
    'word' => '餐厅吊灯',
    'hits' => 0,
    'score' => 0,
  ),
  154 => 
  array (
    '_id' => '餐厅吊顶',
    'word' => '餐厅吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  155 => 
  array (
    '_id' => '餐厅吊顶装修效果图',
    'word' => '餐厅吊顶装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  156 => 
  array (
    '_id' => '餐厅风水',
    'word' => '餐厅风水',
    'hits' => 0,
    'score' => 0,
  ),
  157 => 
  array (
    '_id' => '餐厅装修',
    'word' => '餐厅装修',
    'hits' => 0,
    'score' => 0,
  ),
  158 => 
  array (
    '_id' => '餐桌布',
    'word' => '餐桌布',
    'hits' => 0,
    'score' => 0,
  ),
  159 => 
  array (
    '_id' => '仓储中心区',
    'word' => '仓储中心区',
    'hits' => 0,
    'score' => 0,
  ),
  160 => 
  array (
    '_id' => '仓库租赁',
    'word' => '仓库租赁',
    'hits' => 0,
    'score' => 0,
  ),
  161 => 
  array (
    '_id' => '沧州公积金贷款',
    'word' => '沧州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  162 => 
  array (
    '_id' => '沧州住房公积金提取',
    'word' => '沧州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  163 => 
  array (
    '_id' => '操纵市场行为',
    'word' => '操纵市场行为',
    'hits' => 0,
    'score' => 0,
  ),
  164 => 
  array (
    '_id' => '层高',
    'word' => '层高',
    'hits' => 0,
    'score' => 0,
  ),
  165 => 
  array (
    '_id' => '茶晶',
    'word' => '茶晶',
    'hits' => 0,
    'score' => 0,
  ),
  166 => 
  array (
    '_id' => '茶具',
    'word' => '茶具',
    'hits' => 0,
    'score' => 0,
  ),
  167 => 
  array (
    '_id' => '茶桌',
    'word' => '茶桌',
    'hits' => 0,
    'score' => 0,
  ),
  168 => 
  array (
    '_id' => '拆迁',
    'word' => '拆迁',
    'hits' => 0,
    'score' => 0,
  ),
  169 => 
  array (
    '_id' => '拆迁安置',
    'word' => '拆迁安置',
    'hits' => 0,
    'score' => 0,
  ),
  170 => 
  array (
    '_id' => '拆迁补偿',
    'word' => '拆迁补偿',
    'hits' => 0,
    'score' => 0,
  ),
  171 => 
  array (
    '_id' => '拆迁律师',
    'word' => '拆迁律师',
    'hits' => 0,
    'score' => 0,
  ),
  172 => 
  array (
    '_id' => '拆迁赔偿',
    'word' => '拆迁赔偿',
    'hits' => 0,
    'score' => 0,
  ),
  173 => 
  array (
    '_id' => '拆迁人',
    'word' => '拆迁人',
    'hits' => 0,
    'score' => 0,
  ),
  174 => 
  array (
    '_id' => '拆迁政策',
    'word' => '拆迁政策',
    'hits' => 0,
    'score' => 0,
  ),
  175 => 
  array (
    '_id' => '产权',
    'word' => '产权',
    'hits' => 0,
    'score' => 0,
  ),
  176 => 
  array (
    '_id' => '产权到期',
    'word' => '产权到期',
    'hits' => 0,
    'score' => 0,
  ),
  177 => 
  array (
    '_id' => '产权房',
    'word' => '产权房',
    'hits' => 0,
    'score' => 0,
  ),
  178 => 
  array (
    '_id' => '产权交易',
    'word' => '产权交易',
    'hits' => 0,
    'score' => 0,
  ),
  179 => 
  array (
    '_id' => '产权年限',
    'word' => '产权年限',
    'hits' => 0,
    'score' => 0,
  ),
  180 => 
  array (
    '_id' => '产权证和房产证',
    'word' => '产权证和房产证',
    'hits' => 0,
    'score' => 0,
  ),
  181 => 
  array (
    '_id' => '产权证明怎么写',
    'word' => '产权证明怎么写',
    'hits' => 0,
    'score' => 0,
  ),
  182 => 
  array (
    '_id' => '产权证书',
    'word' => '产权证书',
    'hits' => 0,
    'score' => 0,
  ),
  183 => 
  array (
    '_id' => '产权置换',
    'word' => '产权置换',
    'hits' => 0,
    'score' => 0,
  ),
  184 => 
  array (
    '_id' => '昌吉公积金贷款',
    'word' => '昌吉公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  185 => 
  array (
    '_id' => '昌吉住房公积金查询',
    'word' => '昌吉住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  186 => 
  array (
    '_id' => '昌吉住房公积金提取',
    'word' => '昌吉住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  187 => 
  array (
    '_id' => '常州公积金贷款',
    'word' => '常州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  188 => 
  array (
    '_id' => '常州住房公积金查询',
    'word' => '常州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  189 => 
  array (
    '_id' => '场地租赁',
    'word' => '场地租赁',
    'hits' => 0,
    'score' => 0,
  ),
  190 => 
  array (
    '_id' => '场地租赁合同',
    'word' => '场地租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  191 => 
  array (
    '_id' => '超薄灯箱',
    'word' => '超薄灯箱',
    'hits' => 0,
    'score' => 0,
  ),
  192 => 
  array (
    '_id' => '超高层',
    'word' => '超高层',
    'hits' => 0,
    'score' => 0,
  ),
  193 => 
  array (
    '_id' => '巢湖公积金贷款',
    'word' => '巢湖公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  194 => 
  array (
    '_id' => '朝阳公积金贷款',
    'word' => '朝阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  195 => 
  array (
    '_id' => '潮州公积金贷款',
    'word' => '潮州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  196 => 
  array (
    '_id' => '炒地皮',
    'word' => '炒地皮',
    'hits' => 0,
    'score' => 0,
  ),
  197 => 
  array (
    '_id' => '郴州公积金贷款',
    'word' => '郴州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  198 => 
  array (
    '_id' => '郴州住房公积金查询',
    'word' => '郴州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  199 => 
  array (
    '_id' => '郴州住房公积金提取',
    'word' => '郴州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  200 => 
  array (
    '_id' => '沉降缝',
    'word' => '沉降缝',
    'hits' => 0,
    'score' => 0,
  ),
  201 => 
  array (
    '_id' => '沉香木',
    'word' => '沉香木',
    'hits' => 0,
    'score' => 0,
  ),
  202 => 
  array (
    '_id' => '成本价',
    'word' => '成本价',
    'hits' => 0,
    'score' => 0,
  ),
  203 => 
  array (
    '_id' => '成本租金',
    'word' => '成本租金',
    'hits' => 0,
    'score' => 0,
  ),
  204 => 
  array (
    '_id' => '成长股',
    'word' => '成长股',
    'hits' => 0,
    'score' => 0,
  ),
  205 => 
  array (
    '_id' => '成都公积金贷款',
    'word' => '成都公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  206 => 
  array (
    '_id' => '成都买房条件',
    'word' => '成都买房条件',
    'hits' => 0,
    'score' => 0,
  ),
  207 => 
  array (
    '_id' => '成都住房公积金提取',
    'word' => '成都住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  208 => 
  array (
    '_id' => '成熟配套',
    'word' => '成熟配套',
    'hits' => 0,
    'score' => 0,
  ),
  209 => 
  array (
    '_id' => '成熟市场',
    'word' => '成熟市场',
    'hits' => 0,
    'score' => 0,
  ),
  210 => 
  array (
    '_id' => '成套住宅',
    'word' => '成套住宅',
    'hits' => 0,
    'score' => 0,
  ),
  211 => 
  array (
    '_id' => '承德公积金贷款',
    'word' => '承德公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  212 => 
  array (
    '_id' => '承重墙',
    'word' => '承重墙',
    'hits' => 0,
    'score' => 0,
  ),
  213 => 
  array (
    '_id' => '诚意金',
    'word' => '诚意金',
    'hits' => 0,
    'score' => 0,
  ),
  214 => 
  array (
    '_id' => '城市建设综合开发',
    'word' => '城市建设综合开发',
    'hits' => 0,
    'score' => 0,
  ),
  215 => 
  array (
    '_id' => '城市住房基金',
    'word' => '城市住房基金',
    'hits' => 0,
    'score' => 0,
  ),
  216 => 
  array (
    '_id' => '城镇土地使用',
    'word' => '城镇土地使用',
    'hits' => 0,
    'score' => 0,
  ),
  217 => 
  array (
    '_id' => '池州住房公积金提取',
    'word' => '池州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  218 => 
  array (
    '_id' => '赤峰住房公积金查询',
    'word' => '赤峰住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  219 => 
  array (
    '_id' => '崇左公积金贷款',
    'word' => '崇左公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  220 => 
  array (
    '_id' => '崇左住房公积金提取',
    'word' => '崇左住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  221 => 
  array (
    '_id' => '抽水马桶',
    'word' => '抽水马桶',
    'hits' => 0,
    'score' => 0,
  ),
  222 => 
  array (
    '_id' => '出货',
    'word' => '出货',
    'hits' => 0,
    'score' => 0,
  ),
  223 => 
  array (
    '_id' => '出租房注意事项',
    'word' => '出租房注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  224 => 
  array (
    '_id' => '初始登记',
    'word' => '初始登记',
    'hits' => 0,
    'score' => 0,
  ),
  225 => 
  array (
    '_id' => '厨房地砖',
    'word' => '厨房地砖',
    'hits' => 0,
    'score' => 0,
  ),
  226 => 
  array (
    '_id' => '厨房门',
    'word' => '厨房门',
    'hits' => 0,
    'score' => 0,
  ),
  227 => 
  array (
    '_id' => '厨房设计',
    'word' => '厨房设计',
    'hits' => 0,
    'score' => 0,
  ),
  228 => 
  array (
    '_id' => '厨房水龙头安装',
    'word' => '厨房水龙头安装',
    'hits' => 0,
    'score' => 0,
  ),
  229 => 
  array (
    '_id' => '厨房推拉门',
    'word' => '厨房推拉门',
    'hits' => 0,
    'score' => 0,
  ),
  230 => 
  array (
    '_id' => '厨房移门',
    'word' => '厨房移门',
    'hits' => 0,
    'score' => 0,
  ),
  231 => 
  array (
    '_id' => '厨房用具',
    'word' => '厨房用具',
    'hits' => 0,
    'score' => 0,
  ),
  232 => 
  array (
    '_id' => '厨房装修',
    'word' => '厨房装修',
    'hits' => 0,
    'score' => 0,
  ),
  233 => 
  array (
    '_id' => '厨房装修风水',
    'word' => '厨房装修风水',
    'hits' => 0,
    'score' => 0,
  ),
  234 => 
  array (
    '_id' => '厨具五大件',
    'word' => '厨具五大件',
    'hits' => 0,
    'score' => 0,
  ),
  235 => 
  array (
    '_id' => '厨卫吊顶',
    'word' => '厨卫吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  236 => 
  array (
    '_id' => '滁州公积金贷款',
    'word' => '滁州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  237 => 
  array (
    '_id' => '滁州住房公积金查询',
    'word' => '滁州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  238 => 
  array (
    '_id' => '滁州住房公积金提取',
    'word' => '滁州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  239 => 
  array (
    '_id' => '橱柜安装方法',
    'word' => '橱柜安装方法',
    'hits' => 0,
    'score' => 0,
  ),
  240 => 
  array (
    '_id' => '橱柜拉篮',
    'word' => '橱柜拉篮',
    'hits' => 0,
    'score' => 0,
  ),
  241 => 
  array (
    '_id' => '楚雄公积金贷款',
    'word' => '楚雄公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  242 => 
  array (
    '_id' => '楚雄住房公积金查询',
    'word' => '楚雄住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  243 => 
  array (
    '_id' => '触摸开关',
    'word' => '触摸开关',
    'hits' => 0,
    'score' => 0,
  ),
  244 => 
  array (
    '_id' => '窗',
    'word' => '窗',
    'hits' => 0,
    'score' => 0,
  ),
  245 => 
  array (
    '_id' => '窗帘布艺',
    'word' => '窗帘布艺',
    'hits' => 0,
    'score' => 0,
  ),
  246 => 
  array (
    '_id' => '窗帘盒',
    'word' => '窗帘盒',
    'hits' => 0,
    'score' => 0,
  ),
  247 => 
  array (
    '_id' => '窗帘价格',
    'word' => '窗帘价格',
    'hits' => 0,
    'score' => 0,
  ),
  248 => 
  array (
    '_id' => '窗帘配件',
    'word' => '窗帘配件',
    'hits' => 0,
    'score' => 0,
  ),
  249 => 
  array (
    '_id' => '床头背景墙',
    'word' => '床头背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  250 => 
  array (
    '_id' => '床头柜',
    'word' => '床头柜',
    'hits' => 0,
    'score' => 0,
  ),
  251 => 
  array (
    '_id' => '创业贷款条件',
    'word' => '创业贷款条件',
    'hits' => 0,
    'score' => 0,
  ),
  252 => 
  array (
    '_id' => '创意灯具',
    'word' => '创意灯具',
    'hits' => 0,
    'score' => 0,
  ),
  253 => 
  array (
    '_id' => '创意家具',
    'word' => '创意家具',
    'hits' => 0,
    'score' => 0,
  ),
  254 => 
  array (
    '_id' => '创意书架',
    'word' => '创意书架',
    'hits' => 0,
    'score' => 0,
  ),
  255 => 
  array (
    '_id' => '瓷砖橱柜',
    'word' => '瓷砖橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  256 => 
  array (
    '_id' => '瓷砖胶',
    'word' => '瓷砖胶',
    'hits' => 0,
    'score' => 0,
  ),
  257 => 
  array (
    '_id' => '存贷款利率',
    'word' => '存贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  258 => 
  array (
    '_id' => '存款利息计算',
    'word' => '存款利息计算',
    'hits' => 0,
    'score' => 0,
  ),
  259 => 
  array (
    '_id' => '存量',
    'word' => '存量',
    'hits' => 0,
    'score' => 0,
  ),
  260 => 
  array (
    '_id' => '存量房',
    'word' => '存量房',
    'hits' => 0,
    'score' => 0,
  ),
  261 => 
  array (
    '_id' => '存托凭证',
    'word' => '存托凭证',
    'hits' => 0,
    'score' => 0,
  ),
  262 => 
  array (
    '_id' => '存续期',
    'word' => '存续期',
    'hits' => 0,
    'score' => 0,
  ),
  263 => 
  array (
    '_id' => '错层',
    'word' => '错层',
    'hits' => 0,
    'score' => 0,
  ),
  264 => 
  array (
    '_id' => '错层式住宅',
    'word' => '错层式住宅',
    'hits' => 0,
    'score' => 0,
  ),
  265 => 
  array (
    '_id' => '达州住房公积金查询',
    'word' => '达州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  266 => 
  array (
    '_id' => '达州住房公积金提取',
    'word' => '达州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  267 => 
  array (
    '_id' => '打压',
    'word' => '打压',
    'hits' => 0,
    'score' => 0,
  ),
  268 => 
  array (
    '_id' => '大产证',
    'word' => '大产证',
    'hits' => 0,
    'score' => 0,
  ),
  269 => 
  array (
    '_id' => '大幅振荡',
    'word' => '大幅振荡',
    'hits' => 0,
    'score' => 0,
  ),
  270 => 
  array (
    '_id' => '大理公积金贷款',
    'word' => '大理公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  271 => 
  array (
    '_id' => '大理石餐桌片',
    'word' => '大理石餐桌片',
    'hits' => 0,
    'score' => 0,
  ),
  272 => 
  array (
    '_id' => '大理石茶几',
    'word' => '大理石茶几',
    'hits' => 0,
    'score' => 0,
  ),
  273 => 
  array (
    '_id' => '大理石瓷砖',
    'word' => '大理石瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  274 => 
  array (
    '_id' => '大理住房公积金查询',
    'word' => '大理住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  275 => 
  array (
    '_id' => '大连公积金贷款',
    'word' => '大连公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  276 => 
  array (
    '_id' => '大连住房公积金查询',
    'word' => '大连住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  277 => 
  array (
    '_id' => '大门风水',
    'word' => '大门风水',
    'hits' => 0,
    'score' => 0,
  ),
  278 => 
  array (
    '_id' => '大庆住房公积金查询',
    'word' => '大庆住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  279 => 
  array (
    '_id' => '大同住房公积金查询',
    'word' => '大同住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  280 => 
  array (
    '_id' => '大同住房公积金提取',
    'word' => '大同住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  281 => 
  array (
    '_id' => '大芯板',
    'word' => '大芯板',
    'hits' => 0,
    'score' => 0,
  ),
  282 => 
  array (
    '_id' => '大兴安岭住房公积金提取',
    'word' => '大兴安岭住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  283 => 
  array (
    '_id' => '大修工程',
    'word' => '大修工程',
    'hits' => 0,
    'score' => 0,
  ),
  284 => 
  array (
    '_id' => '大修基金',
    'word' => '大修基金',
    'hits' => 0,
    'score' => 0,
  ),
  285 => 
  array (
    '_id' => '代理商',
    'word' => '代理商',
    'hits' => 0,
    'score' => 0,
  ),
  286 => 
  array (
    '_id' => '代销',
    'word' => '代销',
    'hits' => 0,
    'score' => 0,
  ),
  287 => 
  array (
    '_id' => '贷款方式',
    'word' => '贷款方式',
    'hits' => 0,
    'score' => 0,
  ),
  288 => 
  array (
    '_id' => '贷款计算',
    'word' => '贷款计算',
    'hits' => 0,
    'score' => 0,
  ),
  289 => 
  array (
    '_id' => '贷款利率',
    'word' => '贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  290 => 
  array (
    '_id' => '贷款利率表',
    'word' => '贷款利率表',
    'hits' => 0,
    'score' => 0,
  ),
  291 => 
  array (
    '_id' => '贷款利率计算',
    'word' => '贷款利率计算',
    'hits' => 0,
    'score' => 0,
  ),
  292 => 
  array (
    '_id' => '贷款买二手房流程',
    'word' => '贷款买二手房流程',
    'hits' => 0,
    'score' => 0,
  ),
  293 => 
  array (
    '_id' => '贷款买房',
    'word' => '贷款买房',
    'hits' => 0,
    'score' => 0,
  ),
  294 => 
  array (
    '_id' => '贷款买房 房产证',
    'word' => '贷款买房 房产证',
    'hits' => 0,
    'score' => 0,
  ),
  295 => 
  array (
    '_id' => '贷款买房流程',
    'word' => '贷款买房流程',
    'hits' => 0,
    'score' => 0,
  ),
  296 => 
  array (
    '_id' => '贷款买房手续',
    'word' => '贷款买房手续',
    'hits' => 0,
    'score' => 0,
  ),
  297 => 
  array (
    '_id' => '贷款买房条件',
    'word' => '贷款买房条件',
    'hits' => 0,
    'score' => 0,
  ),
  298 => 
  array (
    '_id' => '贷款收入证明模板',
    'word' => '贷款收入证明模板',
    'hits' => 0,
    'score' => 0,
  ),
  299 => 
  array (
    '_id' => '贷款手续',
    'word' => '贷款手续',
    'hits' => 0,
    'score' => 0,
  ),
  300 => 
  array (
    '_id' => '贷款提前还款',
    'word' => '贷款提前还款',
    'hits' => 0,
    'score' => 0,
  ),
  301 => 
  array (
    '_id' => '贷款条件',
    'word' => '贷款条件',
    'hits' => 0,
    'score' => 0,
  ),
  302 => 
  array (
    '_id' => '贷款政策和计算',
    'word' => '贷款政策和计算',
    'hits' => 0,
    'score' => 0,
  ),
  303 => 
  array (
    '_id' => '丹东住房公积金查询',
    'word' => '丹东住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  304 => 
  array (
    '_id' => '丹东住房公积金提取',
    'word' => '丹东住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  305 => 
  array (
    '_id' => '单身证明去哪里开',
    'word' => '单身证明去哪里开',
    'hits' => 0,
    'score' => 0,
  ),
  306 => 
  array (
    '_id' => '单位住房基金',
    'word' => '单位住房基金',
    'hits' => 0,
    'score' => 0,
  ),
  307 => 
  array (
    '_id' => '单元式高层住宅',
    'word' => '单元式高层住宅',
    'hits' => 0,
    'score' => 0,
  ),
  308 => 
  array (
    '_id' => '单元式住宅',
    'word' => '单元式住宅',
    'hits' => 0,
    'score' => 0,
  ),
  309 => 
  array (
    '_id' => '儋州住房公积金查询',
    'word' => '儋州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  310 => 
  array (
    '_id' => '弹簧草',
    'word' => '弹簧草',
    'hits' => 0,
    'score' => 0,
  ),
  311 => 
  array (
    '_id' => '道路红线',
    'word' => '道路红线',
    'hits' => 0,
    'score' => 0,
  ),
  312 => 
  array (
    '_id' => '道路用地',
    'word' => '道路用地',
    'hits' => 0,
    'score' => 0,
  ),
  313 => 
  array (
    '_id' => '得房率',
    'word' => '得房率',
    'hits' => 0,
    'score' => 0,
  ),
  314 => 
  array (
    '_id' => '德宏公积金贷款',
    'word' => '德宏公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  315 => 
  array (
    '_id' => '德宏住房公积金查询',
    'word' => '德宏住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  316 => 
  array (
    '_id' => '德宏住房公积金提取',
    'word' => '德宏住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  317 => 
  array (
    '_id' => '德阳住房公积金提取',
    'word' => '德阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  318 => 
  array (
    '_id' => '德州公积金贷款',
    'word' => '德州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  319 => 
  array (
    '_id' => '德州住房公积金查询',
    'word' => '德州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  320 => 
  array (
    '_id' => '灯带',
    'word' => '灯带',
    'hits' => 0,
    'score' => 0,
  ),
  321 => 
  array (
    '_id' => '灯带安装',
    'word' => '灯带安装',
    'hits' => 0,
    'score' => 0,
  ),
  322 => 
  array (
    '_id' => '灯带效果图',
    'word' => '灯带效果图',
    'hits' => 0,
    'score' => 0,
  ),
  323 => 
  array (
    '_id' => '灯带怎么安装',
    'word' => '灯带怎么安装',
    'hits' => 0,
    'score' => 0,
  ),
  324 => 
  array (
    '_id' => '灯具安装方式',
    'word' => '灯具安装方式',
    'hits' => 0,
    'score' => 0,
  ),
  325 => 
  array (
    '_id' => '灯具品牌',
    'word' => '灯具品牌',
    'hits' => 0,
    'score' => 0,
  ),
  326 => 
  array (
    '_id' => '灯具设计',
    'word' => '灯具设计',
    'hits' => 0,
    'score' => 0,
  ),
  327 => 
  array (
    '_id' => '等额本金还款',
    'word' => '等额本金还款',
    'hits' => 0,
    'score' => 0,
  ),
  328 => 
  array (
    '_id' => '等额本息',
    'word' => '等额本息',
    'hits' => 0,
    'score' => 0,
  ),
  329 => 
  array (
    '_id' => '等额本息和等额本金',
    'word' => '等额本息和等额本金',
    'hits' => 0,
    'score' => 0,
  ),
  330 => 
  array (
    '_id' => '等额本息还款',
    'word' => '等额本息还款',
    'hits' => 0,
    'score' => 0,
  ),
  331 => 
  array (
    '_id' => '等额本息还款法',
    'word' => '等额本息还款法',
    'hits' => 0,
    'score' => 0,
  ),
  332 => 
  array (
    '_id' => '低保收入证明',
    'word' => '低保收入证明',
    'hits' => 0,
    'score' => 0,
  ),
  333 => 
  array (
    '_id' => '低层',
    'word' => '低层',
    'hits' => 0,
    'score' => 0,
  ),
  334 => 
  array (
    '_id' => '低层房屋',
    'word' => '低层房屋',
    'hits' => 0,
    'score' => 0,
  ),
  335 => 
  array (
    '_id' => '低层住宅',
    'word' => '低层住宅',
    'hits' => 0,
    'score' => 0,
  ),
  336 => 
  array (
    '_id' => '滴水观音',
    'word' => '滴水观音',
    'hits' => 0,
    'score' => 0,
  ),
  337 => 
  array (
    '_id' => '迪庆公积金贷款',
    'word' => '迪庆公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  338 => 
  array (
    '_id' => '迪庆住房公积金查询',
    'word' => '迪庆住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  339 => 
  array (
    '_id' => '敌意收购',
    'word' => '敌意收购',
    'hits' => 0,
    'score' => 0,
  ),
  340 => 
  array (
    '_id' => '底板',
    'word' => '底板',
    'hits' => 0,
    'score' => 0,
  ),
  341 => 
  array (
    '_id' => '底漆',
    'word' => '底漆',
    'hits' => 0,
    'score' => 0,
  ),
  342 => 
  array (
    '_id' => '底漆和面漆的区别',
    'word' => '底漆和面漆的区别',
    'hits' => 0,
    'score' => 0,
  ),
  343 => 
  array (
    '_id' => '地板革',
    'word' => '地板革',
    'hits' => 0,
    'score' => 0,
  ),
  344 => 
  array (
    '_id' => '地板品牌',
    'word' => '地板品牌',
    'hits' => 0,
    'score' => 0,
  ),
  345 => 
  array (
    '_id' => '地板漆',
    'word' => '地板漆',
    'hits' => 0,
    'score' => 0,
  ),
  346 => 
  array (
    '_id' => '地板砖',
    'word' => '地板砖',
    'hits' => 0,
    'score' => 0,
  ),
  347 => 
  array (
    '_id' => '地板砖品牌',
    'word' => '地板砖品牌',
    'hits' => 0,
    'score' => 0,
  ),
  348 => 
  array (
    '_id' => '地板砖十大品牌',
    'word' => '地板砖十大品牌',
    'hits' => 0,
    'score' => 0,
  ),
  349 => 
  array (
    '_id' => '地产',
    'word' => '地产',
    'hits' => 0,
    'score' => 0,
  ),
  350 => 
  array (
    '_id' => '地产中介',
    'word' => '地产中介',
    'hits' => 0,
    'score' => 0,
  ),
  351 => 
  array (
    '_id' => '地段',
    'word' => '地段',
    'hits' => 0,
    'score' => 0,
  ),
  352 => 
  array (
    '_id' => '地方政府债券',
    'word' => '地方政府债券',
    'hits' => 0,
    'score' => 0,
  ),
  353 => 
  array (
    '_id' => '地籍',
    'word' => '地籍',
    'hits' => 0,
    'score' => 0,
  ),
  354 => 
  array (
    '_id' => '地籍测量',
    'word' => '地籍测量',
    'hits' => 0,
    'score' => 0,
  ),
  355 => 
  array (
    '_id' => '地籍测量图',
    'word' => '地籍测量图',
    'hits' => 0,
    'score' => 0,
  ),
  356 => 
  array (
    '_id' => '地块面积',
    'word' => '地块面积',
    'hits' => 0,
    'score' => 0,
  ),
  357 => 
  array (
    '_id' => '地理风水',
    'word' => '地理风水',
    'hits' => 0,
    'score' => 0,
  ),
  358 => 
  array (
    '_id' => '地漏安装',
    'word' => '地漏安装',
    'hits' => 0,
    'score' => 0,
  ),
  359 => 
  array (
    '_id' => '地面地价',
    'word' => '地面地价',
    'hits' => 0,
    'score' => 0,
  ),
  360 => 
  array (
    '_id' => '地面砖',
    'word' => '地面砖',
    'hits' => 0,
    'score' => 0,
  ),
  361 => 
  array (
    '_id' => '地暖',
    'word' => '地暖',
    'hits' => 0,
    'score' => 0,
  ),
  362 => 
  array (
    '_id' => '地暖安装示意图',
    'word' => '地暖安装示意图',
    'hits' => 0,
    'score' => 0,
  ),
  363 => 
  array (
    '_id' => '地暖打压',
    'word' => '地暖打压',
    'hits' => 0,
    'score' => 0,
  ),
  364 => 
  array (
    '_id' => '地暖地板',
    'word' => '地暖地板',
    'hits' => 0,
    'score' => 0,
  ),
  365 => 
  array (
    '_id' => '地暖管',
    'word' => '地暖管',
    'hits' => 0,
    'score' => 0,
  ),
  366 => 
  array (
    '_id' => '地暖锅炉',
    'word' => '地暖锅炉',
    'hits' => 0,
    'score' => 0,
  ),
  367 => 
  array (
    '_id' => '地暖原理',
    'word' => '地暖原理',
    'hits' => 0,
    'score' => 0,
  ),
  368 => 
  array (
    '_id' => '地坪漆施工',
    'word' => '地坪漆施工',
    'hits' => 0,
    'score' => 0,
  ),
  369 => 
  array (
    '_id' => '地热',
    'word' => '地热',
    'hits' => 0,
    'score' => 0,
  ),
  370 => 
  array (
    '_id' => '地热地板',
    'word' => '地热地板',
    'hits' => 0,
    'score' => 0,
  ),
  371 => 
  array (
    '_id' => '地台装修效果图',
    'word' => '地台装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  372 => 
  array (
    '_id' => '地下室',
    'word' => '地下室',
    'hits' => 0,
    'score' => 0,
  ),
  373 => 
  array (
    '_id' => '地下室设计',
    'word' => '地下室设计',
    'hits' => 0,
    'score' => 0,
  ),
  374 => 
  array (
    '_id' => '地中海风格装修',
    'word' => '地中海风格装修',
    'hits' => 0,
    'score' => 0,
  ),
  375 => 
  array (
    '_id' => '地砖规格',
    'word' => '地砖规格',
    'hits' => 0,
    'score' => 0,
  ),
  376 => 
  array (
    '_id' => '地砖拼花效果图',
    'word' => '地砖拼花效果图',
    'hits' => 0,
    'score' => 0,
  ),
  377 => 
  array (
    '_id' => '地砖品牌',
    'word' => '地砖品牌',
    'hits' => 0,
    'score' => 0,
  ),
  378 => 
  array (
    '_id' => '地砖十大品牌',
    'word' => '地砖十大品牌',
    'hits' => 0,
    'score' => 0,
  ),
  379 => 
  array (
    '_id' => '地砖种类',
    'word' => '地砖种类',
    'hits' => 0,
    'score' => 0,
  ),
  380 => 
  array (
    '_id' => '第二套房产税',
    'word' => '第二套房产税',
    'hits' => 0,
    'score' => 0,
  ),
  381 => 
  array (
    '_id' => '电动百叶窗',
    'word' => '电动百叶窗',
    'hits' => 0,
    'score' => 0,
  ),
  382 => 
  array (
    '_id' => '电动餐桌',
    'word' => '电动餐桌',
    'hits' => 0,
    'score' => 0,
  ),
  383 => 
  array (
    '_id' => '电动窗帘',
    'word' => '电动窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  384 => 
  array (
    '_id' => '电动阀门',
    'word' => '电动阀门',
    'hits' => 0,
    'score' => 0,
  ),
  385 => 
  array (
    '_id' => '电动卷帘门',
    'word' => '电动卷帘门',
    'hits' => 0,
    'score' => 0,
  ),
  386 => 
  array (
    '_id' => '电动晾衣架',
    'word' => '电动晾衣架',
    'hits' => 0,
    'score' => 0,
  ),
  387 => 
  array (
    '_id' => '电动门',
    'word' => '电动门',
    'hits' => 0,
    'score' => 0,
  ),
  388 => 
  array (
    '_id' => '电动伸缩门',
    'word' => '电动伸缩门',
    'hits' => 0,
    'score' => 0,
  ),
  389 => 
  array (
    '_id' => '电加热管',
    'word' => '电加热管',
    'hits' => 0,
    'score' => 0,
  ),
  390 => 
  array (
    '_id' => '电气柜',
    'word' => '电气柜',
    'hits' => 0,
    'score' => 0,
  ),
  391 => 
  array (
    '_id' => '电热膜地暖',
    'word' => '电热膜地暖',
    'hits' => 0,
    'score' => 0,
  ),
  392 => 
  array (
    '_id' => '电热水龙头',
    'word' => '电热水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  393 => 
  array (
    '_id' => '电视背景墙',
    'word' => '电视背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  394 => 
  array (
    '_id' => '电视柜',
    'word' => '电视柜',
    'hits' => 0,
    'score' => 0,
  ),
  395 => 
  array (
    '_id' => '电视柜尺寸样式',
    'word' => '电视柜尺寸样式',
    'hits' => 0,
    'score' => 0,
  ),
  396 => 
  array (
    '_id' => '电视墙装修效果图',
    'word' => '电视墙装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  397 => 
  array (
    '_id' => '电梯保养',
    'word' => '电梯保养',
    'hits' => 0,
    'score' => 0,
  ),
  398 => 
  array (
    '_id' => '电梯大修',
    'word' => '电梯大修',
    'hits' => 0,
    'score' => 0,
  ),
  399 => 
  array (
    '_id' => '电梯改造',
    'word' => '电梯改造',
    'hits' => 0,
    'score' => 0,
  ),
  400 => 
  array (
    '_id' => '电梯更新',
    'word' => '电梯更新',
    'hits' => 0,
    'score' => 0,
  ),
  401 => 
  array (
    '_id' => '电梯门',
    'word' => '电梯门',
    'hits' => 0,
    'score' => 0,
  ),
  402 => 
  array (
    '_id' => '电梯中修',
    'word' => '电梯中修',
    'hits' => 0,
    'score' => 0,
  ),
  403 => 
  array (
    '_id' => '电线管',
    'word' => '电线管',
    'hits' => 0,
    'score' => 0,
  ),
  404 => 
  array (
    '_id' => '电线规格',
    'word' => '电线规格',
    'hits' => 0,
    'score' => 0,
  ),
  405 => 
  array (
    '_id' => '电线品牌',
    'word' => '电线品牌',
    'hits' => 0,
    'score' => 0,
  ),
  406 => 
  array (
    '_id' => '电子灯箱',
    'word' => '电子灯箱',
    'hits' => 0,
    'score' => 0,
  ),
  407 => 
  array (
    '_id' => '店面转让',
    'word' => '店面转让',
    'hits' => 0,
    'score' => 0,
  ),
  408 => 
  array (
    '_id' => '店面装饰',
    'word' => '店面装饰',
    'hits' => 0,
    'score' => 0,
  ),
  409 => 
  array (
    '_id' => '店面租赁合同',
    'word' => '店面租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  410 => 
  array (
    '_id' => '店铺装修',
    'word' => '店铺装修',
    'hits' => 0,
    'score' => 0,
  ),
  411 => 
  array (
    '_id' => '雕花板',
    'word' => '雕花板',
    'hits' => 0,
    'score' => 0,
  ),
  412 => 
  array (
    '_id' => '吊顶灯',
    'word' => '吊顶灯',
    'hits' => 0,
    'score' => 0,
  ),
  413 => 
  array (
    '_id' => '吊顶灯带',
    'word' => '吊顶灯带',
    'hits' => 0,
    'score' => 0,
  ),
  414 => 
  array (
    '_id' => '吊顶效果图',
    'word' => '吊顶效果图',
    'hits' => 0,
    'score' => 0,
  ),
  415 => 
  array (
    '_id' => '吊顶装修效果图',
    'word' => '吊顶装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  416 => 
  array (
    '_id' => '叠加别墅',
    'word' => '叠加别墅',
    'hits' => 0,
    'score' => 0,
  ),
  417 => 
  array (
    '_id' => '叠拼别墅',
    'word' => '叠拼别墅',
    'hits' => 0,
    'score' => 0,
  ),
  418 => 
  array (
    '_id' => '顶固衣柜',
    'word' => '顶固衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  419 => 
  array (
    '_id' => '顶上吊顶',
    'word' => '顶上吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  420 => 
  array (
    '_id' => '鼎美吊顶',
    'word' => '鼎美吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  421 => 
  array (
    '_id' => '订金',
    'word' => '订金',
    'hits' => 0,
    'score' => 0,
  ),
  422 => 
  array (
    '_id' => '定金',
    'word' => '定金',
    'hits' => 0,
    'score' => 0,
  ),
  423 => 
  array (
    '_id' => '定金罚则',
    'word' => '定金罚则',
    'hits' => 0,
    'score' => 0,
  ),
  424 => 
  array (
    '_id' => '定金合同',
    'word' => '定金合同',
    'hits' => 0,
    'score' => 0,
  ),
  425 => 
  array (
    '_id' => '定时插座',
    'word' => '定时插座',
    'hits' => 0,
    'score' => 0,
  ),
  426 => 
  array (
    '_id' => '定时开关',
    'word' => '定时开关',
    'hits' => 0,
    'score' => 0,
  ),
  427 => 
  array (
    '_id' => '定西住房公积金提取',
    'word' => '定西住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  428 => 
  array (
    '_id' => '定制家具',
    'word' => '定制家具',
    'hits' => 0,
    'score' => 0,
  ),
  429 => 
  array (
    '_id' => '东灿集成吊顶',
    'word' => '东灿集成吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  430 => 
  array (
    '_id' => '东方邦太橱柜',
    'word' => '东方邦太橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  431 => 
  array (
    '_id' => '东南亚风格家具',
    'word' => '东南亚风格家具',
    'hits' => 0,
    'score' => 0,
  ),
  432 => 
  array (
    '_id' => '东鹏瓷砖',
    'word' => '东鹏瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  433 => 
  array (
    '_id' => '东鹏卫浴',
    'word' => '东鹏卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  434 => 
  array (
    '_id' => '东升地毯',
    'word' => '东升地毯',
    'hits' => 0,
    'score' => 0,
  ),
  435 => 
  array (
    '_id' => '东莞公积金贷款',
    'word' => '东莞公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  436 => 
  array (
    '_id' => '东莞住房公积金提取',
    'word' => '东莞住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  437 => 
  array (
    '_id' => '东营公积金贷款',
    'word' => '东营公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  438 => 
  array (
    '_id' => '动迁房',
    'word' => '动迁房',
    'hits' => 0,
    'score' => 0,
  ),
  439 => 
  array (
    '_id' => '栋距',
    'word' => '栋距',
    'hits' => 0,
    'score' => 0,
  ),
  440 => 
  array (
    '_id' => '独栋别墅',
    'word' => '独栋别墅',
    'hits' => 0,
    'score' => 0,
  ),
  441 => 
  array (
    '_id' => '杜菲尼卫浴',
    'word' => '杜菲尼卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  442 => 
  array (
    '_id' => '镀锌钢管',
    'word' => '镀锌钢管',
    'hits' => 0,
    'score' => 0,
  ),
  443 => 
  array (
    '_id' => '墩接柱根',
    'word' => '墩接柱根',
    'hits' => 0,
    'score' => 0,
  ),
  444 => 
  array (
    '_id' => '蹲便器',
    'word' => '蹲便器',
    'hits' => 0,
    'score' => 0,
  ),
  445 => 
  array (
    '_id' => '钝化',
    'word' => '钝化',
    'hits' => 0,
    'score' => 0,
  ),
  446 => 
  array (
    '_id' => '多层',
    'word' => '多层',
    'hits' => 0,
    'score' => 0,
  ),
  447 => 
  array (
    '_id' => '多层房屋',
    'word' => '多层房屋',
    'hits' => 0,
    'score' => 0,
  ),
  448 => 
  array (
    '_id' => '多层实木板',
    'word' => '多层实木板',
    'hits' => 0,
    'score' => 0,
  ),
  449 => 
  array (
    '_id' => '多层住宅',
    'word' => '多层住宅',
    'hits' => 0,
    'score' => 0,
  ),
  450 => 
  array (
    '_id' => '多功能沙发床',
    'word' => '多功能沙发床',
    'hits' => 0,
    'score' => 0,
  ),
  451 => 
  array (
    '_id' => '多孔砖',
    'word' => '多孔砖',
    'hits' => 0,
    'score' => 0,
  ),
  452 => 
  array (
    '_id' => '多乐士油漆',
    'word' => '多乐士油漆',
    'hits' => 0,
    'score' => 0,
  ),
  453 => 
  array (
    '_id' => '多灵合页',
    'word' => '多灵合页',
    'hits' => 0,
    'score' => 0,
  ),
  454 => 
  array (
    '_id' => '多喜爱家具',
    'word' => '多喜爱家具',
    'hits' => 0,
    'score' => 0,
  ),
  455 => 
  array (
    '_id' => '刨花板',
    'word' => '刨花板',
    'hits' => 0,
    'score' => 0,
  ),
  456 => 
  array (
    '_id' => '鄂尔多斯公积金贷款',
    'word' => '鄂尔多斯公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  457 => 
  array (
    '_id' => '鄂尔多斯住房公积金查询',
    'word' => '鄂尔多斯住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  458 => 
  array (
    '_id' => '鄂州住房公积金查询',
    'word' => '鄂州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  459 => 
  array (
    '_id' => '鄂州住房公积金提取',
    'word' => '鄂州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  460 => 
  array (
    '_id' => '恩施住房公积金查询',
    'word' => '恩施住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  461 => 
  array (
    '_id' => '恩施住房公积金提取',
    'word' => '恩施住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  462 => 
  array (
    '_id' => '儿童房设计',
    'word' => '儿童房设计',
    'hits' => 0,
    'score' => 0,
  ),
  463 => 
  array (
    '_id' => '儿童家具',
    'word' => '儿童家具',
    'hits' => 0,
    'score' => 0,
  ),
  464 => 
  array (
    '_id' => '儿童书桌',
    'word' => '儿童书桌',
    'hits' => 0,
    'score' => 0,
  ),
  465 => 
  array (
    '_id' => '儿童套房',
    'word' => '儿童套房',
    'hits' => 0,
    'score' => 0,
  ),
  466 => 
  array (
    '_id' => '儿童套房家具',
    'word' => '儿童套房家具',
    'hits' => 0,
    'score' => 0,
  ),
  467 => 
  array (
    '_id' => '儿童衣柜',
    'word' => '儿童衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  468 => 
  array (
    '_id' => '二次供水设施',
    'word' => '二次供水设施',
    'hits' => 0,
    'score' => 0,
  ),
  469 => 
  array (
    '_id' => '二次供水设施大修',
    'word' => '二次供水设施大修',
    'hits' => 0,
    'score' => 0,
  ),
  470 => 
  array (
    '_id' => '二次供水设施改造',
    'word' => '二次供水设施改造',
    'hits' => 0,
    'score' => 0,
  ),
  471 => 
  array (
    '_id' => '二次供水设施更新',
    'word' => '二次供水设施更新',
    'hits' => 0,
    'score' => 0,
  ),
  472 => 
  array (
    '_id' => '二次供水设施维护保养',
    'word' => '二次供水设施维护保养',
    'hits' => 0,
    'score' => 0,
  ),
  473 => 
  array (
    '_id' => '二手房按揭',
    'word' => '二手房按揭',
    'hits' => 0,
    'score' => 0,
  ),
  474 => 
  array (
    '_id' => '二手房贷款',
    'word' => '二手房贷款',
    'hits' => 0,
    'score' => 0,
  ),
  475 => 
  array (
    '_id' => '二手房贷款政策',
    'word' => '二手房贷款政策',
    'hits' => 0,
    'score' => 0,
  ),
  476 => 
  array (
    '_id' => '二手房的交易流程',
    'word' => '二手房的交易流程',
    'hits' => 0,
    'score' => 0,
  ),
  477 => 
  array (
    '_id' => '二手房个人所得税',
    'word' => '二手房个人所得税',
    'hits' => 0,
    'score' => 0,
  ),
  478 => 
  array (
    '_id' => '二手房个税',
    'word' => '二手房个税',
    'hits' => 0,
    'score' => 0,
  ),
  479 => 
  array (
    '_id' => '二手房购房合同',
    'word' => '二手房购房合同',
    'hits' => 0,
    'score' => 0,
  ),
  480 => 
  array (
    '_id' => '二手房过户费',
    'word' => '二手房过户费',
    'hits' => 0,
    'score' => 0,
  ),
  481 => 
  array (
    '_id' => '二手房过户费用',
    'word' => '二手房过户费用',
    'hits' => 0,
    'score' => 0,
  ),
  482 => 
  array (
    '_id' => '二手房过户流程',
    'word' => '二手房过户流程',
    'hits' => 0,
    'score' => 0,
  ),
  483 => 
  array (
    '_id' => '二手房过户注意事项',
    'word' => '二手房过户注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  484 => 
  array (
    '_id' => '二手房合同',
    'word' => '二手房合同',
    'hits' => 0,
    'score' => 0,
  ),
  485 => 
  array (
    '_id' => '二手房交房时注意事项',
    'word' => '二手房交房时注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  486 => 
  array (
    '_id' => '二手房交易费用',
    'word' => '二手房交易费用',
    'hits' => 0,
    'score' => 0,
  ),
  487 => 
  array (
    '_id' => '二手房交易合同范本',
    'word' => '二手房交易合同范本',
    'hits' => 0,
    'score' => 0,
  ),
  488 => 
  array (
    '_id' => '二手房交易流程',
    'word' => '二手房交易流程',
    'hits' => 0,
    'score' => 0,
  ),
  489 => 
  array (
    '_id' => '二手房交易流程表',
    'word' => '二手房交易流程表',
    'hits' => 0,
    'score' => 0,
  ),
  490 => 
  array (
    '_id' => '二手房交易税费',
    'word' => '二手房交易税费',
    'hits' => 0,
    'score' => 0,
  ),
  491 => 
  array (
    '_id' => '二手房交易注意事项',
    'word' => '二手房交易注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  492 => 
  array (
    '_id' => '二手房买卖',
    'word' => '二手房买卖',
    'hits' => 0,
    'score' => 0,
  ),
  493 => 
  array (
    '_id' => '二手房买卖流程',
    'word' => '二手房买卖流程',
    'hits' => 0,
    'score' => 0,
  ),
  494 => 
  array (
    '_id' => '二手房评估价',
    'word' => '二手房评估价',
    'hits' => 0,
    'score' => 0,
  ),
  495 => 
  array (
    '_id' => '二手房税',
    'word' => '二手房税',
    'hits' => 0,
    'score' => 0,
  ),
  496 => 
  array (
    '_id' => '二手房税费',
    'word' => '二手房税费',
    'hits' => 0,
    'score' => 0,
  ),
  497 => 
  array (
    '_id' => '二手房屋买卖合同',
    'word' => '二手房屋买卖合同',
    'hits' => 0,
    'score' => 0,
  ),
  498 => 
  array (
    '_id' => '二手房销售',
    'word' => '二手房销售',
    'hits' => 0,
    'score' => 0,
  ),
  499 => 
  array (
    '_id' => '二手房银行贷款',
    'word' => '二手房银行贷款',
    'hits' => 0,
    'score' => 0,
  ),
  500 => 
  array (
    '_id' => '二手房营业税怎么算',
    'word' => '二手房营业税怎么算',
    'hits' => 0,
    'score' => 0,
  ),
  501 => 
  array (
    '_id' => '二手房中介',
    'word' => '二手房中介',
    'hits' => 0,
    'score' => 0,
  ),
  502 => 
  array (
    '_id' => '二手房中介费',
    'word' => '二手房中介费',
    'hits' => 0,
    'score' => 0,
  ),
  503 => 
  array (
    '_id' => '二手房中介费用',
    'word' => '二手房中介费用',
    'hits' => 0,
    'score' => 0,
  ),
  504 => 
  array (
    '_id' => '二手房中介交易流程',
    'word' => '二手房中介交易流程',
    'hits' => 0,
    'score' => 0,
  ),
  505 => 
  array (
    '_id' => '二手房注意事项',
    'word' => '二手房注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  506 => 
  array (
    '_id' => '二手楼',
    'word' => '二手楼',
    'hits' => 0,
    'score' => 0,
  ),
  507 => 
  array (
    '_id' => '二套房',
    'word' => '二套房',
    'hits' => 0,
    'score' => 0,
  ),
  508 => 
  array (
    '_id' => '二套房贷款',
    'word' => '二套房贷款',
    'hits' => 0,
    'score' => 0,
  ),
  509 => 
  array (
    '_id' => '二套房贷款基准利率',
    'word' => '二套房贷款基准利率',
    'hits' => 0,
    'score' => 0,
  ),
  510 => 
  array (
    '_id' => '二套房公积金贷款',
    'word' => '二套房公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  511 => 
  array (
    '_id' => '二套房公积金贷款政策',
    'word' => '二套房公积金贷款政策',
    'hits' => 0,
    'score' => 0,
  ),
  512 => 
  array (
    '_id' => '二套房契税',
    'word' => '二套房契税',
    'hits' => 0,
    'score' => 0,
  ),
  513 => 
  array (
    '_id' => '二套房首付比例',
    'word' => '二套房首付比例',
    'hits' => 0,
    'score' => 0,
  ),
  514 => 
  array (
    '_id' => '二套房政策',
    'word' => '二套房政策',
    'hits' => 0,
    'score' => 0,
  ),
  515 => 
  array (
    '_id' => '发展商',
    'word' => '发展商',
    'hits' => 0,
    'score' => 0,
  ),
  516 => 
  array (
    '_id' => '阀门品牌',
    'word' => '阀门品牌',
    'hits' => 0,
    'score' => 0,
  ),
  517 => 
  array (
    '_id' => '法恩莎浴缸',
    'word' => '法恩莎浴缸',
    'hits' => 0,
    'score' => 0,
  ),
  518 => 
  array (
    '_id' => '法拉第橱柜',
    'word' => '法拉第橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  519 => 
  array (
    '_id' => '法式风格',
    'word' => '法式风格',
    'hits' => 0,
    'score' => 0,
  ),
  520 => 
  array (
    '_id' => '法式家具',
    'word' => '法式家具',
    'hits' => 0,
    'score' => 0,
  ),
  521 => 
  array (
    '_id' => '翻修工程',
    'word' => '翻修工程',
    'hits' => 0,
    'score' => 0,
  ),
  522 => 
  array (
    '_id' => '反光材料',
    'word' => '反光材料',
    'hits' => 0,
    'score' => 0,
  ),
  523 => 
  array (
    '_id' => '方太橱柜',
    'word' => '方太橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  524 => 
  array (
    '_id' => '防盗报警器',
    'word' => '防盗报警器',
    'hits' => 0,
    'score' => 0,
  ),
  525 => 
  array (
    '_id' => '防盗窗',
    'word' => '防盗窗',
    'hits' => 0,
    'score' => 0,
  ),
  526 => 
  array (
    '_id' => '防盗门',
    'word' => '防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  527 => 
  array (
    '_id' => '防盗门安装',
    'word' => '防盗门安装',
    'hits' => 0,
    'score' => 0,
  ),
  528 => 
  array (
    '_id' => '防盗门安装方法',
    'word' => '防盗门安装方法',
    'hits' => 0,
    'score' => 0,
  ),
  529 => 
  array (
    '_id' => '防盗门锁',
    'word' => '防盗门锁',
    'hits' => 0,
    'score' => 0,
  ),
  530 => 
  array (
    '_id' => '防盗纱窗',
    'word' => '防盗纱窗',
    'hits' => 0,
    'score' => 0,
  ),
  531 => 
  array (
    '_id' => '防腐木地板',
    'word' => '防腐木地板',
    'hits' => 0,
    'score' => 0,
  ),
  532 => 
  array (
    '_id' => '防腐漆',
    'word' => '防腐漆',
    'hits' => 0,
    'score' => 0,
  ),
  533 => 
  array (
    '_id' => '防腐涂料',
    'word' => '防腐涂料',
    'hits' => 0,
    'score' => 0,
  ),
  534 => 
  array (
    '_id' => '防火板',
    'word' => '防火板',
    'hits' => 0,
    'score' => 0,
  ),
  535 => 
  array (
    '_id' => '防火材料',
    'word' => '防火材料',
    'hits' => 0,
    'score' => 0,
  ),
  536 => 
  array (
    '_id' => '防火窗',
    'word' => '防火窗',
    'hits' => 0,
    'score' => 0,
  ),
  537 => 
  array (
    '_id' => '防火卷帘',
    'word' => '防火卷帘',
    'hits' => 0,
    'score' => 0,
  ),
  538 => 
  array (
    '_id' => '防火卷帘门',
    'word' => '防火卷帘门',
    'hits' => 0,
    'score' => 0,
  ),
  539 => 
  array (
    '_id' => '防霉涂料',
    'word' => '防霉涂料',
    'hits' => 0,
    'score' => 0,
  ),
  540 => 
  array (
    '_id' => '防水涂料',
    'word' => '防水涂料',
    'hits' => 0,
    'score' => 0,
  ),
  541 => 
  array (
    '_id' => '防震缝',
    'word' => '防震缝',
    'hits' => 0,
    'score' => 0,
  ),
  542 => 
  array (
    '_id' => '房产',
    'word' => '房产',
    'hits' => 0,
    'score' => 0,
  ),
  543 => 
  array (
    '_id' => '房产登记管理办法',
    'word' => '房产登记管理办法',
    'hits' => 0,
    'score' => 0,
  ),
  544 => 
  array (
    '_id' => '房产抵押贷款',
    'word' => '房产抵押贷款',
    'hits' => 0,
    'score' => 0,
  ),
  545 => 
  array (
    '_id' => '房产抵押合同',
    'word' => '房产抵押合同',
    'hits' => 0,
    'score' => 0,
  ),
  546 => 
  array (
    '_id' => '房产个税',
    'word' => '房产个税',
    'hits' => 0,
    'score' => 0,
  ),
  547 => 
  array (
    '_id' => '房产公证',
    'word' => '房产公证',
    'hits' => 0,
    'score' => 0,
  ),
  548 => 
  array (
    '_id' => '房产公证书',
    'word' => '房产公证书',
    'hits' => 0,
    'score' => 0,
  ),
  549 => 
  array (
    '_id' => '房产过户费用计算',
    'word' => '房产过户费用计算',
    'hits' => 0,
    'score' => 0,
  ),
  550 => 
  array (
    '_id' => '房产过户流程',
    'word' => '房产过户流程',
    'hits' => 0,
    'score' => 0,
  ),
  551 => 
  array (
    '_id' => '房产交易',
    'word' => '房产交易',
    'hits' => 0,
    'score' => 0,
  ),
  552 => 
  array (
    '_id' => '房产交易税费',
    'word' => '房产交易税费',
    'hits' => 0,
    'score' => 0,
  ),
  553 => 
  array (
    '_id' => '房产纠纷',
    'word' => '房产纠纷',
    'hits' => 0,
    'score' => 0,
  ),
  554 => 
  array (
    '_id' => '房产开发商',
    'word' => '房产开发商',
    'hits' => 0,
    'score' => 0,
  ),
  555 => 
  array (
    '_id' => '房产契税',
    'word' => '房产契税',
    'hits' => 0,
    'score' => 0,
  ),
  556 => 
  array (
    '_id' => '房产税开征最新消息',
    'word' => '房产税开征最新消息',
    'hits' => 0,
    'score' => 0,
  ),
  557 => 
  array (
    '_id' => '房产税试点',
    'word' => '房产税试点',
    'hits' => 0,
    'score' => 0,
  ),
  558 => 
  array (
    '_id' => '房产税条例',
    'word' => '房产税条例',
    'hits' => 0,
    'score' => 0,
  ),
  559 => 
  array (
    '_id' => '房产税怎么交',
    'word' => '房产税怎么交',
    'hits' => 0,
    'score' => 0,
  ),
  560 => 
  array (
    '_id' => '房产信息',
    'word' => '房产信息',
    'hits' => 0,
    'score' => 0,
  ),
  561 => 
  array (
    '_id' => '房产折旧',
    'word' => '房产折旧',
    'hits' => 0,
    'score' => 0,
  ),
  562 => 
  array (
    '_id' => '房产证办理',
    'word' => '房产证办理',
    'hits' => 0,
    'score' => 0,
  ),
  563 => 
  array (
    '_id' => '房产证办理流程',
    'word' => '房产证办理流程',
    'hits' => 0,
    'score' => 0,
  ),
  564 => 
  array (
    '_id' => '房产证抵押贷款',
    'word' => '房产证抵押贷款',
    'hits' => 0,
    'score' => 0,
  ),
  565 => 
  array (
    '_id' => '房产证丢了怎么办',
    'word' => '房产证丢了怎么办',
    'hits' => 0,
    'score' => 0,
  ),
  566 => 
  array (
    '_id' => '房产证改名字',
    'word' => '房产证改名字',
    'hits' => 0,
    'score' => 0,
  ),
  567 => 
  array (
    '_id' => '房产证更名',
    'word' => '房产证更名',
    'hits' => 0,
    'score' => 0,
  ),
  568 => 
  array (
    '_id' => '房产证挂失',
    'word' => '房产证挂失',
    'hits' => 0,
    'score' => 0,
  ),
  569 => 
  array (
    '_id' => '房产证过户费',
    'word' => '房产证过户费',
    'hits' => 0,
    'score' => 0,
  ),
  570 => 
  array (
    '_id' => '房产证加名',
    'word' => '房产证加名',
    'hits' => 0,
    'score' => 0,
  ),
  571 => 
  array (
    '_id' => '房产证减名字',
    'word' => '房产证减名字',
    'hits' => 0,
    'score' => 0,
  ),
  572 => 
  array (
    '_id' => '房产证去名字',
    'word' => '房产证去名字',
    'hits' => 0,
    'score' => 0,
  ),
  573 => 
  array (
    '_id' => '房产证如何办理',
    'word' => '房产证如何办理',
    'hits' => 0,
    'score' => 0,
  ),
  574 => 
  array (
    '_id' => '房产证上加名字',
    'word' => '房产证上加名字',
    'hits' => 0,
    'score' => 0,
  ),
  575 => 
  array (
    '_id' => '房产证上加名字流程',
    'word' => '房产证上加名字流程',
    'hits' => 0,
    'score' => 0,
  ),
  576 => 
  array (
    '_id' => '房产证上加配偶名字',
    'word' => '房产证上加配偶名字',
    'hits' => 0,
    'score' => 0,
  ),
  577 => 
  array (
    '_id' => '房产证土地证',
    'word' => '房产证土地证',
    'hits' => 0,
    'score' => 0,
  ),
  578 => 
  array (
    '_id' => '房产证样本',
    'word' => '房产证样本',
    'hits' => 0,
    'score' => 0,
  ),
  579 => 
  array (
    '_id' => '房产中介',
    'word' => '房产中介',
    'hits' => 0,
    'score' => 0,
  ),
  580 => 
  array (
    '_id' => '房产中介费',
    'word' => '房产中介费',
    'hits' => 0,
    'score' => 0,
  ),
  581 => 
  array (
    '_id' => '房产中介好做',
    'word' => '房产中介好做',
    'hits' => 0,
    'score' => 0,
  ),
  582 => 
  array (
    '_id' => '房贷担保',
    'word' => '房贷担保',
    'hits' => 0,
    'score' => 0,
  ),
  583 => 
  array (
    '_id' => '房贷还款方式',
    'word' => '房贷还款方式',
    'hits' => 0,
    'score' => 0,
  ),
  584 => 
  array (
    '_id' => '房贷还清',
    'word' => '房贷还清',
    'hits' => 0,
    'score' => 0,
  ),
  585 => 
  array (
    '_id' => '房贷利率计算',
    'word' => '房贷利率计算',
    'hits' => 0,
    'score' => 0,
  ),
  586 => 
  array (
    '_id' => '房贷利率是多少',
    'word' => '房贷利率是多少',
    'hits' => 0,
    'score' => 0,
  ),
  587 => 
  array (
    '_id' => '房贷流程',
    'word' => '房贷流程',
    'hits' => 0,
    'score' => 0,
  ),
  588 => 
  array (
    '_id' => '房贷收入证明范本',
    'word' => '房贷收入证明范本',
    'hits' => 0,
    'score' => 0,
  ),
  589 => 
  array (
    '_id' => '房贷首付比例',
    'word' => '房贷首付比例',
    'hits' => 0,
    'score' => 0,
  ),
  590 => 
  array (
    '_id' => '房贷首付多少',
    'word' => '房贷首付多少',
    'hits' => 0,
    'score' => 0,
  ),
  591 => 
  array (
    '_id' => '房贷提前还款划算吗',
    'word' => '房贷提前还款划算吗',
    'hits' => 0,
    'score' => 0,
  ),
  592 => 
  array (
    '_id' => '房贷提前还款怎么算',
    'word' => '房贷提前还款怎么算',
    'hits' => 0,
    'score' => 0,
  ),
  593 => 
  array (
    '_id' => '房贷逾期',
    'word' => '房贷逾期',
    'hits' => 0,
    'score' => 0,
  ),
  594 => 
  array (
    '_id' => '房贷月供',
    'word' => '房贷月供',
    'hits' => 0,
    'score' => 0,
  ),
  595 => 
  array (
    '_id' => '房地产',
    'word' => '房地产',
    'hits' => 0,
    'score' => 0,
  ),
  596 => 
  array (
    '_id' => '房地产按揭',
    'word' => '房地产按揭',
    'hits' => 0,
    'score' => 0,
  ),
  597 => 
  array (
    '_id' => '房地产变更登记',
    'word' => '房地产变更登记',
    'hits' => 0,
    'score' => 0,
  ),
  598 => 
  array (
    '_id' => '房地产测绘',
    'word' => '房地产测绘',
    'hits' => 0,
    'score' => 0,
  ),
  599 => 
  array (
    '_id' => '房地产产籍',
    'word' => '房地产产籍',
    'hits' => 0,
    'score' => 0,
  ),
  600 => 
  array (
    '_id' => '房地产产权',
    'word' => '房地产产权',
    'hits' => 0,
    'score' => 0,
  ),
  601 => 
  array (
    '_id' => '房地产产权管理',
    'word' => '房地产产权管理',
    'hits' => 0,
    'score' => 0,
  ),
  602 => 
  array (
    '_id' => '房地产存量',
    'word' => '房地产存量',
    'hits' => 0,
    'score' => 0,
  ),
  603 => 
  array (
    '_id' => '房地产抵押',
    'word' => '房地产抵押',
    'hits' => 0,
    'score' => 0,
  ),
  604 => 
  array (
    '_id' => '房地产抵押权人',
    'word' => '房地产抵押权人',
    'hits' => 0,
    'score' => 0,
  ),
  605 => 
  array (
    '_id' => '房地产抵押人',
    'word' => '房地产抵押人',
    'hits' => 0,
    'score' => 0,
  ),
  606 => 
  array (
    '_id' => '房地产典当',
    'word' => '房地产典当',
    'hits' => 0,
    'score' => 0,
  ),
  607 => 
  array (
    '_id' => '房地产法',
    'word' => '房地产法',
    'hits' => 0,
    'score' => 0,
  ),
  608 => 
  array (
    '_id' => '房地产分幅平面图',
    'word' => '房地产分幅平面图',
    'hits' => 0,
    'score' => 0,
  ),
  609 => 
  array (
    '_id' => '房地产共有权',
    'word' => '房地产共有权',
    'hits' => 0,
    'score' => 0,
  ),
  610 => 
  array (
    '_id' => '房地产估价',
    'word' => '房地产估价',
    'hits' => 0,
    'score' => 0,
  ),
  611 => 
  array (
    '_id' => '房地产广告',
    'word' => '房地产广告',
    'hits' => 0,
    'score' => 0,
  ),
  612 => 
  array (
    '_id' => '房地产交易',
    'word' => '房地产交易',
    'hits' => 0,
    'score' => 0,
  ),
  613 => 
  array (
    '_id' => '房地产交易手续费',
    'word' => '房地产交易手续费',
    'hits' => 0,
    'score' => 0,
  ),
  614 => 
  array (
    '_id' => '房地产金融',
    'word' => '房地产金融',
    'hits' => 0,
    'score' => 0,
  ),
  615 => 
  array (
    '_id' => '房地产经纪',
    'word' => '房地产经纪',
    'hits' => 0,
    'score' => 0,
  ),
  616 => 
  array (
    '_id' => '房地产开发',
    'word' => '房地产开发',
    'hits' => 0,
    'score' => 0,
  ),
  617 => 
  array (
    '_id' => '房地产开发经营',
    'word' => '房地产开发经营',
    'hits' => 0,
    'score' => 0,
  ),
  618 => 
  array (
    '_id' => '房地产开发商',
    'word' => '房地产开发商',
    'hits' => 0,
    'score' => 0,
  ),
  619 => 
  array (
    '_id' => '房地产开发项目',
    'word' => '房地产开发项目',
    'hits' => 0,
    'score' => 0,
  ),
  620 => 
  array (
    '_id' => '房地产灭失量',
    'word' => '房地产灭失量',
    'hits' => 0,
    'score' => 0,
  ),
  621 => 
  array (
    '_id' => '房地产拍卖',
    'word' => '房地产拍卖',
    'hits' => 0,
    'score' => 0,
  ),
  622 => 
  array (
    '_id' => '房地产泡沫',
    'word' => '房地产泡沫',
    'hits' => 0,
    'score' => 0,
  ),
  623 => 
  array (
    '_id' => '房地产评估',
    'word' => '房地产评估',
    'hits' => 0,
    'score' => 0,
  ),
  624 => 
  array (
    '_id' => '房地产评估价格',
    'word' => '房地产评估价格',
    'hits' => 0,
    'score' => 0,
  ),
  625 => 
  array (
    '_id' => '房地产企业所得税',
    'word' => '房地产企业所得税',
    'hits' => 0,
    'score' => 0,
  ),
  626 => 
  array (
    '_id' => '房地产权利人',
    'word' => '房地产权利人',
    'hits' => 0,
    'score' => 0,
  ),
  627 => 
  array (
    '_id' => '房地产权属登记',
    'word' => '房地产权属登记',
    'hits' => 0,
    'score' => 0,
  ),
  628 => 
  array (
    '_id' => '房地产权属总登记',
    'word' => '房地产权属总登记',
    'hits' => 0,
    'score' => 0,
  ),
  629 => 
  array (
    '_id' => '房地产容积率',
    'word' => '房地产容积率',
    'hits' => 0,
    'score' => 0,
  ),
  630 => 
  array (
    '_id' => '房地产使用权',
    'word' => '房地产使用权',
    'hits' => 0,
    'score' => 0,
  ),
  631 => 
  array (
    '_id' => '房地产市场',
    'word' => '房地产市场',
    'hits' => 0,
    'score' => 0,
  ),
  632 => 
  array (
    '_id' => '房地产所有权',
    'word' => '房地产所有权',
    'hits' => 0,
    'score' => 0,
  ),
  633 => 
  array (
    '_id' => '房地产他项权利登记',
    'word' => '房地产他项权利登记',
    'hits' => 0,
    'score' => 0,
  ),
  634 => 
  array (
    '_id' => '房地产投资',
    'word' => '房地产投资',
    'hits' => 0,
    'score' => 0,
  ),
  635 => 
  array (
    '_id' => '房地产投资模式',
    'word' => '房地产投资模式',
    'hits' => 0,
    'score' => 0,
  ),
  636 => 
  array (
    '_id' => '房地产投资泡沫',
    'word' => '房地产投资泡沫',
    'hits' => 0,
    'score' => 0,
  ),
  637 => 
  array (
    '_id' => '房地产图',
    'word' => '房地产图',
    'hits' => 0,
    'score' => 0,
  ),
  638 => 
  array (
    '_id' => '房地产销售方案',
    'word' => '房地产销售方案',
    'hits' => 0,
    'score' => 0,
  ),
  639 => 
  array (
    '_id' => '房地产新政策',
    'word' => '房地产新政策',
    'hits' => 0,
    'score' => 0,
  ),
  640 => 
  array (
    '_id' => '房地产信托',
    'word' => '房地产信托',
    'hits' => 0,
    'score' => 0,
  ),
  641 => 
  array (
    '_id' => '房地产业',
    'word' => '房地产业',
    'hits' => 0,
    'score' => 0,
  ),
  642 => 
  array (
    '_id' => '房地产营销',
    'word' => '房地产营销',
    'hits' => 0,
    'score' => 0,
  ),
  643 => 
  array (
    '_id' => '房地产营业税',
    'word' => '房地产营业税',
    'hits' => 0,
    'score' => 0,
  ),
  644 => 
  array (
    '_id' => '房地产增量',
    'word' => '房地产增量',
    'hits' => 0,
    'score' => 0,
  ),
  645 => 
  array (
    '_id' => '房地产政策调控',
    'word' => '房地产政策调控',
    'hits' => 0,
    'score' => 0,
  ),
  646 => 
  array (
    '_id' => '房地产知识大全',
    'word' => '房地产知识大全',
    'hits' => 0,
    'score' => 0,
  ),
  647 => 
  array (
    '_id' => '房地产中介',
    'word' => '房地产中介',
    'hits' => 0,
    'score' => 0,
  ),
  648 => 
  array (
    '_id' => '房地产注销登记',
    'word' => '房地产注销登记',
    'hits' => 0,
    'score' => 0,
  ),
  649 => 
  array (
    '_id' => '房地产转让',
    'word' => '房地产转让',
    'hits' => 0,
    'score' => 0,
  ),
  650 => 
  array (
    '_id' => '房地产转移登记',
    'word' => '房地产转移登记',
    'hits' => 0,
    'score' => 0,
  ),
  651 => 
  array (
    '_id' => '房地产咨询',
    'word' => '房地产咨询',
    'hits' => 0,
    'score' => 0,
  ),
  652 => 
  array (
    '_id' => '房地产综合开发',
    'word' => '房地产综合开发',
    'hits' => 0,
    'score' => 0,
  ),
  653 => 
  array (
    '_id' => '房地产租赁合同',
    'word' => '房地产租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  654 => 
  array (
    '_id' => '房顶漏水',
    'word' => '房顶漏水',
    'hits' => 0,
    'score' => 0,
  ),
  655 => 
  array (
    '_id' => '房改房土地出让金',
    'word' => '房改房土地出让金',
    'hits' => 0,
    'score' => 0,
  ),
  656 => 
  array (
    '_id' => '房价',
    'word' => '房价',
    'hits' => 0,
    'score' => 0,
  ),
  657 => 
  array (
    '_id' => '房价调控政策',
    'word' => '房价调控政策',
    'hits' => 0,
    'score' => 0,
  ),
  658 => 
  array (
    '_id' => '房价会涨吗',
    'word' => '房价会涨吗',
    'hits' => 0,
    'score' => 0,
  ),
  659 => 
  array (
    '_id' => '房价收入比',
    'word' => '房价收入比',
    'hits' => 0,
    'score' => 0,
  ),
  660 => 
  array (
    '_id' => '房价收入比计算',
    'word' => '房价收入比计算',
    'hits' => 0,
    'score' => 0,
  ),
  661 => 
  array (
    '_id' => '房价下跌',
    'word' => '房价下跌',
    'hits' => 0,
    'score' => 0,
  ),
  662 => 
  array (
    '_id' => '房价下跌后果',
    'word' => '房价下跌后果',
    'hits' => 0,
    'score' => 0,
  ),
  663 => 
  array (
    '_id' => '房价走势',
    'word' => '房价走势',
    'hits' => 0,
    'score' => 0,
  ),
  664 => 
  array (
    '_id' => '房间灯',
    'word' => '房间灯',
    'hits' => 0,
    'score' => 0,
  ),
  665 => 
  array (
    '_id' => '房市崩盘',
    'word' => '房市崩盘',
    'hits' => 0,
    'score' => 0,
  ),
  666 => 
  array (
    '_id' => '房屋拆迁',
    'word' => '房屋拆迁',
    'hits' => 0,
    'score' => 0,
  ),
  667 => 
  array (
    '_id' => '房屋拆迁补偿',
    'word' => '房屋拆迁补偿',
    'hits' => 0,
    'score' => 0,
  ),
  668 => 
  array (
    '_id' => '房屋拆迁合同',
    'word' => '房屋拆迁合同',
    'hits' => 0,
    'score' => 0,
  ),
  669 => 
  array (
    '_id' => '房屋产权变更',
    'word' => '房屋产权变更',
    'hits' => 0,
    'score' => 0,
  ),
  670 => 
  array (
    '_id' => '房屋产权到期',
    'word' => '房屋产权到期',
    'hits' => 0,
    'score' => 0,
  ),
  671 => 
  array (
    '_id' => '房屋产权登记',
    'word' => '房屋产权登记',
    'hits' => 0,
    'score' => 0,
  ),
  672 => 
  array (
    '_id' => '房屋产权面积',
    'word' => '房屋产权面积',
    'hits' => 0,
    'score' => 0,
  ),
  673 => 
  array (
    '_id' => '房屋产权证',
    'word' => '房屋产权证',
    'hits' => 0,
    'score' => 0,
  ),
  674 => 
  array (
    '_id' => '房屋产权证明',
    'word' => '房屋产权证明',
    'hits' => 0,
    'score' => 0,
  ),
  675 => 
  array (
    '_id' => '房屋出售信息',
    'word' => '房屋出售信息',
    'hits' => 0,
    'score' => 0,
  ),
  676 => 
  array (
    '_id' => '房屋出租税',
    'word' => '房屋出租税',
    'hits' => 0,
    'score' => 0,
  ),
  677 => 
  array (
    '_id' => '房屋贷款利率',
    'word' => '房屋贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  678 => 
  array (
    '_id' => '房屋抵押银行贷款',
    'word' => '房屋抵押银行贷款',
    'hits' => 0,
    'score' => 0,
  ),
  679 => 
  array (
    '_id' => '房屋二次抵押贷款',
    'word' => '房屋二次抵押贷款',
    'hits' => 0,
    'score' => 0,
  ),
  680 => 
  array (
    '_id' => '房屋估价',
    'word' => '房屋估价',
    'hits' => 0,
    'score' => 0,
  ),
  681 => 
  array (
    '_id' => '房屋过户费',
    'word' => '房屋过户费',
    'hits' => 0,
    'score' => 0,
  ),
  682 => 
  array (
    '_id' => '房屋过户费用计算',
    'word' => '房屋过户费用计算',
    'hits' => 0,
    'score' => 0,
  ),
  683 => 
  array (
    '_id' => '房屋继承',
    'word' => '房屋继承',
    'hits' => 0,
    'score' => 0,
  ),
  684 => 
  array (
    '_id' => '房屋继承法',
    'word' => '房屋继承法',
    'hits' => 0,
    'score' => 0,
  ),
  685 => 
  array (
    '_id' => '房屋建筑工程',
    'word' => '房屋建筑工程',
    'hits' => 0,
    'score' => 0,
  ),
  686 => 
  array (
    '_id' => '房屋交易税',
    'word' => '房屋交易税',
    'hits' => 0,
    'score' => 0,
  ),
  687 => 
  array (
    '_id' => '房屋结构',
    'word' => '房屋结构',
    'hits' => 0,
    'score' => 0,
  ),
  688 => 
  array (
    '_id' => '房屋买卖合同',
    'word' => '房屋买卖合同',
    'hits' => 0,
    'score' => 0,
  ),
  689 => 
  array (
    '_id' => '房屋买卖合同范本',
    'word' => '房屋买卖合同范本',
    'hits' => 0,
    'score' => 0,
  ),
  690 => 
  array (
    '_id' => '房屋买卖纠纷',
    'word' => '房屋买卖纠纷',
    'hits' => 0,
    'score' => 0,
  ),
  691 => 
  array (
    '_id' => '房屋买卖协议书',
    'word' => '房屋买卖协议书',
    'hits' => 0,
    'score' => 0,
  ),
  692 => 
  array (
    '_id' => '房屋面积',
    'word' => '房屋面积',
    'hits' => 0,
    'score' => 0,
  ),
  693 => 
  array (
    '_id' => '房屋评估',
    'word' => '房屋评估',
    'hits' => 0,
    'score' => 0,
  ),
  694 => 
  array (
    '_id' => '房屋契税',
    'word' => '房屋契税',
    'hits' => 0,
    'score' => 0,
  ),
  695 => 
  array (
    '_id' => '房屋权属登记',
    'word' => '房屋权属登记',
    'hits' => 0,
    'score' => 0,
  ),
  696 => 
  array (
    '_id' => '房屋所有权',
    'word' => '房屋所有权',
    'hits' => 0,
    'score' => 0,
  ),
  697 => 
  array (
    '_id' => '房屋他项权证',
    'word' => '房屋他项权证',
    'hits' => 0,
    'score' => 0,
  ),
  698 => 
  array (
    '_id' => '房屋维修',
    'word' => '房屋维修',
    'hits' => 0,
    'score' => 0,
  ),
  699 => 
  array (
    '_id' => '房屋维修基金',
    'word' => '房屋维修基金',
    'hits' => 0,
    'score' => 0,
  ),
  700 => 
  array (
    '_id' => '房屋维修基金怎么交',
    'word' => '房屋维修基金怎么交',
    'hits' => 0,
    'score' => 0,
  ),
  701 => 
  array (
    '_id' => '房屋修缮',
    'word' => '房屋修缮',
    'hits' => 0,
    'score' => 0,
  ),
  702 => 
  array (
    '_id' => '房屋验收注意事项',
    'word' => '房屋验收注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  703 => 
  array (
    '_id' => '房屋赠与过户费用',
    'word' => '房屋赠与过户费用',
    'hits' => 0,
    'score' => 0,
  ),
  704 => 
  array (
    '_id' => '房屋赠与协议',
    'word' => '房屋赠与协议',
    'hits' => 0,
    'score' => 0,
  ),
  705 => 
  array (
    '_id' => '房屋征收',
    'word' => '房屋征收',
    'hits' => 0,
    'score' => 0,
  ),
  706 => 
  array (
    '_id' => '房屋转让合同',
    'word' => '房屋转让合同',
    'hits' => 0,
    'score' => 0,
  ),
  707 => 
  array (
    '_id' => '房屋转租',
    'word' => '房屋转租',
    'hits' => 0,
    'score' => 0,
  ),
  708 => 
  array (
    '_id' => '房屋装修步骤',
    'word' => '房屋装修步骤',
    'hits' => 0,
    'score' => 0,
  ),
  709 => 
  array (
    '_id' => '房屋装修合同',
    'word' => '房屋装修合同',
    'hits' => 0,
    'score' => 0,
  ),
  710 => 
  array (
    '_id' => '房屋装修设计',
    'word' => '房屋装修设计',
    'hits' => 0,
    'score' => 0,
  ),
  711 => 
  array (
    '_id' => '房屋装修预算',
    'word' => '房屋装修预算',
    'hits' => 0,
    'score' => 0,
  ),
  712 => 
  array (
    '_id' => '房屋装修注意事项',
    'word' => '房屋装修注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  713 => 
  array (
    '_id' => '房屋租金',
    'word' => '房屋租金',
    'hits' => 0,
    'score' => 0,
  ),
  714 => 
  array (
    '_id' => '房屋租赁',
    'word' => '房屋租赁',
    'hits' => 0,
    'score' => 0,
  ),
  715 => 
  array (
    '_id' => '房屋租赁合同',
    'word' => '房屋租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  716 => 
  array (
    '_id' => '房屋租赁合同登记备案',
    'word' => '房屋租赁合同登记备案',
    'hits' => 0,
    'score' => 0,
  ),
  717 => 
  array (
    '_id' => '房屋租赁合同范本',
    'word' => '房屋租赁合同范本',
    'hits' => 0,
    'score' => 0,
  ),
  718 => 
  array (
    '_id' => '房屋租赁证明',
    'word' => '房屋租赁证明',
    'hits' => 0,
    'score' => 0,
  ),
  719 => 
  array (
    '_id' => '房子风水',
    'word' => '房子风水',
    'hits' => 0,
    'score' => 0,
  ),
  720 => 
  array (
    '_id' => '房子首付多少',
    'word' => '房子首付多少',
    'hits' => 0,
    'score' => 0,
  ),
  721 => 
  array (
    '_id' => '房子装修风格',
    'word' => '房子装修风格',
    'hits' => 0,
    'score' => 0,
  ),
  722 => 
  array (
    '_id' => '非普通住宅',
    'word' => '非普通住宅',
    'hits' => 0,
    'score' => 0,
  ),
  723 => 
  array (
    '_id' => '分期付款',
    'word' => '分期付款',
    'hits' => 0,
    'score' => 0,
  ),
  724 => 
  array (
    '_id' => '分期付款买房',
    'word' => '分期付款买房',
    'hits' => 0,
    'score' => 0,
  ),
  725 => 
  array (
    '_id' => '夫妻房产过户',
    'word' => '夫妻房产过户',
    'hits' => 0,
    'score' => 0,
  ),
  726 => 
  array (
    '_id' => '夫妻公积金贷款',
    'word' => '夫妻公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  727 => 
  array (
    '_id' => '福州住房公积金提取',
    'word' => '福州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  728 => 
  array (
    '_id' => '父母房产继承',
    'word' => '父母房产继承',
    'hits' => 0,
    'score' => 0,
  ),
  729 => 
  array (
    '_id' => '复式住宅',
    'word' => '复式住宅',
    'hits' => 0,
    'score' => 0,
  ),
  730 => 
  array (
    '_id' => '复式装修',
    'word' => '复式装修',
    'hits' => 0,
    'score' => 0,
  ),
  731 => 
  array (
    '_id' => '高层公摊',
    'word' => '高层公摊',
    'hits' => 0,
    'score' => 0,
  ),
  732 => 
  array (
    '_id' => '高层住宅',
    'word' => '高层住宅',
    'hits' => 0,
    'score' => 0,
  ),
  733 => 
  array (
    '_id' => '阁楼装修',
    'word' => '阁楼装修',
    'hits' => 0,
    'score' => 0,
  ),
  734 => 
  array (
    '_id' => '个人出租房屋',
    'word' => '个人出租房屋',
    'hits' => 0,
    'score' => 0,
  ),
  735 => 
  array (
    '_id' => '个人公积金查询',
    'word' => '个人公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  736 => 
  array (
    '_id' => '个人公积金贷款',
    'word' => '个人公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  737 => 
  array (
    '_id' => '个人住房抵押贷款',
    'word' => '个人住房抵押贷款',
    'hits' => 0,
    'score' => 0,
  ),
  738 => 
  array (
    '_id' => '工字钢尺寸',
    'word' => '工字钢尺寸',
    'hits' => 0,
    'score' => 0,
  ),
  739 => 
  array (
    '_id' => '工字钢规格',
    'word' => '工字钢规格',
    'hits' => 0,
    'score' => 0,
  ),
  740 => 
  array (
    '_id' => '公房承租权',
    'word' => '公房承租权',
    'hits' => 0,
    'score' => 0,
  ),
  741 => 
  array (
    '_id' => '公共服务设施用地',
    'word' => '公共服务设施用地',
    'hits' => 0,
    'score' => 0,
  ),
  742 => 
  array (
    '_id' => '公共活动中心',
    'word' => '公共活动中心',
    'hits' => 0,
    'score' => 0,
  ),
  743 => 
  array (
    '_id' => '公共绿地',
    'word' => '公共绿地',
    'hits' => 0,
    'score' => 0,
  ),
  744 => 
  array (
    '_id' => '公共面积',
    'word' => '公共面积',
    'hits' => 0,
    'score' => 0,
  ),
  745 => 
  array (
    '_id' => '公共维修基',
    'word' => '公共维修基',
    'hits' => 0,
    'score' => 0,
  ),
  746 => 
  array (
    '_id' => '公共维修基金',
    'word' => '公共维修基金',
    'hits' => 0,
    'score' => 0,
  ),
  747 => 
  array (
    '_id' => '公共维修基金额',
    'word' => '公共维修基金额',
    'hits' => 0,
    'score' => 0,
  ),
  748 => 
  array (
    '_id' => '公积金查询',
    'word' => '公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  749 => 
  array (
    '_id' => '公积金贷款查询',
    'word' => '公积金贷款查询',
    'hits' => 0,
    'score' => 0,
  ),
  750 => 
  array (
    '_id' => '公积金贷款额度',
    'word' => '公积金贷款额度',
    'hits' => 0,
    'score' => 0,
  ),
  751 => 
  array (
    '_id' => '公积金贷款购房',
    'word' => '公积金贷款购房',
    'hits' => 0,
    'score' => 0,
  ),
  752 => 
  array (
    '_id' => '公积金贷款计算',
    'word' => '公积金贷款计算',
    'hits' => 0,
    'score' => 0,
  ),
  753 => 
  array (
    '_id' => '公积金贷款利率是多少',
    'word' => '公积金贷款利率是多少',
    'hits' => 0,
    'score' => 0,
  ),
  754 => 
  array (
    '_id' => '公积金贷款买房',
    'word' => '公积金贷款买房',
    'hits' => 0,
    'score' => 0,
  ),
  755 => 
  array (
    '_id' => '公积金贷款年限',
    'word' => '公积金贷款年限',
    'hits' => 0,
    'score' => 0,
  ),
  756 => 
  array (
    '_id' => '公积金贷款上限',
    'word' => '公积金贷款上限',
    'hits' => 0,
    'score' => 0,
  ),
  757 => 
  array (
    '_id' => '公积金贷款首付比例',
    'word' => '公积金贷款首付比例',
    'hits' => 0,
    'score' => 0,
  ),
  758 => 
  array (
    '_id' => '公积金贷款提前还款',
    'word' => '公积金贷款提前还款',
    'hits' => 0,
    'score' => 0,
  ),
  759 => 
  array (
    '_id' => '公积金贷款提前还款划算吗',
    'word' => '公积金贷款提前还款划算吗',
    'hits' => 0,
    'score' => 0,
  ),
  760 => 
  array (
    '_id' => '公积金贷款条件',
    'word' => '公积金贷款条件',
    'hits' => 0,
    'score' => 0,
  ),
  761 => 
  array (
    '_id' => '公积金缴纳',
    'word' => '公积金缴纳',
    'hits' => 0,
    'score' => 0,
  ),
  762 => 
  array (
    '_id' => '公积金如何贷款',
    'word' => '公积金如何贷款',
    'hits' => 0,
    'score' => 0,
  ),
  763 => 
  array (
    '_id' => '公积金如何提取',
    'word' => '公积金如何提取',
    'hits' => 0,
    'score' => 0,
  ),
  764 => 
  array (
    '_id' => '公积金提前还贷',
    'word' => '公积金提前还贷',
    'hits' => 0,
    'score' => 0,
  ),
  765 => 
  array (
    '_id' => '公积金提取额度',
    'word' => '公积金提取额度',
    'hits' => 0,
    'score' => 0,
  ),
  766 => 
  array (
    '_id' => '公积金提取申请表',
    'word' => '公积金提取申请表',
    'hits' => 0,
    'score' => 0,
  ),
  767 => 
  array (
    '_id' => '公积金提取手续',
    'word' => '公积金提取手续',
    'hits' => 0,
    'score' => 0,
  ),
  768 => 
  array (
    '_id' => '公积金提取条件',
    'word' => '公积金提取条件',
    'hits' => 0,
    'score' => 0,
  ),
  769 => 
  array (
    '_id' => '公积金怎么贷款',
    'word' => '公积金怎么贷款',
    'hits' => 0,
    'score' => 0,
  ),
  770 => 
  array (
    '_id' => '公积金怎么提取',
    'word' => '公积金怎么提取',
    'hits' => 0,
    'score' => 0,
  ),
  771 => 
  array (
    '_id' => '公摊面积',
    'word' => '公摊面积',
    'hits' => 0,
    'score' => 0,
  ),
  772 => 
  array (
    '_id' => '公摊面积怎么算',
    'word' => '公摊面积怎么算',
    'hits' => 0,
    'score' => 0,
  ),
  773 => 
  array (
    '_id' => '公用建筑面积',
    'word' => '公用建筑面积',
    'hits' => 0,
    'score' => 0,
  ),
  774 => 
  array (
    '_id' => '公用建筑面积分摊系数',
    'word' => '公用建筑面积分摊系数',
    'hits' => 0,
    'score' => 0,
  ),
  775 => 
  array (
    '_id' => '公用面积',
    'word' => '公用面积',
    'hits' => 0,
    'score' => 0,
  ),
  776 => 
  array (
    '_id' => '公用设施用房',
    'word' => '公用设施用房',
    'hits' => 0,
    'score' => 0,
  ),
  777 => 
  array (
    '_id' => '公有房屋',
    'word' => '公有房屋',
    'hits' => 0,
    'score' => 0,
  ),
  778 => 
  array (
    '_id' => '公寓式住宅',
    'word' => '公寓式住宅',
    'hits' => 0,
    'score' => 0,
  ),
  779 => 
  array (
    '_id' => '公寓装修效果图',
    'word' => '公寓装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  780 => 
  array (
    '_id' => '公租房廉租房',
    'word' => '公租房廉租房',
    'hits' => 0,
    'score' => 0,
  ),
  781 => 
  array (
    '_id' => '共有产权房',
    'word' => '共有产权房',
    'hits' => 0,
    'score' => 0,
  ),
  782 => 
  array (
    '_id' => '共有房产',
    'word' => '共有房产',
    'hits' => 0,
    'score' => 0,
  ),
  783 => 
  array (
    '_id' => '共有面积',
    'word' => '共有面积',
    'hits' => 0,
    'score' => 0,
  ),
  784 => 
  array (
    '_id' => '构件拔榫',
    'word' => '构件拔榫',
    'hits' => 0,
    'score' => 0,
  ),
  785 => 
  array (
    '_id' => '构造钢筋',
    'word' => '构造钢筋',
    'hits' => 0,
    'score' => 0,
  ),
  786 => 
  array (
    '_id' => '购二手房流程',
    'word' => '购二手房流程',
    'hits' => 0,
    'score' => 0,
  ),
  787 => 
  array (
    '_id' => '购房常识',
    'word' => '购房常识',
    'hits' => 0,
    'score' => 0,
  ),
  788 => 
  array (
    '_id' => '购房贷款利率',
    'word' => '购房贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  789 => 
  array (
    '_id' => '购房合同',
    'word' => '购房合同',
    'hits' => 0,
    'score' => 0,
  ),
  790 => 
  array (
    '_id' => '购房合同备案',
    'word' => '购房合同备案',
    'hits' => 0,
    'score' => 0,
  ),
  791 => 
  array (
    '_id' => '购房合同范本',
    'word' => '购房合同范本',
    'hits' => 0,
    'score' => 0,
  ),
  792 => 
  array (
    '_id' => '购房合同更名',
    'word' => '购房合同更名',
    'hits' => 0,
    'score' => 0,
  ),
  793 => 
  array (
    '_id' => '购房合同书',
    'word' => '购房合同书',
    'hits' => 0,
    'score' => 0,
  ),
  794 => 
  array (
    '_id' => '购房收入证明',
    'word' => '购房收入证明',
    'hits' => 0,
    'score' => 0,
  ),
  795 => 
  array (
    '_id' => '购房税',
    'word' => '购房税',
    'hits' => 0,
    'score' => 0,
  ),
  796 => 
  array (
    '_id' => '购房协议书',
    'word' => '购房协议书',
    'hits' => 0,
    'score' => 0,
  ),
  797 => 
  array (
    '_id' => '购房须知',
    'word' => '购房须知',
    'hits' => 0,
    'score' => 0,
  ),
  798 => 
  array (
    '_id' => '购买二手房',
    'word' => '购买二手房',
    'hits' => 0,
    'score' => 0,
  ),
  799 => 
  array (
    '_id' => '购买房子流程',
    'word' => '购买房子流程',
    'hits' => 0,
    'score' => 0,
  ),
  800 => 
  array (
    '_id' => '购买新房流程',
    'word' => '购买新房流程',
    'hits' => 0,
    'score' => 0,
  ),
  801 => 
  array (
    '_id' => '购买新房注意事项',
    'word' => '购买新房注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  802 => 
  array (
    '_id' => '估价报告',
    'word' => '估价报告',
    'hits' => 0,
    'score' => 0,
  ),
  803 => 
  array (
    '_id' => '估价对象',
    'word' => '估价对象',
    'hits' => 0,
    'score' => 0,
  ),
  804 => 
  array (
    '_id' => '估价规范',
    'word' => '估价规范',
    'hits' => 0,
    'score' => 0,
  ),
  805 => 
  array (
    '_id' => '估价目的',
    'word' => '估价目的',
    'hits' => 0,
    'score' => 0,
  ),
  806 => 
  array (
    '_id' => '估价师',
    'word' => '估价师',
    'hits' => 0,
    'score' => 0,
  ),
  807 => 
  array (
    '_id' => '估值',
    'word' => '估值',
    'hits' => 0,
    'score' => 0,
  ),
  808 => 
  array (
    '_id' => '古典欧式风格',
    'word' => '古典欧式风格',
    'hits' => 0,
    'score' => 0,
  ),
  809 => 
  array (
    '_id' => '固特合页',
    'word' => '固特合页',
    'hits' => 0,
    'score' => 0,
  ),
  810 => 
  array (
    '_id' => '固原公积金贷款',
    'word' => '固原公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  811 => 
  array (
    '_id' => '固原住房公积金提取',
    'word' => '固原住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  812 => 
  array (
    '_id' => '刮腻子施工工艺',
    'word' => '刮腻子施工工艺',
    'hits' => 0,
    'score' => 0,
  ),
  813 => 
  array (
    '_id' => '关于房产税',
    'word' => '关于房产税',
    'hits' => 0,
    'score' => 0,
  ),
  814 => 
  array (
    '_id' => '冠牛木门',
    'word' => '冠牛木门',
    'hits' => 0,
    'score' => 0,
  ),
  815 => 
  array (
    '_id' => '管道井',
    'word' => '管道井',
    'hits' => 0,
    'score' => 0,
  ),
  816 => 
  array (
    '_id' => '光芒吊顶',
    'word' => '光芒吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  817 => 
  array (
    '_id' => '广安公积金贷款',
    'word' => '广安公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  818 => 
  array (
    '_id' => '广博插座',
    'word' => '广博插座',
    'hits' => 0,
    'score' => 0,
  ),
  819 => 
  array (
    '_id' => '广元公积金贷款',
    'word' => '广元公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  820 => 
  array (
    '_id' => '广州住房公积金提取',
    'word' => '广州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  821 => 
  array (
    '_id' => '轨道线',
    'word' => '轨道线',
    'hits' => 0,
    'score' => 0,
  ),
  822 => 
  array (
    '_id' => '贵阳住房公积金查询',
    'word' => '贵阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  823 => 
  array (
    '_id' => '贵阳住房公积金提取',
    'word' => '贵阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  824 => 
  array (
    '_id' => '桂林住房公积金查询',
    'word' => '桂林住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  825 => 
  array (
    '_id' => '国八条',
    'word' => '国八条',
    'hits' => 0,
    'score' => 0,
  ),
  826 => 
  array (
    '_id' => '国家棚户区改造',
    'word' => '国家棚户区改造',
    'hits' => 0,
    'score' => 0,
  ),
  827 => 
  array (
    '_id' => '国土局',
    'word' => '国土局',
    'hits' => 0,
    'score' => 0,
  ),
  828 => 
  array (
    '_id' => '国土使用证',
    'word' => '国土使用证',
    'hits' => 0,
    'score' => 0,
  ),
  829 => 
  array (
    '_id' => '国有房产',
    'word' => '国有房产',
    'hits' => 0,
    'score' => 0,
  ),
  830 => 
  array (
    '_id' => '国有土地出让',
    'word' => '国有土地出让',
    'hits' => 0,
    'score' => 0,
  ),
  831 => 
  array (
    '_id' => '国有土地出让合同',
    'word' => '国有土地出让合同',
    'hits' => 0,
    'score' => 0,
  ),
  832 => 
  array (
    '_id' => '国有土地上房屋征收',
    'word' => '国有土地上房屋征收',
    'hits' => 0,
    'score' => 0,
  ),
  833 => 
  array (
    '_id' => '国有土地使用权出租',
    'word' => '国有土地使用权出租',
    'hits' => 0,
    'score' => 0,
  ),
  834 => 
  array (
    '_id' => '国有土地使用权转让',
    'word' => '国有土地使用权转让',
    'hits' => 0,
    'score' => 0,
  ),
  835 => 
  array (
    '_id' => '果洛州公积金贷款',
    'word' => '果洛州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  836 => 
  array (
    '_id' => '过道',
    'word' => '过道',
    'hits' => 0,
    'score' => 0,
  ),
  837 => 
  array (
    '_id' => '哈尔滨公积金贷款',
    'word' => '哈尔滨公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  838 => 
  array (
    '_id' => '哈尔滨住房公积金查询',
    'word' => '哈尔滨住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  839 => 
  array (
    '_id' => '哈尔滨住房公积金提取',
    'word' => '哈尔滨住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  840 => 
  array (
    '_id' => '哈劳水槽',
    'word' => '哈劳水槽',
    'hits' => 0,
    'score' => 0,
  ),
  841 => 
  array (
    '_id' => '哈密公积金贷款',
    'word' => '哈密公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  842 => 
  array (
    '_id' => '哈密住房公积金提取',
    'word' => '哈密住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  843 => 
  array (
    '_id' => '海北州公积金贷款',
    'word' => '海北州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  844 => 
  array (
    '_id' => '海北州住房公积金查询',
    'word' => '海北州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  845 => 
  array (
    '_id' => '海北州住房公积金提取',
    'word' => '海北州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  846 => 
  array (
    '_id' => '海创集成吊顶',
    'word' => '海创集成吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  847 => 
  array (
    '_id' => '海德曼门铃',
    'word' => '海德曼门铃',
    'hits' => 0,
    'score' => 0,
  ),
  848 => 
  array (
    '_id' => '海东住房公积金提取',
    'word' => '海东住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  849 => 
  array (
    '_id' => '海尔冰箱',
    'word' => '海尔冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  850 => 
  array (
    '_id' => '海尔橱柜',
    'word' => '海尔橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  851 => 
  array (
    '_id' => '海口住房公积金查询',
    'word' => '海口住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  852 => 
  array (
    '_id' => '海口住房公积金提取',
    'word' => '海口住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  853 => 
  array (
    '_id' => '海门公积金贷款',
    'word' => '海门公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  854 => 
  array (
    '_id' => '海门住房公积金查询',
    'word' => '海门住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  855 => 
  array (
    '_id' => '海宁公积金贷款',
    'word' => '海宁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  856 => 
  array (
    '_id' => '海宁住房公积金提取',
    'word' => '海宁住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  857 => 
  array (
    '_id' => '海信冰箱',
    'word' => '海信冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  858 => 
  array (
    '_id' => '海信电视',
    'word' => '海信电视',
    'hits' => 0,
    'score' => 0,
  ),
  859 => 
  array (
    '_id' => '海信空调',
    'word' => '海信空调',
    'hits' => 0,
    'score' => 0,
  ),
  860 => 
  array (
    '_id' => '含水率',
    'word' => '含水率',
    'hits' => 0,
    'score' => 0,
  ),
  861 => 
  array (
    '_id' => '邯郸住房公积金查询',
    'word' => '邯郸住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  862 => 
  array (
    '_id' => '邯郸住房公积金提取',
    'word' => '邯郸住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  863 => 
  array (
    '_id' => '韩国装修风格',
    'word' => '韩国装修风格',
    'hits' => 0,
    'score' => 0,
  ),
  864 => 
  array (
    '_id' => '汉斯格雅',
    'word' => '汉斯格雅',
    'hits' => 0,
    'score' => 0,
  ),
  865 => 
  array (
    '_id' => '汉斯希尔净水器',
    'word' => '汉斯希尔净水器',
    'hits' => 0,
    'score' => 0,
  ),
  866 => 
  array (
    '_id' => '杭州住房公积金查询',
    'word' => '杭州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  867 => 
  array (
    '_id' => '杭州住房公积金提取',
    'word' => '杭州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  868 => 
  array (
    '_id' => '航嘉插座',
    'word' => '航嘉插座',
    'hits' => 0,
    'score' => 0,
  ),
  869 => 
  array (
    '_id' => '豪宅别墅图片',
    'word' => '豪宅别墅图片',
    'hits' => 0,
    'score' => 0,
  ),
  870 => 
  array (
    '_id' => '好莱客衣柜',
    'word' => '好莱客衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  871 => 
  array (
    '_id' => '好美家地板',
    'word' => '好美家地板',
    'hits' => 0,
    'score' => 0,
  ),
  872 => 
  array (
    '_id' => '好太太晾衣架',
    'word' => '好太太晾衣架',
    'hits' => 0,
    'score' => 0,
  ),
  873 => 
  array (
    '_id' => '合肥住房公积金查询',
    'word' => '合肥住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  874 => 
  array (
    '_id' => '合肥住房公积金提取',
    'word' => '合肥住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  875 => 
  array (
    '_id' => '合同',
    'word' => '合同',
    'hits' => 0,
    'score' => 0,
  ),
  876 => 
  array (
    '_id' => '合同陷阱',
    'word' => '合同陷阱',
    'hits' => 0,
    'score' => 0,
  ),
  877 => 
  array (
    '_id' => '何为标准绿色住宅',
    'word' => '何为标准绿色住宅',
    'hits' => 0,
    'score' => 0,
  ),
  878 => 
  array (
    '_id' => '和成卫浴',
    'word' => '和成卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  879 => 
  array (
    '_id' => '和田住房公积金查询',
    'word' => '和田住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  880 => 
  array (
    '_id' => '河源住房公积金提取',
    'word' => '河源住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  881 => 
  array (
    '_id' => '菏泽住房公积金提取',
    'word' => '菏泽住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  882 => 
  array (
    '_id' => '贺州住房公积金查询',
    'word' => '贺州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  883 => 
  array (
    '_id' => '鹤壁公积金贷款',
    'word' => '鹤壁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  884 => 
  array (
    '_id' => '鹤壁住房公积金查询',
    'word' => '鹤壁住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  885 => 
  array (
    '_id' => '鹤壁住房公积金提取',
    'word' => '鹤壁住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  886 => 
  array (
    '_id' => '鹤岗公积金贷款',
    'word' => '鹤岗公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  887 => 
  array (
    '_id' => '鹤岗住房公积金提取',
    'word' => '鹤岗住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  888 => 
  array (
    '_id' => '黑河公积金贷款',
    'word' => '黑河公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  889 => 
  array (
    '_id' => '黑河住房公积金查询',
    'word' => '黑河住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  890 => 
  array (
    '_id' => '黑河住房公积金提取',
    'word' => '黑河住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  891 => 
  array (
    '_id' => '黑色大理石',
    'word' => '黑色大理石',
    'hits' => 0,
    'score' => 0,
  ),
  892 => 
  array (
    '_id' => '恒洁马桶',
    'word' => '恒洁马桶',
    'hits' => 0,
    'score' => 0,
  ),
  893 => 
  array (
    '_id' => '恒洁卫浴',
    'word' => '恒洁卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  894 => 
  array (
    '_id' => '恒热热水器',
    'word' => '恒热热水器',
    'hits' => 0,
    'score' => 0,
  ),
  895 => 
  array (
    '_id' => '恒生卫浴',
    'word' => '恒生卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  896 => 
  array (
    '_id' => '衡水公积金贷款',
    'word' => '衡水公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  897 => 
  array (
    '_id' => '衡水住房公积金查询',
    'word' => '衡水住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  898 => 
  array (
    '_id' => '衡水住房公积金提取',
    'word' => '衡水住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  899 => 
  array (
    '_id' => '衡阳住房公积金查询',
    'word' => '衡阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  900 => 
  array (
    '_id' => '衡阳住房公积金提取',
    'word' => '衡阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  901 => 
  array (
    '_id' => '红河住房公积金提取',
    'word' => '红河住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  902 => 
  array (
    '_id' => '红木茶几',
    'word' => '红木茶几',
    'hits' => 0,
    'score' => 0,
  ),
  903 => 
  array (
    '_id' => '红木家具',
    'word' => '红木家具',
    'hits' => 0,
    'score' => 0,
  ),
  904 => 
  array (
    '_id' => '红木家具保养',
    'word' => '红木家具保养',
    'hits' => 0,
    'score' => 0,
  ),
  905 => 
  array (
    '_id' => '红苹果床垫',
    'word' => '红苹果床垫',
    'hits' => 0,
    'score' => 0,
  ),
  906 => 
  array (
    '_id' => '宏发地板',
    'word' => '宏发地板',
    'hits' => 0,
    'score' => 0,
  ),
  907 => 
  array (
    '_id' => '宏浪卫浴',
    'word' => '宏浪卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  908 => 
  array (
    '_id' => '宏起地板',
    'word' => '宏起地板',
    'hits' => 0,
    'score' => 0,
  ),
  909 => 
  array (
    '_id' => '虹吸式马桶',
    'word' => '虹吸式马桶',
    'hits' => 0,
    'score' => 0,
  ),
  910 => 
  array (
    '_id' => '鸿昌漆',
    'word' => '鸿昌漆',
    'hits' => 0,
    'score' => 0,
  ),
  911 => 
  array (
    '_id' => '鸿雁插座',
    'word' => '鸿雁插座',
    'hits' => 0,
    'score' => 0,
  ),
  912 => 
  array (
    '_id' => '呼和浩特公积金贷款',
    'word' => '呼和浩特公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  913 => 
  array (
    '_id' => '呼和浩特住房公积金查询',
    'word' => '呼和浩特住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  914 => 
  array (
    '_id' => '湖州住房公积金提取',
    'word' => '湖州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  915 => 
  array (
    '_id' => '葫芦岛住房公积金查询',
    'word' => '葫芦岛住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  916 => 
  array (
    '_id' => '户籍',
    'word' => '户籍',
    'hits' => 0,
    'score' => 0,
  ),
  917 => 
  array (
    '_id' => '户口',
    'word' => '户口',
    'hits' => 0,
    'score' => 0,
  ),
  918 => 
  array (
    '_id' => '户口迁移手续',
    'word' => '户口迁移手续',
    'hits' => 0,
    'score' => 0,
  ),
  919 => 
  array (
    '_id' => '户外地板',
    'word' => '户外地板',
    'hits' => 0,
    'score' => 0,
  ),
  920 => 
  array (
    '_id' => '户型',
    'word' => '户型',
    'hits' => 0,
    'score' => 0,
  ),
  921 => 
  array (
    '_id' => '户主',
    'word' => '户主',
    'hits' => 0,
    'score' => 0,
  ),
  922 => 
  array (
    '_id' => '护栏管',
    'word' => '护栏管',
    'hits' => 0,
    'score' => 0,
  ),
  923 => 
  array (
    '_id' => '护盘',
    'word' => '护盘',
    'hits' => 0,
    'score' => 0,
  ),
  924 => 
  array (
    '_id' => '花梨木家具',
    'word' => '花梨木家具',
    'hits' => 0,
    'score' => 0,
  ),
  925 => 
  array (
    '_id' => '花王漆',
    'word' => '花王漆',
    'hits' => 0,
    'score' => 0,
  ),
  926 => 
  array (
    '_id' => '花园式住宅',
    'word' => '花园式住宅',
    'hits' => 0,
    'score' => 0,
  ),
  927 => 
  array (
    '_id' => '花园洋房',
    'word' => '花园洋房',
    'hits' => 0,
    'score' => 0,
  ),
  928 => 
  array (
    '_id' => '华德地毯',
    'word' => '华德地毯',
    'hits' => 0,
    'score' => 0,
  ),
  929 => 
  array (
    '_id' => '华帝热水器',
    'word' => '华帝热水器',
    'hits' => 0,
    'score' => 0,
  ),
  930 => 
  array (
    '_id' => '华帝水槽',
    'word' => '华帝水槽',
    'hits' => 0,
    'score' => 0,
  ),
  931 => 
  array (
    '_id' => '华雕卫浴',
    'word' => '华雕卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  932 => 
  array (
    '_id' => '华鹤木门',
    'word' => '华鹤木门',
    'hits' => 0,
    'score' => 0,
  ),
  933 => 
  array (
    '_id' => '华美冰箱',
    'word' => '华美冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  934 => 
  array (
    '_id' => '华润腻子',
    'word' => '华润腻子',
    'hits' => 0,
    'score' => 0,
  ),
  935 => 
  array (
    '_id' => '华润漆',
    'word' => '华润漆',
    'hits' => 0,
    'score' => 0,
  ),
  936 => 
  array (
    '_id' => '华泰木门',
    'word' => '华泰木门',
    'hits' => 0,
    'score' => 0,
  ),
  937 => 
  array (
    '_id' => '华谊家具',
    'word' => '华谊家具',
    'hits' => 0,
    'score' => 0,
  ),
  938 => 
  array (
    '_id' => '怀化住房公积金查询',
    'word' => '怀化住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  939 => 
  array (
    '_id' => '淮安公积金贷款',
    'word' => '淮安公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  940 => 
  array (
    '_id' => '淮安住房公积金查询',
    'word' => '淮安住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  941 => 
  array (
    '_id' => '淮北公积金贷款',
    'word' => '淮北公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  942 => 
  array (
    '_id' => '淮北住房公积金提取',
    'word' => '淮北住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  943 => 
  array (
    '_id' => '淮南公积金贷款',
    'word' => '淮南公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  944 => 
  array (
    '_id' => '还房贷',
    'word' => '还房贷',
    'hits' => 0,
    'score' => 0,
  ),
  945 => 
  array (
    '_id' => '还建房买卖',
    'word' => '还建房买卖',
    'hits' => 0,
    'score' => 0,
  ),
  946 => 
  array (
    '_id' => '还款方式',
    'word' => '还款方式',
    'hits' => 0,
    'score' => 0,
  ),
  947 => 
  array (
    '_id' => '环保空调',
    'word' => '环保空调',
    'hits' => 0,
    'score' => 0,
  ),
  948 => 
  array (
    '_id' => '环保涂料',
    'word' => '环保涂料',
    'hits' => 0,
    'score' => 0,
  ),
  949 => 
  array (
    '_id' => '环境控制系统',
    'word' => '环境控制系统',
    'hits' => 0,
    'score' => 0,
  ),
  950 => 
  array (
    '_id' => '环美家居',
    'word' => '环美家居',
    'hits' => 0,
    'score' => 0,
  ),
  951 => 
  array (
    '_id' => '环氧地板漆',
    'word' => '环氧地板漆',
    'hits' => 0,
    'score' => 0,
  ),
  952 => 
  array (
    '_id' => '环氧富锌底漆',
    'word' => '环氧富锌底漆',
    'hits' => 0,
    'score' => 0,
  ),
  953 => 
  array (
    '_id' => '换热器原理',
    'word' => '换热器原理',
    'hits' => 0,
    'score' => 0,
  ),
  954 => 
  array (
    '_id' => '换手率',
    'word' => '换手率',
    'hits' => 0,
    'score' => 0,
  ),
  955 => 
  array (
    '_id' => '皇朝床垫',
    'word' => '皇朝床垫',
    'hits' => 0,
    'score' => 0,
  ),
  956 => 
  array (
    '_id' => '黄冈住房公积金查询',
    'word' => '黄冈住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  957 => 
  array (
    '_id' => '黄冈住房公积金提取',
    'word' => '黄冈住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  958 => 
  array (
    '_id' => '黄山公积金贷款',
    'word' => '黄山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  959 => 
  array (
    '_id' => '黄山住房公积金查询',
    'word' => '黄山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  960 => 
  array (
    '_id' => '黄石公积金贷款',
    'word' => '黄石公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  961 => 
  array (
    '_id' => '黄石住房公积金提取',
    'word' => '黄石住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  962 => 
  array (
    '_id' => '灰空间',
    'word' => '灰空间',
    'hits' => 0,
    'score' => 0,
  ),
  963 => 
  array (
    '_id' => '辉煌水龙头',
    'word' => '辉煌水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  964 => 
  array (
    '_id' => '惠达瓷砖',
    'word' => '惠达瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  965 => 
  array (
    '_id' => '惠达浴缸',
    'word' => '惠达浴缸',
    'hits' => 0,
    'score' => 0,
  ),
  966 => 
  array (
    '_id' => '惠而浦冰箱',
    'word' => '惠而浦冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  967 => 
  array (
    '_id' => '惠而浦空调',
    'word' => '惠而浦空调',
    'hits' => 0,
    'score' => 0,
  ),
  968 => 
  array (
    '_id' => '惠而浦热水器',
    'word' => '惠而浦热水器',
    'hits' => 0,
    'score' => 0,
  ),
  969 => 
  array (
    '_id' => '婚房装修效果图',
    'word' => '婚房装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  970 => 
  array (
    '_id' => '婚后房产',
    'word' => '婚后房产',
    'hits' => 0,
    'score' => 0,
  ),
  971 => 
  array (
    '_id' => '婚后房产证加名字',
    'word' => '婚后房产证加名字',
    'hits' => 0,
    'score' => 0,
  ),
  972 => 
  array (
    '_id' => '婚后房产证上加名字有用',
    'word' => '婚后房产证上加名字有用',
    'hits' => 0,
    'score' => 0,
  ),
  973 => 
  array (
    '_id' => '婚后婚前房产证上加名字',
    'word' => '婚后婚前房产证上加名字',
    'hits' => 0,
    'score' => 0,
  ),
  974 => 
  array (
    '_id' => '婚前财产',
    'word' => '婚前财产',
    'hits' => 0,
    'score' => 0,
  ),
  975 => 
  array (
    '_id' => '婚前财产公证',
    'word' => '婚前财产公证',
    'hits' => 0,
    'score' => 0,
  ),
  976 => 
  array (
    '_id' => '婚前房产',
    'word' => '婚前房产',
    'hits' => 0,
    'score' => 0,
  ),
  977 => 
  array (
    '_id' => '婚前房产公证',
    'word' => '婚前房产公证',
    'hits' => 0,
    'score' => 0,
  ),
  978 => 
  array (
    '_id' => '婚姻法',
    'word' => '婚姻法',
    'hits' => 0,
    'score' => 0,
  ),
  979 => 
  array (
    '_id' => '婚姻法财产新规',
    'word' => '婚姻法财产新规',
    'hits' => 0,
    'score' => 0,
  ),
  980 => 
  array (
    '_id' => '婚姻法全文',
    'word' => '婚姻法全文',
    'hits' => 0,
    'score' => 0,
  ),
  981 => 
  array (
    '_id' => '婚姻法司法解释',
    'word' => '婚姻法司法解释',
    'hits' => 0,
    'score' => 0,
  ),
  982 => 
  array (
    '_id' => '混凝土浇筑',
    'word' => '混凝土浇筑',
    'hits' => 0,
    'score' => 0,
  ),
  983 => 
  array (
    '_id' => '混凝土结构设计',
    'word' => '混凝土结构设计',
    'hits' => 0,
    'score' => 0,
  ),
  984 => 
  array (
    '_id' => '混凝土密封固化剂',
    'word' => '混凝土密封固化剂',
    'hits' => 0,
    'score' => 0,
  ),
  985 => 
  array (
    '_id' => '混凝土配比',
    'word' => '混凝土配比',
    'hits' => 0,
    'score' => 0,
  ),
  986 => 
  array (
    '_id' => '混凝土养护',
    'word' => '混凝土养护',
    'hits' => 0,
    'score' => 0,
  ),
  987 => 
  array (
    '_id' => '混油和清油的区别',
    'word' => '混油和清油的区别',
    'hits' => 0,
    'score' => 0,
  ),
  988 => 
  array (
    '_id' => '活动屏风',
    'word' => '活动屏风',
    'hits' => 0,
    'score' => 0,
  ),
  989 => 
  array (
    '_id' => '货币补偿基准价',
    'word' => '货币补偿基准价',
    'hits' => 0,
    'score' => 0,
  ),
  990 => 
  array (
    '_id' => '货币政策',
    'word' => '货币政策',
    'hits' => 0,
    'score' => 0,
  ),
  991 => 
  array (
    '_id' => '货梯',
    'word' => '货梯',
    'hits' => 0,
    'score' => 0,
  ),
  992 => 
  array (
    '_id' => '霍尼韦尔净水器',
    'word' => '霍尼韦尔净水器',
    'hits' => 0,
    'score' => 0,
  ),
  993 => 
  array (
    '_id' => 'LOFT',
    'word' => 'LOFT',
    'hits' => 0,
    'score' => 0,
  ),
  994 => 
  array (
    '_id' => '柜式空调',
    'word' => '柜式空调',
    'hits' => 0,
    'score' => 0,
  ),
  995 => 
  array (
    '_id' => '鸡翅木家具',
    'word' => '鸡翅木家具',
    'hits' => 0,
    'score' => 0,
  ),
  996 => 
  array (
    '_id' => '鸡西公积金贷款',
    'word' => '鸡西公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  997 => 
  array (
    '_id' => '鸡西住房公积金查询',
    'word' => '鸡西住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  998 => 
  array (
    '_id' => '鸡西住房公积金提取',
    'word' => '鸡西住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  999 => 
  array (
    '_id' => '基本面',
    'word' => '基本面',
    'hits' => 0,
    'score' => 0,
  ),
  1000 => 
  array (
    '_id' => '基底面积',
    'word' => '基底面积',
    'hits' => 0,
    'score' => 0,
  ),
  1001 => 
  array (
    '_id' => '基价',
    'word' => '基价',
    'hits' => 0,
    'score' => 0,
  ),
  1002 => 
  array (
    '_id' => '基准地价',
    'word' => '基准地价',
    'hits' => 0,
    'score' => 0,
  ),
  1003 => 
  array (
    '_id' => '吉安住房公积金查询',
    'word' => '吉安住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1004 => 
  array (
    '_id' => '吉安住房公积金提取',
    'word' => '吉安住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1005 => 
  array (
    '_id' => '即热式电热水龙头',
    'word' => '即热式电热水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  1006 => 
  array (
    '_id' => '集成环保灶',
    'word' => '集成环保灶',
    'hits' => 0,
    'score' => 0,
  ),
  1007 => 
  array (
    '_id' => '集成浴霸',
    'word' => '集成浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  1008 => 
  array (
    '_id' => '集合竞价',
    'word' => '集合竞价',
    'hits' => 0,
    'score' => 0,
  ),
  1009 => 
  array (
    '_id' => '集体户口买房',
    'word' => '集体户口买房',
    'hits' => 0,
    'score' => 0,
  ),
  1010 => 
  array (
    '_id' => '集体建设用地',
    'word' => '集体建设用地',
    'hits' => 0,
    'score' => 0,
  ),
  1011 => 
  array (
    '_id' => '集体所有房产',
    'word' => '集体所有房产',
    'hits' => 0,
    'score' => 0,
  ),
  1012 => 
  array (
    '_id' => '集体土地',
    'word' => '集体土地',
    'hits' => 0,
    'score' => 0,
  ),
  1013 => 
  array (
    '_id' => '集体土地流转',
    'word' => '集体土地流转',
    'hits' => 0,
    'score' => 0,
  ),
  1014 => 
  array (
    '_id' => '集体土地使用权转让',
    'word' => '集体土地使用权转让',
    'hits' => 0,
    'score' => 0,
  ),
  1015 => 
  array (
    '_id' => '集体土地征收补偿',
    'word' => '集体土地征收补偿',
    'hits' => 0,
    'score' => 0,
  ),
  1016 => 
  array (
    '_id' => '集资房',
    'word' => '集资房',
    'hits' => 0,
    'score' => 0,
  ),
  1017 => 
  array (
    '_id' => '计算房贷',
    'word' => '计算房贷',
    'hits' => 0,
    'score' => 0,
  ),
  1018 => 
  array (
    '_id' => '济南住房公积金查询',
    'word' => '济南住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1019 => 
  array (
    '_id' => '济南住房公积金提取',
    'word' => '济南住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1020 => 
  array (
    '_id' => '济宁公积金贷款',
    'word' => '济宁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1021 => 
  array (
    '_id' => '济宁住房公积金查询',
    'word' => '济宁住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1022 => 
  array (
    '_id' => '济宁住房公积金提取',
    'word' => '济宁住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1023 => 
  array (
    '_id' => '济源住房公积金查询',
    'word' => '济源住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1024 => 
  array (
    '_id' => '继承法全文',
    'word' => '继承法全文',
    'hits' => 0,
    'score' => 0,
  ),
  1025 => 
  array (
    '_id' => '继承房产',
    'word' => '继承房产',
    'hits' => 0,
    'score' => 0,
  ),
  1026 => 
  array (
    '_id' => '继承过户费用',
    'word' => '继承过户费用',
    'hits' => 0,
    'score' => 0,
  ),
  1027 => 
  array (
    '_id' => '继承权公证书',
    'word' => '继承权公证书',
    'hits' => 0,
    'score' => 0,
  ),
  1028 => 
  array (
    '_id' => '加气混凝土砌块',
    'word' => '加气混凝土砌块',
    'hits' => 0,
    'score' => 0,
  ),
  1029 => 
  array (
    '_id' => '佳德水槽',
    'word' => '佳德水槽',
    'hits' => 0,
    'score' => 0,
  ),
  1030 => 
  array (
    '_id' => '佳木斯住房公积金提取',
    'word' => '佳木斯住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1031 => 
  array (
    '_id' => '家居风水摆件',
    'word' => '家居风水摆件',
    'hits' => 0,
    'score' => 0,
  ),
  1032 => 
  array (
    '_id' => '家居风水布局',
    'word' => '家居风水布局',
    'hits' => 0,
    'score' => 0,
  ),
  1033 => 
  array (
    '_id' => '家居风水禁忌大全',
    'word' => '家居风水禁忌大全',
    'hits' => 0,
    'score' => 0,
  ),
  1034 => 
  array (
    '_id' => '家居设计',
    'word' => '家居设计',
    'hits' => 0,
    'score' => 0,
  ),
  1035 => 
  array (
    '_id' => '家居装饰',
    'word' => '家居装饰',
    'hits' => 0,
    'score' => 0,
  ),
  1036 => 
  array (
    '_id' => '家居装修',
    'word' => '家居装修',
    'hits' => 0,
    'score' => 0,
  ),
  1037 => 
  array (
    '_id' => '家里镜子的摆放位置',
    'word' => '家里镜子的摆放位置',
    'hits' => 0,
    'score' => 0,
  ),
  1038 => 
  array (
    '_id' => '家庭装修步骤',
    'word' => '家庭装修步骤',
    'hits' => 0,
    'score' => 0,
  ),
  1039 => 
  array (
    '_id' => '家庭装修风格',
    'word' => '家庭装修风格',
    'hits' => 0,
    'score' => 0,
  ),
  1040 => 
  array (
    '_id' => '家宅风水',
    'word' => '家宅风水',
    'hits' => 0,
    'score' => 0,
  ),
  1041 => 
  array (
    '_id' => '家装背景墙',
    'word' => '家装背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  1042 => 
  array (
    '_id' => '家装材料清单',
    'word' => '家装材料清单',
    'hits' => 0,
    'score' => 0,
  ),
  1043 => 
  array (
    '_id' => '家装电工基础知识',
    'word' => '家装电工基础知识',
    'hits' => 0,
    'score' => 0,
  ),
  1044 => 
  array (
    '_id' => '家装电路施工图解',
    'word' => '家装电路施工图解',
    'hits' => 0,
    'score' => 0,
  ),
  1045 => 
  array (
    '_id' => '家装电线品牌',
    'word' => '家装电线品牌',
    'hits' => 0,
    'score' => 0,
  ),
  1046 => 
  array (
    '_id' => '家装风水学',
    'word' => '家装风水学',
    'hits' => 0,
    'score' => 0,
  ),
  1047 => 
  array (
    '_id' => '家装流程',
    'word' => '家装流程',
    'hits' => 0,
    'score' => 0,
  ),
  1048 => 
  array (
    '_id' => '家装水电改造价格',
    'word' => '家装水电改造价格',
    'hits' => 0,
    'score' => 0,
  ),
  1049 => 
  array (
    '_id' => '家装知识',
    'word' => '家装知识',
    'hits' => 0,
    'score' => 0,
  ),
  1050 => 
  array (
    '_id' => '家装知识入门',
    'word' => '家装知识入门',
    'hits' => 0,
    'score' => 0,
  ),
  1051 => 
  array (
    '_id' => '嘉宝莉漆',
    'word' => '嘉宝莉漆',
    'hits' => 0,
    'score' => 0,
  ),
  1052 => 
  array (
    '_id' => '嘉豪何室家具',
    'word' => '嘉豪何室家具',
    'hits' => 0,
    'score' => 0,
  ),
  1053 => 
  array (
    '_id' => '嘉丽士漆',
    'word' => '嘉丽士漆',
    'hits' => 0,
    'score' => 0,
  ),
  1054 => 
  array (
    '_id' => '嘉兴住房公积金查询',
    'word' => '嘉兴住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1055 => 
  array (
    '_id' => '嘉峪关住房公积金提取',
    'word' => '嘉峪关住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1056 => 
  array (
    '_id' => '假层',
    'word' => '假层',
    'hits' => 0,
    'score' => 0,
  ),
  1057 => 
  array (
    '_id' => '剪力墙',
    'word' => '剪力墙',
    'hits' => 0,
    'score' => 0,
  ),
  1058 => 
  array (
    '_id' => '剪力墙结构',
    'word' => '剪力墙结构',
    'hits' => 0,
    'score' => 0,
  ),
  1059 => 
  array (
    '_id' => '简单房屋租赁合同',
    'word' => '简单房屋租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  1060 => 
  array (
    '_id' => '简单租房协议书',
    'word' => '简单租房协议书',
    'hits' => 0,
    'score' => 0,
  ),
  1061 => 
  array (
    '_id' => '简欧风格简',
    'word' => '简欧风格简',
    'hits' => 0,
    'score' => 0,
  ),
  1062 => 
  array (
    '_id' => '简易淋浴房',
    'word' => '简易淋浴房',
    'hits' => 0,
    'score' => 0,
  ),
  1063 => 
  array (
    '_id' => '简易衣柜',
    'word' => '简易衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1064 => 
  array (
    '_id' => '简易租房协议书范本',
    'word' => '简易租房协议书范本',
    'hits' => 0,
    'score' => 0,
  ),
  1065 => 
  array (
    '_id' => '简约风格',
    'word' => '简约风格',
    'hits' => 0,
    'score' => 0,
  ),
  1066 => 
  array (
    '_id' => '建设产权证',
    'word' => '建设产权证',
    'hits' => 0,
    'score' => 0,
  ),
  1067 => 
  array (
    '_id' => '建设用地',
    'word' => '建设用地',
    'hits' => 0,
    'score' => 0,
  ),
  1068 => 
  array (
    '_id' => '建设用地分类',
    'word' => '建设用地分类',
    'hits' => 0,
    'score' => 0,
  ),
  1069 => 
  array (
    '_id' => '建设用地申请',
    'word' => '建设用地申请',
    'hits' => 0,
    'score' => 0,
  ),
  1070 => 
  array (
    '_id' => '建设用地审批',
    'word' => '建设用地审批',
    'hits' => 0,
    'score' => 0,
  ),
  1071 => 
  array (
    '_id' => '建筑风水',
    'word' => '建筑风水',
    'hits' => 0,
    'score' => 0,
  ),
  1072 => 
  array (
    '_id' => '建筑工程',
    'word' => '建筑工程',
    'hits' => 0,
    'score' => 0,
  ),
  1073 => 
  array (
    '_id' => '建筑工程建筑面积计算规范',
    'word' => '建筑工程建筑面积计算规范',
    'hits' => 0,
    'score' => 0,
  ),
  1074 => 
  array (
    '_id' => '建筑工程施工管理',
    'word' => '建筑工程施工管理',
    'hits' => 0,
    'score' => 0,
  ),
  1075 => 
  array (
    '_id' => '建筑工程施工手册',
    'word' => '建筑工程施工手册',
    'hits' => 0,
    'score' => 0,
  ),
  1076 => 
  array (
    '_id' => '建筑工程施工许可证',
    'word' => '建筑工程施工许可证',
    'hits' => 0,
    'score' => 0,
  ),
  1077 => 
  array (
    '_id' => '建筑工程识图',
    'word' => '建筑工程识图',
    'hits' => 0,
    'score' => 0,
  ),
  1078 => 
  array (
    '_id' => '建筑工程预算',
    'word' => '建筑工程预算',
    'hits' => 0,
    'score' => 0,
  ),
  1079 => 
  array (
    '_id' => '建筑工程质量管理',
    'word' => '建筑工程质量管理',
    'hits' => 0,
    'score' => 0,
  ),
  1080 => 
  array (
    '_id' => '建筑规范',
    'word' => '建筑规范',
    'hits' => 0,
    'score' => 0,
  ),
  1081 => 
  array (
    '_id' => '建筑胶',
    'word' => '建筑胶',
    'hits' => 0,
    'score' => 0,
  ),
  1082 => 
  array (
    '_id' => '建筑结构分类',
    'word' => '建筑结构分类',
    'hits' => 0,
    'score' => 0,
  ),
  1083 => 
  array (
    '_id' => '建筑结构荷载规范',
    'word' => '建筑结构荷载规范',
    'hits' => 0,
    'score' => 0,
  ),
  1084 => 
  array (
    '_id' => '建筑类型',
    'word' => '建筑类型',
    'hits' => 0,
    'score' => 0,
  ),
  1085 => 
  array (
    '_id' => '建筑密度',
    'word' => '建筑密度',
    'hits' => 0,
    'score' => 0,
  ),
  1086 => 
  array (
    '_id' => '建筑密度标准',
    'word' => '建筑密度标准',
    'hits' => 0,
    'score' => 0,
  ),
  1087 => 
  array (
    '_id' => '建筑面积',
    'word' => '建筑面积',
    'hits' => 0,
    'score' => 0,
  ),
  1088 => 
  array (
    '_id' => '建筑面积和使用面积',
    'word' => '建筑面积和使用面积',
    'hits' => 0,
    'score' => 0,
  ),
  1089 => 
  array (
    '_id' => '建筑面积计算',
    'word' => '建筑面积计算',
    'hits' => 0,
    'score' => 0,
  ),
  1090 => 
  array (
    '_id' => '建筑容积率',
    'word' => '建筑容积率',
    'hits' => 0,
    'score' => 0,
  ),
  1091 => 
  array (
    '_id' => '建筑设计',
    'word' => '建筑设计',
    'hits' => 0,
    'score' => 0,
  ),
  1092 => 
  array (
    '_id' => '建筑线',
    'word' => '建筑线',
    'hits' => 0,
    'score' => 0,
  ),
  1093 => 
  array (
    '_id' => '建筑形式',
    'word' => '建筑形式',
    'hits' => 0,
    'score' => 0,
  ),
  1094 => 
  array (
    '_id' => '建筑智能化',
    'word' => '建筑智能化',
    'hits' => 0,
    'score' => 0,
  ),
  1095 => 
  array (
    '_id' => '建筑总面积',
    'word' => '建筑总面积',
    'hits' => 0,
    'score' => 0,
  ),
  1096 => 
  array (
    '_id' => '箭牌瓷砖',
    'word' => '箭牌瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1097 => 
  array (
    '_id' => '箭牌淋浴房',
    'word' => '箭牌淋浴房',
    'hits' => 0,
    'score' => 0,
  ),
  1098 => 
  array (
    '_id' => '箭牌马桶',
    'word' => '箭牌马桶',
    'hits' => 0,
    'score' => 0,
  ),
  1099 => 
  array (
    '_id' => '箭牌衣柜',
    'word' => '箭牌衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1100 => 
  array (
    '_id' => '箭牌浴缸',
    'word' => '箭牌浴缸',
    'hits' => 0,
    'score' => 0,
  ),
  1101 => 
  array (
    '_id' => '江都公积金贷款',
    'word' => '江都公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1102 => 
  array (
    '_id' => '江都住房公积金查询',
    'word' => '江都住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1103 => 
  array (
    '_id' => '江都住房公积金提取',
    'word' => '江都住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1104 => 
  array (
    '_id' => '江门公积金贷款',
    'word' => '江门公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1105 => 
  array (
    '_id' => '江门住房公积金查询',
    'word' => '江门住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1106 => 
  array (
    '_id' => '江阴住房公积金查询',
    'word' => '江阴住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1107 => 
  array (
    '_id' => '江阴住房公积金提取',
    'word' => '江阴住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1108 => 
  array (
    '_id' => '交房',
    'word' => '交房',
    'hits' => 0,
    'score' => 0,
  ),
  1109 => 
  array (
    '_id' => '交房方案',
    'word' => '交房方案',
    'hits' => 0,
    'score' => 0,
  ),
  1110 => 
  array (
    '_id' => '交房费用',
    'word' => '交房费用',
    'hits' => 0,
    'score' => 0,
  ),
  1111 => 
  array (
    '_id' => '交房流程',
    'word' => '交房流程',
    'hits' => 0,
    'score' => 0,
  ),
  1112 => 
  array (
    '_id' => '交房时要交哪些费用',
    'word' => '交房时要交哪些费用',
    'hits' => 0,
    'score' => 0,
  ),
  1113 => 
  array (
    '_id' => '交房手续',
    'word' => '交房手续',
    'hits' => 0,
    'score' => 0,
  ),
  1114 => 
  array (
    '_id' => '交通配套',
    'word' => '交通配套',
    'hits' => 0,
    'score' => 0,
  ),
  1115 => 
  array (
    '_id' => '交印花税',
    'word' => '交印花税',
    'hits' => 0,
    'score' => 0,
  ),
  1116 => 
  array (
    '_id' => '焦作住房公积金查询',
    'word' => '焦作住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1117 => 
  array (
    '_id' => '教育配套',
    'word' => '教育配套',
    'hits' => 0,
    'score' => 0,
  ),
  1118 => 
  array (
    '_id' => '接房',
    'word' => '接房',
    'hits' => 0,
    'score' => 0,
  ),
  1119 => 
  array (
    '_id' => '揭阳住房公积金查询',
    'word' => '揭阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1120 => 
  array (
    '_id' => '揭阳住房公积金提取',
    'word' => '揭阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1121 => 
  array (
    '_id' => '节能灯',
    'word' => '节能灯',
    'hits' => 0,
    'score' => 0,
  ),
  1122 => 
  array (
    '_id' => '节能马桶',
    'word' => '节能马桶',
    'hits' => 0,
    'score' => 0,
  ),
  1123 => 
  array (
    '_id' => '结构',
    'word' => '结构',
    'hits' => 0,
    'score' => 0,
  ),
  1124 => 
  array (
    '_id' => '结构墙',
    'word' => '结构墙',
    'hits' => 0,
    'score' => 0,
  ),
  1125 => 
  array (
    '_id' => '捷欧插座',
    'word' => '捷欧插座',
    'hits' => 0,
    'score' => 0,
  ),
  1126 => 
  array (
    '_id' => '解困房',
    'word' => '解困房',
    'hits' => 0,
    'score' => 0,
  ),
  1127 => 
  array (
    '_id' => '金蝉窗帘',
    'word' => '金蝉窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  1128 => 
  array (
    '_id' => '金昌公积金贷款',
    'word' => '金昌公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1129 => 
  array (
    '_id' => '金昌住房公积金查询',
    'word' => '金昌住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1130 => 
  array (
    '_id' => '金朝阳瓷砖',
    'word' => '金朝阳瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1131 => 
  array (
    '_id' => '金虎家私',
    'word' => '金虎家私',
    'hits' => 0,
    'score' => 0,
  ),
  1132 => 
  array (
    '_id' => '金华住房公积金提取',
    'word' => '金华住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1133 => 
  array (
    '_id' => '金舰阳台窗',
    'word' => '金舰阳台窗',
    'hits' => 0,
    'score' => 0,
  ),
  1134 => 
  array (
    '_id' => '金羚浴霸',
    'word' => '金羚浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  1135 => 
  array (
    '_id' => '金宁床垫',
    'word' => '金宁床垫',
    'hits' => 0,
    'score' => 0,
  ),
  1136 => 
  array (
    '_id' => '金牌亚洲瓷砖',
    'word' => '金牌亚洲瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1137 => 
  array (
    '_id' => '金莎丽淋浴房',
    'word' => '金莎丽淋浴房',
    'hits' => 0,
    'score' => 0,
  ),
  1138 => 
  array (
    '_id' => '金属漆',
    'word' => '金属漆',
    'hits' => 0,
    'score' => 0,
  ),
  1139 => 
  array (
    '_id' => '锦州公积金贷款',
    'word' => '锦州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1140 => 
  array (
    '_id' => '锦州住房公积金查询',
    'word' => '锦州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1141 => 
  array (
    '_id' => '锦州住房公积金提取',
    'word' => '锦州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1142 => 
  array (
    '_id' => '进门玄关鞋柜',
    'word' => '进门玄关鞋柜',
    'hits' => 0,
    'score' => 0,
  ),
  1143 => 
  array (
    '_id' => '进深',
    'word' => '进深',
    'hits' => 0,
    'score' => 0,
  ),
  1144 => 
  array (
    '_id' => '晋城公积金贷款',
    'word' => '晋城公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1145 => 
  array (
    '_id' => '晋中住房公积金查询',
    'word' => '晋中住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1146 => 
  array (
    '_id' => '京兰床垫',
    'word' => '京兰床垫',
    'hits' => 0,
    'score' => 0,
  ),
  1147 => 
  array (
    '_id' => '经济适用房',
    'word' => '经济适用房',
    'hits' => 0,
    'score' => 0,
  ),
  1148 => 
  array (
    '_id' => '经济适用房贷款',
    'word' => '经济适用房贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1149 => 
  array (
    '_id' => '经济适用房和商品房的区别',
    'word' => '经济适用房和商品房的区别',
    'hits' => 0,
    'score' => 0,
  ),
  1150 => 
  array (
    '_id' => '经济适用房可以买卖吗',
    'word' => '经济适用房可以买卖吗',
    'hits' => 0,
    'score' => 0,
  ),
  1151 => 
  array (
    '_id' => '经济适用房申请',
    'word' => '经济适用房申请',
    'hits' => 0,
    'score' => 0,
  ),
  1152 => 
  array (
    '_id' => '经济适用房申请条件',
    'word' => '经济适用房申请条件',
    'hits' => 0,
    'score' => 0,
  ),
  1153 => 
  array (
    '_id' => '经济适用房转商品房',
    'word' => '经济适用房转商品房',
    'hits' => 0,
    'score' => 0,
  ),
  1154 => 
  array (
    '_id' => '经适房',
    'word' => '经适房',
    'hits' => 0,
    'score' => 0,
  ),
  1155 => 
  array (
    '_id' => '荆门公积金贷款',
    'word' => '荆门公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1156 => 
  array (
    '_id' => '荆门住房公积金查询',
    'word' => '荆门住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1157 => 
  array (
    '_id' => '荆门住房公积金提取',
    'word' => '荆门住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1158 => 
  array (
    '_id' => '荆州公积金贷款',
    'word' => '荆州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1159 => 
  array (
    '_id' => '荆州住房公积金查询',
    'word' => '荆州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1160 => 
  array (
    '_id' => '荆州住房公积金提取',
    'word' => '荆州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1161 => 
  array (
    '_id' => '精装房',
    'word' => '精装房',
    'hits' => 0,
    'score' => 0,
  ),
  1162 => 
  array (
    '_id' => '精装房收房注意事项',
    'word' => '精装房收房注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  1163 => 
  array (
    '_id' => '精装房验房注意事项',
    'word' => '精装房验房注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  1164 => 
  array (
    '_id' => '精装修验房',
    'word' => '精装修验房',
    'hits' => 0,
    'score' => 0,
  ),
  1165 => 
  array (
    '_id' => '井筒',
    'word' => '井筒',
    'hits' => 0,
    'score' => 0,
  ),
  1166 => 
  array (
    '_id' => '景德镇公积金贷款',
    'word' => '景德镇公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1167 => 
  array (
    '_id' => '景德镇住房公积金提取',
    'word' => '景德镇住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1168 => 
  array (
    '_id' => '景观',
    'word' => '景观',
    'hits' => 0,
    'score' => 0,
  ),
  1169 => 
  array (
    '_id' => '净高',
    'word' => '净高',
    'hits' => 0,
    'score' => 0,
  ),
  1170 => 
  array (
    '_id' => '净吸纳量',
    'word' => '净吸纳量',
    'hits' => 0,
    'score' => 0,
  ),
  1171 => 
  array (
    '_id' => '镜前灯',
    'word' => '镜前灯',
    'hits' => 0,
    'score' => 0,
  ),
  1172 => 
  array (
    '_id' => '九江公积金贷款',
    'word' => '九江公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1173 => 
  array (
    '_id' => '九棵松地板',
    'word' => '九棵松地板',
    'hits' => 0,
    'score' => 0,
  ),
  1174 => 
  array (
    '_id' => '久聚木门',
    'word' => '久聚木门',
    'hits' => 0,
    'score' => 0,
  ),
  1175 => 
  array (
    '_id' => '酒吧吧台',
    'word' => '酒吧吧台',
    'hits' => 0,
    'score' => 0,
  ),
  1176 => 
  array (
    '_id' => '酒店门锁',
    'word' => '酒店门锁',
    'hits' => 0,
    'score' => 0,
  ),
  1177 => 
  array (
    '_id' => '酒店式服务公寓',
    'word' => '酒店式服务公寓',
    'hits' => 0,
    'score' => 0,
  ),
  1178 => 
  array (
    '_id' => '酒店式公寓',
    'word' => '酒店式公寓',
    'hits' => 0,
    'score' => 0,
  ),
  1179 => 
  array (
    '_id' => '酒店租赁',
    'word' => '酒店租赁',
    'hits' => 0,
    'score' => 0,
  ),
  1180 => 
  array (
    '_id' => '酒柜设计',
    'word' => '酒柜设计',
    'hits' => 0,
    'score' => 0,
  ),
  1181 => 
  array (
    '_id' => '酒架',
    'word' => '酒架',
    'hits' => 0,
    'score' => 0,
  ),
  1182 => 
  array (
    '_id' => '酒泉公积金贷款',
    'word' => '酒泉公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1183 => 
  array (
    '_id' => '酒泉住房公积金查询',
    'word' => '酒泉住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1184 => 
  array (
    '_id' => '酒泉住房公积金提取',
    'word' => '酒泉住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1185 => 
  array (
    '_id' => '旧房改造',
    'word' => '旧房改造',
    'hits' => 0,
    'score' => 0,
  ),
  1186 => 
  array (
    '_id' => '旧房装修',
    'word' => '旧房装修',
    'hits' => 0,
    'score' => 0,
  ),
  1187 => 
  array (
    '_id' => '居家风水',
    'word' => '居家风水',
    'hits' => 0,
    'score' => 0,
  ),
  1188 => 
  array (
    '_id' => '居美印尚家具',
    'word' => '居美印尚家具',
    'hits' => 0,
    'score' => 0,
  ),
  1189 => 
  array (
    '_id' => '居梦莱家纺',
    'word' => '居梦莱家纺',
    'hits' => 0,
    'score' => 0,
  ),
  1190 => 
  array (
    '_id' => '居住面积',
    'word' => '居住面积',
    'hits' => 0,
    'score' => 0,
  ),
  1191 => 
  array (
    '_id' => '居住区用地',
    'word' => '居住区用地',
    'hits' => 0,
    'score' => 0,
  ),
  1192 => 
  array (
    '_id' => '居住小区',
    'word' => '居住小区',
    'hits' => 0,
    'score' => 0,
  ),
  1193 => 
  array (
    '_id' => '居住证',
    'word' => '居住证',
    'hits' => 0,
    'score' => 0,
  ),
  1194 => 
  array (
    '_id' => '聚氨酯保温管',
    'word' => '聚氨酯保温管',
    'hits' => 0,
    'score' => 0,
  ),
  1195 => 
  array (
    '_id' => '卷帘',
    'word' => '卷帘',
    'hits' => 0,
    'score' => 0,
  ),
  1196 => 
  array (
    '_id' => '绝缘胶垫',
    'word' => '绝缘胶垫',
    'hits' => 0,
    'score' => 0,
  ),
  1197 => 
  array (
    '_id' => '均价',
    'word' => '均价',
    'hits' => 0,
    'score' => 0,
  ),
  1198 => 
  array (
    '_id' => '骏牌地板',
    'word' => '骏牌地板',
    'hits' => 0,
    'score' => 0,
  ),
  1199 => 
  array (
    '_id' => '喀什住房公积金提取',
    'word' => '喀什住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1200 => 
  array (
    '_id' => '卡迪亚淋浴房',
    'word' => '卡迪亚淋浴房',
    'hits' => 0,
    'score' => 0,
  ),
  1201 => 
  array (
    '_id' => '卡恩诺卫浴',
    'word' => '卡恩诺卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  1202 => 
  array (
    '_id' => '卡尔玛地板',
    'word' => '卡尔玛地板',
    'hits' => 0,
    'score' => 0,
  ),
  1203 => 
  array (
    '_id' => '卡诺尔瓷砖',
    'word' => '卡诺尔瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1204 => 
  array (
    '_id' => '卡座沙发',
    'word' => '卡座沙发',
    'hits' => 0,
    'score' => 0,
  ),
  1205 => 
  array (
    '_id' => '开单身证明',
    'word' => '开单身证明',
    'hits' => 0,
    'score' => 0,
  ),
  1206 => 
  array (
    '_id' => '开发商',
    'word' => '开发商',
    'hits' => 0,
    'score' => 0,
  ),
  1207 => 
  array (
    '_id' => '开发商代办房产证',
    'word' => '开发商代办房产证',
    'hits' => 0,
    'score' => 0,
  ),
  1208 => 
  array (
    '_id' => '开发商垫资',
    'word' => '开发商垫资',
    'hits' => 0,
    'score' => 0,
  ),
  1209 => 
  array (
    '_id' => '开发商交房',
    'word' => '开发商交房',
    'hits' => 0,
    'score' => 0,
  ),
  1210 => 
  array (
    '_id' => '开发商交房条件',
    'word' => '开发商交房条件',
    'hits' => 0,
    'score' => 0,
  ),
  1211 => 
  array (
    '_id' => '开发商五证',
    'word' => '开发商五证',
    'hits' => 0,
    'score' => 0,
  ),
  1212 => 
  array (
    '_id' => '开发商延期交房',
    'word' => '开发商延期交房',
    'hits' => 0,
    'score' => 0,
  ),
  1213 => 
  array (
    '_id' => '开发中项目',
    'word' => '开发中项目',
    'hits' => 0,
    'score' => 0,
  ),
  1214 => 
  array (
    '_id' => '开放日',
    'word' => '开放日',
    'hits' => 0,
    'score' => 0,
  ),
  1215 => 
  array (
    '_id' => '开放式基金',
    'word' => '开放式基金',
    'hits' => 0,
    'score' => 0,
  ),
  1216 => 
  array (
    '_id' => '开封住房公积金提取',
    'word' => '开封住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1217 => 
  array (
    '_id' => '开关插座排名',
    'word' => '开关插座排名',
    'hits' => 0,
    'score' => 0,
  ),
  1218 => 
  array (
    '_id' => '开间',
    'word' => '开间',
    'hits' => 0,
    'score' => 0,
  ),
  1219 => 
  array (
    '_id' => '开间 进深',
    'word' => '开间 进深',
    'hits' => 0,
    'score' => 0,
  ),
  1220 => 
  array (
    '_id' => '开利空调',
    'word' => '开利空调',
    'hits' => 0,
    'score' => 0,
  ),
  1221 => 
  array (
    '_id' => '开晟橱柜',
    'word' => '开晟橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  1222 => 
  array (
    '_id' => '开元灯饰',
    'word' => '开元灯饰',
    'hits' => 0,
    'score' => 0,
  ),
  1223 => 
  array (
    '_id' => '凯鹰卫浴',
    'word' => '凯鹰卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  1224 => 
  array (
    '_id' => '楷模木门',
    'word' => '楷模木门',
    'hits' => 0,
    'score' => 0,
  ),
  1225 => 
  array (
    '_id' => '看跌期权',
    'word' => '看跌期权',
    'hits' => 0,
    'score' => 0,
  ),
  1226 => 
  array (
    '_id' => '康辉地板',
    'word' => '康辉地板',
    'hits' => 0,
    'score' => 0,
  ),
  1227 => 
  array (
    '_id' => '康佳冰箱',
    'word' => '康佳冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  1228 => 
  array (
    '_id' => '康泉热水器',
    'word' => '康泉热水器',
    'hits' => 0,
    'score' => 0,
  ),
  1229 => 
  array (
    '_id' => '抗渗混凝土',
    'word' => '抗渗混凝土',
    'hits' => 0,
    'score' => 0,
  ),
  1230 => 
  array (
    '_id' => '抗震钢筋',
    'word' => '抗震钢筋',
    'hits' => 0,
    'score' => 0,
  ),
  1231 => 
  array (
    '_id' => '抗震烈度',
    'word' => '抗震烈度',
    'hits' => 0,
    'score' => 0,
  ),
  1232 => 
  array (
    '_id' => '烤漆',
    'word' => '烤漆',
    'hits' => 0,
    'score' => 0,
  ),
  1233 => 
  array (
    '_id' => '科勒水槽',
    'word' => '科勒水槽',
    'hits' => 0,
    'score' => 0,
  ),
  1234 => 
  array (
    '_id' => '科勒卫浴',
    'word' => '科勒卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  1235 => 
  array (
    '_id' => '科勒浴缸',
    'word' => '科勒浴缸',
    'hits' => 0,
    'score' => 0,
  ),
  1236 => 
  array (
    '_id' => '科瑞莱空调',
    'word' => '科瑞莱空调',
    'hits' => 0,
    'score' => 0,
  ),
  1237 => 
  array (
    '_id' => '科翔墙纸',
    'word' => '科翔墙纸',
    'hits' => 0,
    'score' => 0,
  ),
  1238 => 
  array (
    '_id' => '科屹乐电热水龙头',
    'word' => '科屹乐电热水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  1239 => 
  array (
    '_id' => '颗粒板',
    'word' => '颗粒板',
    'hits' => 0,
    'score' => 0,
  ),
  1240 => 
  array (
    '_id' => '可出租面积',
    'word' => '可出租面积',
    'hits' => 0,
    'score' => 0,
  ),
  1241 => 
  array (
    '_id' => '可来博插座',
    'word' => '可来博插座',
    'hits' => 0,
    'score' => 0,
  ),
  1242 => 
  array (
    '_id' => '可视门铃',
    'word' => '可视门铃',
    'hits' => 0,
    'score' => 0,
  ),
  1243 => 
  array (
    '_id' => '可转换公司债券',
    'word' => '可转换公司债券',
    'hits' => 0,
    'score' => 0,
  ),
  1244 => 
  array (
    '_id' => '可转换证券',
    'word' => '可转换证券',
    'hits' => 0,
    'score' => 0,
  ),
  1245 => 
  array (
    '_id' => '克拉玛依住房公积金查询',
    'word' => '克拉玛依住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1246 => 
  array (
    '_id' => '客梯',
    'word' => '客梯',
    'hits' => 0,
    'score' => 0,
  ),
  1247 => 
  array (
    '_id' => '客厅窗帘',
    'word' => '客厅窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  1248 => 
  array (
    '_id' => '客厅灯',
    'word' => '客厅灯',
    'hits' => 0,
    'score' => 0,
  ),
  1249 => 
  array (
    '_id' => '客厅灯具',
    'word' => '客厅灯具',
    'hits' => 0,
    'score' => 0,
  ),
  1250 => 
  array (
    '_id' => '客厅灯具选择',
    'word' => '客厅灯具选择',
    'hits' => 0,
    'score' => 0,
  ),
  1251 => 
  array (
    '_id' => '客厅灯饰',
    'word' => '客厅灯饰',
    'hits' => 0,
    'score' => 0,
  ),
  1252 => 
  array (
    '_id' => '客厅地砖',
    'word' => '客厅地砖',
    'hits' => 0,
    'score' => 0,
  ),
  1253 => 
  array (
    '_id' => '客厅电视墙',
    'word' => '客厅电视墙',
    'hits' => 0,
    'score' => 0,
  ),
  1254 => 
  array (
    '_id' => '客厅吊顶',
    'word' => '客厅吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  1255 => 
  array (
    '_id' => '客厅风水',
    'word' => '客厅风水',
    'hits' => 0,
    'score' => 0,
  ),
  1256 => 
  array (
    '_id' => '客厅隔断',
    'word' => '客厅隔断',
    'hits' => 0,
    'score' => 0,
  ),
  1257 => 
  array (
    '_id' => '客厅设计',
    'word' => '客厅设计',
    'hits' => 0,
    'score' => 0,
  ),
  1258 => 
  array (
    '_id' => '客厅装饰',
    'word' => '客厅装饰',
    'hits' => 0,
    'score' => 0,
  ),
  1259 => 
  array (
    '_id' => '客厅装饰效果图',
    'word' => '客厅装饰效果图',
    'hits' => 0,
    'score' => 0,
  ),
  1260 => 
  array (
    '_id' => '客厅装修风水禁忌',
    'word' => '客厅装修风水禁忌',
    'hits' => 0,
    'score' => 0,
  ),
  1261 => 
  array (
    '_id' => '客厅组合沙发',
    'word' => '客厅组合沙发',
    'hits' => 0,
    'score' => 0,
  ),
  1262 => 
  array (
    '_id' => '空仓',
    'word' => '空仓',
    'hits' => 0,
    'score' => 0,
  ),
  1263 => 
  array (
    '_id' => '空仓观望',
    'word' => '空仓观望',
    'hits' => 0,
    'score' => 0,
  ),
  1264 => 
  array (
    '_id' => '空调安装方法及注意事项',
    'word' => '空调安装方法及注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  1265 => 
  array (
    '_id' => '空调插座',
    'word' => '空调插座',
    'hits' => 0,
    'score' => 0,
  ),
  1266 => 
  array (
    '_id' => '空气开关',
    'word' => '空气开关',
    'hits' => 0,
    'score' => 0,
  ),
  1267 => 
  array (
    '_id' => '空气流动',
    'word' => '空气流动',
    'hits' => 0,
    'score' => 0,
  ),
  1268 => 
  array (
    '_id' => '空头',
    'word' => '空头',
    'hits' => 0,
    'score' => 0,
  ),
  1269 => 
  array (
    '_id' => '空心砖',
    'word' => '空心砖',
    'hits' => 0,
    'score' => 0,
  ),
  1270 => 
  array (
    '_id' => '空置率',
    'word' => '空置率',
    'hits' => 0,
    'score' => 0,
  ),
  1271 => 
  array (
    '_id' => '空置面积',
    'word' => '空置面积',
    'hits' => 0,
    'score' => 0,
  ),
  1272 => 
  array (
    '_id' => '孔雀竹芋',
    'word' => '孔雀竹芋',
    'hits' => 0,
    'score' => 0,
  ),
  1273 => 
  array (
    '_id' => '快速卷帘门',
    'word' => '快速卷帘门',
    'hits' => 0,
    'score' => 0,
  ),
  1274 => 
  array (
    '_id' => '快速门',
    'word' => '快速门',
    'hits' => 0,
    'score' => 0,
  ),
  1275 => 
  array (
    '_id' => '矿棉板吊顶',
    'word' => '矿棉板吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  1276 => 
  array (
    '_id' => '框架结构',
    'word' => '框架结构',
    'hits' => 0,
    'score' => 0,
  ),
  1277 => 
  array (
    '_id' => '框架结构的特点',
    'word' => '框架结构的特点',
    'hits' => 0,
    'score' => 0,
  ),
  1278 => 
  array (
    '_id' => '昆明公积金贷款',
    'word' => '昆明公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1279 => 
  array (
    '_id' => '昆明住房公积金查询',
    'word' => '昆明住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1280 => 
  array (
    '_id' => '昆山住房公积金查询',
    'word' => '昆山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1281 => 
  array (
    '_id' => '昆山住房公积金提取',
    'word' => '昆山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1282 => 
  array (
    '_id' => '垃圾股',
    'word' => '垃圾股',
    'hits' => 0,
    'score' => 0,
  ),
  1283 => 
  array (
    '_id' => '垃圾债券',
    'word' => '垃圾债券',
    'hits' => 0,
    'score' => 0,
  ),
  1284 => 
  array (
    '_id' => '拉斐尔衣柜',
    'word' => '拉斐尔衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1285 => 
  array (
    '_id' => '拉萨住房公积金查询',
    'word' => '拉萨住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1286 => 
  array (
    '_id' => '拉萨住房公积金提取',
    'word' => '拉萨住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1287 => 
  array (
    '_id' => '腊梅',
    'word' => '腊梅',
    'hits' => 0,
    'score' => 0,
  ),
  1288 => 
  array (
    '_id' => '来宾住房公积金查询',
    'word' => '来宾住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1289 => 
  array (
    '_id' => '莱博顿淋浴房',
    'word' => '莱博顿淋浴房',
    'hits' => 0,
    'score' => 0,
  ),
  1290 => 
  array (
    '_id' => '莱芜公积金贷款',
    'word' => '莱芜公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1291 => 
  array (
    '_id' => '莱芜住房公积金查询',
    'word' => '莱芜住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1292 => 
  array (
    '_id' => '兰卡合页',
    'word' => '兰卡合页',
    'hits' => 0,
    'score' => 0,
  ),
  1293 => 
  array (
    '_id' => '兰卡威家具',
    'word' => '兰卡威家具',
    'hits' => 0,
    'score' => 0,
  ),
  1294 => 
  array (
    '_id' => '兰州公积金贷款',
    'word' => '兰州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1295 => 
  array (
    '_id' => '兰州经济适用房',
    'word' => '兰州经济适用房',
    'hits' => 0,
    'score' => 0,
  ),
  1296 => 
  array (
    '_id' => '兰州住房公积金查询',
    'word' => '兰州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1297 => 
  array (
    '_id' => '兰州住房公积金提取',
    'word' => '兰州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1298 => 
  array (
    '_id' => '蓝筹股',
    'word' => '蓝筹股',
    'hits' => 0,
    'score' => 0,
  ),
  1299 => 
  array (
    '_id' => '蓝姆特吊顶',
    'word' => '蓝姆特吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  1300 => 
  array (
    '_id' => '蓝石莲',
    'word' => '蓝石莲',
    'hits' => 0,
    'score' => 0,
  ),
  1301 => 
  array (
    '_id' => '蓝丝羽家纺',
    'word' => '蓝丝羽家纺',
    'hits' => 0,
    'score' => 0,
  ),
  1302 => 
  array (
    '_id' => '蓝藤卫浴',
    'word' => '蓝藤卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  1303 => 
  array (
    '_id' => '烂尾房',
    'word' => '烂尾房',
    'hits' => 0,
    'score' => 0,
  ),
  1304 => 
  array (
    '_id' => '廊坊公积金贷款',
    'word' => '廊坊公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1305 => 
  array (
    '_id' => '廊坊住房公积金查询',
    'word' => '廊坊住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1306 => 
  array (
    '_id' => '朗瑞特门铃',
    'word' => '朗瑞特门铃',
    'hits' => 0,
    'score' => 0,
  ),
  1307 => 
  array (
    '_id' => '朗斯淋浴房',
    'word' => '朗斯淋浴房',
    'hits' => 0,
    'score' => 0,
  ),
  1308 => 
  array (
    '_id' => '浪度家私',
    'word' => '浪度家私',
    'hits' => 0,
    'score' => 0,
  ),
  1309 => 
  array (
    '_id' => '浪鲸马桶',
    'word' => '浪鲸马桶',
    'hits' => 0,
    'score' => 0,
  ),
  1310 => 
  array (
    '_id' => '乐谷五金',
    'word' => '乐谷五金',
    'hits' => 0,
    'score' => 0,
  ),
  1311 => 
  array (
    '_id' => '乐华电视',
    'word' => '乐华电视',
    'hits' => 0,
    'score' => 0,
  ),
  1312 => 
  array (
    '_id' => '乐家居陶瓷',
    'word' => '乐家居陶瓷',
    'hits' => 0,
    'score' => 0,
  ),
  1313 => 
  array (
    '_id' => '乐迈地板',
    'word' => '乐迈地板',
    'hits' => 0,
    'score' => 0,
  ),
  1314 => 
  array (
    '_id' => '乐山公积金贷款',
    'word' => '乐山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1315 => 
  array (
    '_id' => '乐山住房公积金提取',
    'word' => '乐山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1316 => 
  array (
    '_id' => '乐视电视',
    'word' => '乐视电视',
    'hits' => 0,
    'score' => 0,
  ),
  1317 => 
  array (
    '_id' => '雷士浴霸',
    'word' => '雷士浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  1318 => 
  array (
    '_id' => '冷门股',
    'word' => '冷门股',
    'hits' => 0,
    'score' => 0,
  ),
  1319 => 
  array (
    '_id' => '冷热水龙头',
    'word' => '冷热水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  1320 => 
  array (
    '_id' => '冷轧带肋钢筋',
    'word' => '冷轧带肋钢筋',
    'hits' => 0,
    'score' => 0,
  ),
  1321 => 
  array (
    '_id' => '离场',
    'word' => '离场',
    'hits' => 0,
    'score' => 0,
  ),
  1322 => 
  array (
    '_id' => '离婚房产分割',
    'word' => '离婚房产分割',
    'hits' => 0,
    'score' => 0,
  ),
  1323 => 
  array (
    '_id' => '离婚房产如何分割',
    'word' => '离婚房产如何分割',
    'hits' => 0,
    'score' => 0,
  ),
  1324 => 
  array (
    '_id' => '力成五金',
    'word' => '力成五金',
    'hits' => 0,
    'score' => 0,
  ),
  1325 => 
  array (
    '_id' => '丽江公积金贷款',
    'word' => '丽江公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1326 => 
  array (
    '_id' => '丽娜地毯',
    'word' => '丽娜地毯',
    'hits' => 0,
    'score' => 0,
  ),
  1327 => 
  array (
    '_id' => '丽水住房公积金查询',
    'word' => '丽水住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1328 => 
  array (
    '_id' => '丽星家具',
    'word' => '丽星家具',
    'hits' => 0,
    'score' => 0,
  ),
  1329 => 
  array (
    '_id' => '利多',
    'word' => '利多',
    'hits' => 0,
    'score' => 0,
  ),
  1330 => 
  array (
    '_id' => '利客迈照明',
    'word' => '利客迈照明',
    'hits' => 0,
    'score' => 0,
  ),
  1331 => 
  array (
    '_id' => '利空',
    'word' => '利空',
    'hits' => 0,
    'score' => 0,
  ),
  1332 => 
  array (
    '_id' => '利空出尽',
    'word' => '利空出尽',
    'hits' => 0,
    'score' => 0,
  ),
  1333 => 
  array (
    '_id' => '利率底',
    'word' => '利率底',
    'hits' => 0,
    'score' => 0,
  ),
  1334 => 
  array (
    '_id' => '利率顶',
    'word' => '利率顶',
    'hits' => 0,
    'score' => 0,
  ),
  1335 => 
  array (
    '_id' => '利率期货',
    'word' => '利率期货',
    'hits' => 0,
    'score' => 0,
  ),
  1336 => 
  array (
    '_id' => '利息怎么算的',
    'word' => '利息怎么算的',
    'hits' => 0,
    'score' => 0,
  ),
  1337 => 
  array (
    '_id' => '沥青混凝土',
    'word' => '沥青混凝土',
    'hits' => 0,
    'score' => 0,
  ),
  1338 => 
  array (
    '_id' => '连续竞价',
    'word' => '连续竞价',
    'hits' => 0,
    'score' => 0,
  ),
  1339 => 
  array (
    '_id' => '连云港住房公积金提取',
    'word' => '连云港住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1340 => 
  array (
    '_id' => '联邦高登衣柜',
    'word' => '联邦高登衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1341 => 
  array (
    '_id' => '联邦家居',
    'word' => '联邦家居',
    'hits' => 0,
    'score' => 0,
  ),
  1342 => 
  array (
    '_id' => '联排别墅',
    'word' => '联排别墅',
    'hits' => 0,
    'score' => 0,
  ),
  1343 => 
  array (
    '_id' => '联想电视',
    'word' => '联想电视',
    'hits' => 0,
    'score' => 0,
  ),
  1344 => 
  array (
    '_id' => '廉租房',
    'word' => '廉租房',
    'hits' => 0,
    'score' => 0,
  ),
  1345 => 
  array (
    '_id' => '廉租房可以买吗',
    'word' => '廉租房可以买吗',
    'hits' => 0,
    'score' => 0,
  ),
  1346 => 
  array (
    '_id' => '廉租房申请书',
    'word' => '廉租房申请书',
    'hits' => 0,
    'score' => 0,
  ),
  1347 => 
  array (
    '_id' => '廉租屋',
    'word' => '廉租屋',
    'hits' => 0,
    'score' => 0,
  ),
  1348 => 
  array (
    '_id' => '廉租住房',
    'word' => '廉租住房',
    'hits' => 0,
    'score' => 0,
  ),
  1349 => 
  array (
    '_id' => '凉山住房公积金查询',
    'word' => '凉山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1350 => 
  array (
    '_id' => '两地上市',
    'word' => '两地上市',
    'hits' => 0,
    'score' => 0,
  ),
  1351 => 
  array (
    '_id' => '两书',
    'word' => '两书',
    'hits' => 0,
    'score' => 0,
  ),
  1352 => 
  array (
    '_id' => '量比',
    'word' => '量比',
    'hits' => 0,
    'score' => 0,
  ),
  1353 => 
  array (
    '_id' => '量房技巧',
    'word' => '量房技巧',
    'hits' => 0,
    'score' => 0,
  ),
  1354 => 
  array (
    '_id' => '辽源住房公积金查询',
    'word' => '辽源住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1355 => 
  array (
    '_id' => '辽源住房公积金提取',
    'word' => '辽源住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1356 => 
  array (
    '_id' => '聊城公积金贷款',
    'word' => '聊城公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1357 => 
  array (
    '_id' => '聊城住房公积金查询',
    'word' => '聊城住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1358 => 
  array (
    '_id' => '林内燃气热水器',
    'word' => '林内燃气热水器',
    'hits' => 0,
    'score' => 0,
  ),
  1359 => 
  array (
    '_id' => '林芝住房公积金查询',
    'word' => '林芝住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1360 => 
  array (
    '_id' => '林芝住房公积金提取',
    'word' => '林芝住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1361 => 
  array (
    '_id' => '临沧公积金贷款',
    'word' => '临沧公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1362 => 
  array (
    '_id' => '临沧住房公积金查询',
    'word' => '临沧住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1363 => 
  array (
    '_id' => '临汾公积金贷款',
    'word' => '临汾公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1364 => 
  array (
    '_id' => '临汾住房公积金提取',
    'word' => '临汾住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1365 => 
  array (
    '_id' => '临街',
    'word' => '临街',
    'hits' => 0,
    'score' => 0,
  ),
  1366 => 
  array (
    '_id' => '临夏公积金贷款',
    'word' => '临夏公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1367 => 
  array (
    '_id' => '临沂公积金贷款',
    'word' => '临沂公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1368 => 
  array (
    '_id' => '临沂住房公积金提取',
    'word' => '临沂住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1369 => 
  array (
    '_id' => '陵水公积金贷款',
    'word' => '陵水公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1370 => 
  array (
    '_id' => '陵水住房公积金查询',
    'word' => '陵水住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1371 => 
  array (
    '_id' => '零股交易',
    'word' => '零股交易',
    'hits' => 0,
    'score' => 0,
  ),
  1372 => 
  array (
    '_id' => '零距离地板',
    'word' => '零距离地板',
    'hits' => 0,
    'score' => 0,
  ),
  1373 => 
  array (
    '_id' => '零首付买房',
    'word' => '零首付买房',
    'hits' => 0,
    'score' => 0,
  ),
  1374 => 
  array (
    '_id' => '流通市值',
    'word' => '流通市值',
    'hits' => 0,
    'score' => 0,
  ),
  1375 => 
  array (
    '_id' => '柳州公积金贷款',
    'word' => '柳州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1376 => 
  array (
    '_id' => '柳州住房公积金查询',
    'word' => '柳州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1377 => 
  array (
    '_id' => '柳州住房公积金提取',
    'word' => '柳州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1378 => 
  array (
    '_id' => '六安住房公积金查询',
    'word' => '六安住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1379 => 
  array (
    '_id' => '六安住房公积金提取',
    'word' => '六安住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1380 => 
  array (
    '_id' => '六盘水住房公积金提取',
    'word' => '六盘水住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1381 => 
  array (
    '_id' => '龙华窗帘',
    'word' => '龙华窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  1382 => 
  array (
    '_id' => '龙甲木门',
    'word' => '龙甲木门',
    'hits' => 0,
    'score' => 0,
  ),
  1383 => 
  array (
    '_id' => '龙舌兰',
    'word' => '龙舌兰',
    'hits' => 0,
    'score' => 0,
  ),
  1384 => 
  array (
    '_id' => '龙头股',
    'word' => '龙头股',
    'hits' => 0,
    'score' => 0,
  ),
  1385 => 
  array (
    '_id' => '龙王球',
    'word' => '龙王球',
    'hits' => 0,
    'score' => 0,
  ),
  1386 => 
  array (
    '_id' => '龙血树',
    'word' => '龙血树',
    'hits' => 0,
    'score' => 0,
  ),
  1387 => 
  array (
    '_id' => '龙岩住房公积金提取',
    'word' => '龙岩住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1388 => 
  array (
    '_id' => '龙阳防盗门',
    'word' => '龙阳防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  1389 => 
  array (
    '_id' => '龙债券',
    'word' => '龙债券',
    'hits' => 0,
    'score' => 0,
  ),
  1390 => 
  array (
    '_id' => '陇南公积金贷款',
    'word' => '陇南公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1391 => 
  array (
    '_id' => '陇南住房公积金查询',
    'word' => '陇南住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1392 => 
  array (
    '_id' => '娄底住房公积金查询',
    'word' => '娄底住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1393 => 
  array (
    '_id' => '娄底住房公积金提取',
    'word' => '娄底住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1394 => 
  array (
    '_id' => '楼层指示',
    'word' => '楼层指示',
    'hits' => 0,
    'score' => 0,
  ),
  1395 => 
  array (
    '_id' => '楼顶漏水',
    'word' => '楼顶漏水',
    'hits' => 0,
    'score' => 0,
  ),
  1396 => 
  array (
    '_id' => '楼房层高',
    'word' => '楼房层高',
    'hits' => 0,
    'score' => 0,
  ),
  1397 => 
  array (
    '_id' => '楼房风水学',
    'word' => '楼房风水学',
    'hits' => 0,
    'score' => 0,
  ),
  1398 => 
  array (
    '_id' => '楼花',
    'word' => '楼花',
    'hits' => 0,
    'score' => 0,
  ),
  1399 => 
  array (
    '_id' => '楼龙防盗门',
    'word' => '楼龙防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  1400 => 
  array (
    '_id' => '楼面地价',
    'word' => '楼面地价',
    'hits' => 0,
    'score' => 0,
  ),
  1401 => 
  array (
    '_id' => '楼面价',
    'word' => '楼面价',
    'hits' => 0,
    'score' => 0,
  ),
  1402 => 
  array (
    '_id' => '楼盘配套',
    'word' => '楼盘配套',
    'hits' => 0,
    'score' => 0,
  ),
  1403 => 
  array (
    '_id' => '楼市拐点',
    'word' => '楼市拐点',
    'hits' => 0,
    'score' => 0,
  ),
  1404 => 
  array (
    '_id' => '楼市降价',
    'word' => '楼市降价',
    'hits' => 0,
    'score' => 0,
  ),
  1405 => 
  array (
    '_id' => '楼市泡沫',
    'word' => '楼市泡沫',
    'hits' => 0,
    'score' => 0,
  ),
  1406 => 
  array (
    '_id' => '楼市走向',
    'word' => '楼市走向',
    'hits' => 0,
    'score' => 0,
  ),
  1407 => 
  array (
    '_id' => '楼宇智能化技术',
    'word' => '楼宇智能化技术',
    'hits' => 0,
    'score' => 0,
  ),
  1408 => 
  array (
    '_id' => '露台',
    'word' => '露台',
    'hits' => 0,
    'score' => 0,
  ),
  1409 => 
  array (
    '_id' => '露台花园',
    'word' => '露台花园',
    'hits' => 0,
    'score' => 0,
  ),
  1410 => 
  array (
    '_id' => '芦荟',
    'word' => '芦荟',
    'hits' => 0,
    'score' => 0,
  ),
  1411 => 
  array (
    '_id' => '泸州公积金贷款',
    'word' => '泸州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1412 => 
  array (
    '_id' => '泸州住房公积金提取',
    'word' => '泸州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1413 => 
  array (
    '_id' => '路透系统',
    'word' => '路透系统',
    'hits' => 0,
    'score' => 0,
  ),
  1414 => 
  array (
    '_id' => '吕梁公积金贷款',
    'word' => '吕梁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1415 => 
  array (
    '_id' => '吕梁住房公积金查询',
    'word' => '吕梁住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1416 => 
  array (
    '_id' => '铝材',
    'word' => '铝材',
    'hits' => 0,
    'score' => 0,
  ),
  1417 => 
  array (
    '_id' => '铝合金窗',
    'word' => '铝合金窗',
    'hits' => 0,
    'score' => 0,
  ),
  1418 => 
  array (
    '_id' => '铝合金隔断',
    'word' => '铝合金隔断',
    'hits' => 0,
    'score' => 0,
  ),
  1419 => 
  array (
    '_id' => '铝合金门',
    'word' => '铝合金门',
    'hits' => 0,
    'score' => 0,
  ),
  1420 => 
  array (
    '_id' => '铝合金门窗价格',
    'word' => '铝合金门窗价格',
    'hits' => 0,
    'score' => 0,
  ),
  1421 => 
  array (
    '_id' => '铝塑板',
    'word' => '铝塑板',
    'hits' => 0,
    'score' => 0,
  ),
  1422 => 
  array (
    '_id' => '铝塑复合管',
    'word' => '铝塑复合管',
    'hits' => 0,
    'score' => 0,
  ),
  1423 => 
  array (
    '_id' => '绿宝',
    'word' => '绿宝',
    'hits' => 0,
    'score' => 0,
  ),
  1424 => 
  array (
    '_id' => '绿地率',
    'word' => '绿地率',
    'hits' => 0,
    'score' => 0,
  ),
  1425 => 
  array (
    '_id' => '绿地率和绿化率的区别',
    'word' => '绿地率和绿化率的区别',
    'hits' => 0,
    'score' => 0,
  ),
  1426 => 
  array (
    '_id' => '绿化工程',
    'word' => '绿化工程',
    'hits' => 0,
    'score' => 0,
  ),
  1427 => 
  array (
    '_id' => '绿化率',
    'word' => '绿化率',
    'hits' => 0,
    'score' => 0,
  ),
  1428 => 
  array (
    '_id' => '绿幽灵',
    'word' => '绿幽灵',
    'hits' => 0,
    'score' => 0,
  ),
  1429 => 
  array (
    '_id' => '伦灯灯饰',
    'word' => '伦灯灯饰',
    'hits' => 0,
    'score' => 0,
  ),
  1430 => 
  array (
    '_id' => '伦敦金融时报指数',
    'word' => '伦敦金融时报指数',
    'hits' => 0,
    'score' => 0,
  ),
  1431 => 
  array (
    '_id' => '罗尔思插座',
    'word' => '罗尔思插座',
    'hits' => 0,
    'score' => 0,
  ),
  1432 => 
  array (
    '_id' => '罗卡淋浴房',
    'word' => '罗卡淋浴房',
    'hits' => 0,
    'score' => 0,
  ),
  1433 => 
  array (
    '_id' => '罗莱儿童家纺',
    'word' => '罗莱儿童家纺',
    'hits' => 0,
    'score' => 0,
  ),
  1434 => 
  array (
    '_id' => '罗莱家纺',
    'word' => '罗莱家纺',
    'hits' => 0,
    'score' => 0,
  ),
  1435 => 
  array (
    '_id' => '罗兰衣柜',
    'word' => '罗兰衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1436 => 
  array (
    '_id' => '罗玛鼎水槽',
    'word' => '罗玛鼎水槽',
    'hits' => 0,
    'score' => 0,
  ),
  1437 => 
  array (
    '_id' => '罗曼迪卡家具',
    'word' => '罗曼迪卡家具',
    'hits' => 0,
    'score' => 0,
  ),
  1438 => 
  array (
    '_id' => '罗曼蒂克瓷砖',
    'word' => '罗曼蒂克瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1439 => 
  array (
    '_id' => '洛可可瓷砖',
    'word' => '洛可可瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1440 => 
  array (
    '_id' => '洛阳公积金贷款',
    'word' => '洛阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1441 => 
  array (
    '_id' => '骆驼油漆',
    'word' => '骆驼油漆',
    'hits' => 0,
    'score' => 0,
  ),
  1442 => 
  array (
    '_id' => '落架重修',
    'word' => '落架重修',
    'hits' => 0,
    'score' => 0,
  ),
  1443 => 
  array (
    '_id' => '漯河公积金贷款',
    'word' => '漯河公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1444 => 
  array (
    '_id' => '漯河住房公积金查询',
    'word' => '漯河住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1445 => 
  array (
    '_id' => 'PP材料',
    'word' => 'PP材料',
    'hits' => 0,
    'score' => 0,
  ),
  1446 => 
  array (
    '_id' => '马鞍山公积金贷款',
    'word' => '马鞍山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1447 => 
  array (
    '_id' => '马赛克瓷砖',
    'word' => '马赛克瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1448 => 
  array (
    '_id' => '马赛克电视背景墙',
    'word' => '马赛克电视背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  1449 => 
  array (
    '_id' => '马桶堵塞',
    'word' => '马桶堵塞',
    'hits' => 0,
    'score' => 0,
  ),
  1450 => 
  array (
    '_id' => '马桶盖',
    'word' => '马桶盖',
    'hits' => 0,
    'score' => 0,
  ),
  1451 => 
  array (
    '_id' => '马桶盖怎么换',
    'word' => '马桶盖怎么换',
    'hits' => 0,
    'score' => 0,
  ),
  1452 => 
  array (
    '_id' => '马桶构造',
    'word' => '马桶构造',
    'hits' => 0,
    'score' => 0,
  ),
  1453 => 
  array (
    '_id' => '马桶结构',
    'word' => '马桶结构',
    'hits' => 0,
    'score' => 0,
  ),
  1454 => 
  array (
    '_id' => '马桶漏水',
    'word' => '马桶漏水',
    'hits' => 0,
    'score' => 0,
  ),
  1455 => 
  array (
    '_id' => '马桶疏通器',
    'word' => '马桶疏通器',
    'hits' => 0,
    'score' => 0,
  ),
  1456 => 
  array (
    '_id' => '马桶水箱配件',
    'word' => '马桶水箱配件',
    'hits' => 0,
    'score' => 0,
  ),
  1457 => 
  array (
    '_id' => '马桶移位器',
    'word' => '马桶移位器',
    'hits' => 0,
    'score' => 0,
  ),
  1458 => 
  array (
    '_id' => '玛瑙',
    'word' => '玛瑙',
    'hits' => 0,
    'score' => 0,
  ),
  1459 => 
  array (
    '_id' => '玛尚壁纸',
    'word' => '玛尚壁纸',
    'hits' => 0,
    'score' => 0,
  ),
  1460 => 
  array (
    '_id' => '买二手房贷款流程',
    'word' => '买二手房贷款流程',
    'hits' => 0,
    'score' => 0,
  ),
  1461 => 
  array (
    '_id' => '买二手房好吗',
    'word' => '买二手房好吗',
    'hits' => 0,
    'score' => 0,
  ),
  1462 => 
  array (
    '_id' => '买二手房交税',
    'word' => '买二手房交税',
    'hits' => 0,
    'score' => 0,
  ),
  1463 => 
  array (
    '_id' => '买二手房可以贷款吗',
    'word' => '买二手房可以贷款吗',
    'hits' => 0,
    'score' => 0,
  ),
  1464 => 
  array (
    '_id' => '买二手房流程',
    'word' => '买二手房流程',
    'hits' => 0,
    'score' => 0,
  ),
  1465 => 
  array (
    '_id' => '买二手房要注意什么',
    'word' => '买二手房要注意什么',
    'hits' => 0,
    'score' => 0,
  ),
  1466 => 
  array (
    '_id' => '买房常识',
    'word' => '买房常识',
    'hits' => 0,
    'score' => 0,
  ),
  1467 => 
  array (
    '_id' => '买房风水注意事项',
    'word' => '买房风水注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  1468 => 
  array (
    '_id' => '买房合同',
    'word' => '买房合同',
    'hits' => 0,
    'score' => 0,
  ),
  1469 => 
  array (
    '_id' => '买房交定金注意事项',
    'word' => '买房交定金注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  1470 => 
  array (
    '_id' => '买房流程',
    'word' => '买房流程',
    'hits' => 0,
    'score' => 0,
  ),
  1471 => 
  array (
    '_id' => '买房排号',
    'word' => '买房排号',
    'hits' => 0,
    'score' => 0,
  ),
  1472 => 
  array (
    '_id' => '买房迁户口',
    'word' => '买房迁户口',
    'hits' => 0,
    'score' => 0,
  ),
  1473 => 
  array (
    '_id' => '买房证件',
    'word' => '买房证件',
    'hits' => 0,
    'score' => 0,
  ),
  1474 => 
  array (
    '_id' => '买房子交税',
    'word' => '买房子交税',
    'hits' => 0,
    'score' => 0,
  ),
  1475 => 
  array (
    '_id' => '买房子首付多少',
    'word' => '买房子首付多少',
    'hits' => 0,
    'score' => 0,
  ),
  1476 => 
  array (
    '_id' => '买房子注意事项',
    'word' => '买房子注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  1477 => 
  array (
    '_id' => '买高层楼房几层最好',
    'word' => '买高层楼房几层最好',
    'hits' => 0,
    'score' => 0,
  ),
  1478 => 
  array (
    '_id' => '买壳上市',
    'word' => '买壳上市',
    'hits' => 0,
    'score' => 0,
  ),
  1479 => 
  array (
    '_id' => '买空',
    'word' => '买空',
    'hits' => 0,
    'score' => 0,
  ),
  1480 => 
  array (
    '_id' => '买卖二手房税',
    'word' => '买卖二手房税',
    'hits' => 0,
    'score' => 0,
  ),
  1481 => 
  array (
    '_id' => '买卖房屋',
    'word' => '买卖房屋',
    'hits' => 0,
    'score' => 0,
  ),
  1482 => 
  array (
    '_id' => '卖房流程',
    'word' => '卖房流程',
    'hits' => 0,
    'score' => 0,
  ),
  1483 => 
  array (
    '_id' => '卖房税费',
    'word' => '卖房税费',
    'hits' => 0,
    'score' => 0,
  ),
  1484 => 
  array (
    '_id' => '满仓',
    'word' => '满仓',
    'hits' => 0,
    'score' => 0,
  ),
  1485 => 
  array (
    '_id' => '毛地',
    'word' => '毛地',
    'hits' => 0,
    'score' => 0,
  ),
  1486 => 
  array (
    '_id' => '毛胚房验房',
    'word' => '毛胚房验房',
    'hits' => 0,
    'score' => 0,
  ),
  1487 => 
  array (
    '_id' => '毛坯房交房标准',
    'word' => '毛坯房交房标准',
    'hits' => 0,
    'score' => 0,
  ),
  1488 => 
  array (
    '_id' => '茂名公积金贷款',
    'word' => '茂名公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1489 => 
  array (
    '_id' => '茂名住房公积金查询',
    'word' => '茂名住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1490 => 
  array (
    '_id' => '没有房产证',
    'word' => '没有房产证',
    'hits' => 0,
    'score' => 0,
  ),
  1491 => 
  array (
    '_id' => '眉山公积金贷款',
    'word' => '眉山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1492 => 
  array (
    '_id' => '眉山住房公积金提取',
    'word' => '眉山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1493 => 
  array (
    '_id' => '梅州公积金贷款',
    'word' => '梅州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1494 => 
  array (
    '_id' => '梅州住房公积金查询',
    'word' => '梅州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1495 => 
  array (
    '_id' => '梅州住房公积金提取',
    'word' => '梅州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1496 => 
  array (
    '_id' => '煤气报警器',
    'word' => '煤气报警器',
    'hits' => 0,
    'score' => 0,
  ),
  1497 => 
  array (
    '_id' => '每股税后利润',
    'word' => '每股税后利润',
    'hits' => 0,
    'score' => 0,
  ),
  1498 => 
  array (
    '_id' => '美标马桶',
    'word' => '美标马桶',
    'hits' => 0,
    'score' => 0,
  ),
  1499 => 
  array (
    '_id' => '美标卫浴',
    'word' => '美标卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  1500 => 
  array (
    '_id' => '美巢腻子',
    'word' => '美巢腻子',
    'hits' => 0,
    'score' => 0,
  ),
  1501 => 
  array (
    '_id' => '美的插座',
    'word' => '美的插座',
    'hits' => 0,
    'score' => 0,
  ),
  1502 => 
  array (
    '_id' => '美的热水器',
    'word' => '美的热水器',
    'hits' => 0,
    'score' => 0,
  ),
  1503 => 
  array (
    '_id' => '美的洗衣机',
    'word' => '美的洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  1504 => 
  array (
    '_id' => '美的浴霸',
    'word' => '美的浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  1505 => 
  array (
    '_id' => '美帝合页',
    'word' => '美帝合页',
    'hits' => 0,
    'score' => 0,
  ),
  1506 => 
  array (
    '_id' => '美国房产税',
    'word' => '美国房产税',
    'hits' => 0,
    'score' => 0,
  ),
  1507 => 
  array (
    '_id' => '美国购房',
    'word' => '美国购房',
    'hits' => 0,
    'score' => 0,
  ),
  1508 => 
  array (
    '_id' => '美赫集成吊顶',
    'word' => '美赫集成吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  1509 => 
  array (
    '_id' => '美克之都卫浴',
    'word' => '美克之都卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  1510 => 
  array (
    '_id' => '美乐电视',
    'word' => '美乐电视',
    'hits' => 0,
    'score' => 0,
  ),
  1511 => 
  array (
    '_id' => '美菱吊顶',
    'word' => '美菱吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  1512 => 
  array (
    '_id' => '美菱防盗门',
    'word' => '美菱防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  1513 => 
  array (
    '_id' => '美琦丽橱柜',
    'word' => '美琦丽橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  1514 => 
  array (
    '_id' => '美式家具',
    'word' => '美式家具',
    'hits' => 0,
    'score' => 0,
  ),
  1515 => 
  array (
    '_id' => '美式期权',
    'word' => '美式期权',
    'hits' => 0,
    'score' => 0,
  ),
  1516 => 
  array (
    '_id' => '美斯床垫',
    'word' => '美斯床垫',
    'hits' => 0,
    'score' => 0,
  ),
  1517 => 
  array (
    '_id' => '美陶瓷砖',
    'word' => '美陶瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1518 => 
  array (
    '_id' => '门窗安装',
    'word' => '门窗安装',
    'hits' => 0,
    'score' => 0,
  ),
  1519 => 
  array (
    '_id' => '门窗过梁',
    'word' => '门窗过梁',
    'hits' => 0,
    'score' => 0,
  ),
  1520 => 
  array (
    '_id' => '门面房租赁合同范本',
    'word' => '门面房租赁合同范本',
    'hits' => 0,
    'score' => 0,
  ),
  1521 => 
  array (
    '_id' => '门面转让',
    'word' => '门面转让',
    'hits' => 0,
    'score' => 0,
  ),
  1522 => 
  array (
    '_id' => '门面租赁合同',
    'word' => '门面租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  1523 => 
  array (
    '_id' => '门吸',
    'word' => '门吸',
    'hits' => 0,
    'score' => 0,
  ),
  1524 => 
  array (
    '_id' => '蒙娜丽莎瓷砖',
    'word' => '蒙娜丽莎瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1525 => 
  array (
    '_id' => '梦见买房子',
    'word' => '梦见买房子',
    'hits' => 0,
    'score' => 0,
  ),
  1526 => 
  array (
    '_id' => '梦开阳台窗',
    'word' => '梦开阳台窗',
    'hits' => 0,
    'score' => 0,
  ),
  1527 => 
  array (
    '_id' => '米黄大理石',
    'word' => '米黄大理石',
    'hits' => 0,
    'score' => 0,
  ),
  1528 => 
  array (
    '_id' => '米兰家具',
    'word' => '米兰家具',
    'hits' => 0,
    'score' => 0,
  ),
  1529 => 
  array (
    '_id' => '密封胶',
    'word' => '密封胶',
    'hits' => 0,
    'score' => 0,
  ),
  1530 => 
  array (
    '_id' => '蜜蜂瓷砖',
    'word' => '蜜蜂瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1531 => 
  array (
    '_id' => '绵阳公积金贷款',
    'word' => '绵阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1532 => 
  array (
    '_id' => '免漆板',
    'word' => '免漆板',
    'hits' => 0,
    'score' => 0,
  ),
  1533 => 
  array (
    '_id' => '面积测绘费',
    'word' => '面积测绘费',
    'hits' => 0,
    'score' => 0,
  ),
  1534 => 
  array (
    '_id' => '面积怎么算',
    'word' => '面积怎么算',
    'hits' => 0,
    'score' => 0,
  ),
  1535 => 
  array (
    '_id' => '民用建筑',
    'word' => '民用建筑',
    'hits' => 0,
    'score' => 0,
  ),
  1536 => 
  array (
    '_id' => '明亮安格阳台窗',
    'word' => '明亮安格阳台窗',
    'hits' => 0,
    'score' => 0,
  ),
  1537 => 
  array (
    '_id' => '明珠家具',
    'word' => '明珠家具',
    'hits' => 0,
    'score' => 0,
  ),
  1538 => 
  array (
    '_id' => '模具钢材',
    'word' => '模具钢材',
    'hits' => 0,
    'score' => 0,
  ),
  1539 => 
  array (
    '_id' => '模压门',
    'word' => '模压门',
    'hits' => 0,
    'score' => 0,
  ),
  1540 => 
  array (
    '_id' => '摩恩水槽',
    'word' => '摩恩水槽',
    'hits' => 0,
    'score' => 0,
  ),
  1541 => 
  array (
    '_id' => '摩尔洗衣机',
    'word' => '摩尔洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  1542 => 
  array (
    '_id' => '摩力克窗帘',
    'word' => '摩力克窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  1543 => 
  array (
    '_id' => '磨砂玻璃',
    'word' => '磨砂玻璃',
    'hits' => 0,
    'score' => 0,
  ),
  1544 => 
  array (
    '_id' => '牡丹江住房公积金查询',
    'word' => '牡丹江住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1545 => 
  array (
    '_id' => '牡丹江住房公积金提取',
    'word' => '牡丹江住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1546 => 
  array (
    '_id' => '木别墅',
    'word' => '木别墅',
    'hits' => 0,
    'score' => 0,
  ),
  1547 => 
  array (
    '_id' => '木地板',
    'word' => '木地板',
    'hits' => 0,
    'score' => 0,
  ),
  1548 => 
  array (
    '_id' => '木地板好还是瓷砖好',
    'word' => '木地板好还是瓷砖好',
    'hits' => 0,
    'score' => 0,
  ),
  1549 => 
  array (
    '_id' => '木地板排名',
    'word' => '木地板排名',
    'hits' => 0,
    'score' => 0,
  ),
  1550 => 
  array (
    '_id' => '木地板怎么清洁',
    'word' => '木地板怎么清洁',
    'hits' => 0,
    'score' => 0,
  ),
  1551 => 
  array (
    '_id' => '木龙骨',
    'word' => '木龙骨',
    'hits' => 0,
    'score' => 0,
  ),
  1552 => 
  array (
    '_id' => '木容尚品家具',
    'word' => '木容尚品家具',
    'hits' => 0,
    'score' => 0,
  ),
  1553 => 
  array (
    '_id' => '木塑门',
    'word' => '木塑门',
    'hits' => 0,
    'score' => 0,
  ),
  1554 => 
  array (
    '_id' => '慕思床垫',
    'word' => '慕思床垫',
    'hits' => 0,
    'score' => 0,
  ),
  1555 => 
  array (
    '_id' => '哪个银行贷款利率低',
    'word' => '哪个银行贷款利率低',
    'hits' => 0,
    'score' => 0,
  ),
  1556 => 
  array (
    '_id' => '内江住房公积金提取',
    'word' => '内江住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1557 => 
  array (
    '_id' => '内盘',
    'word' => '内盘',
    'hits' => 0,
    'score' => 0,
  ),
  1558 => 
  array (
    '_id' => '内墙保温材料',
    'word' => '内墙保温材料',
    'hits' => 0,
    'score' => 0,
  ),
  1559 => 
  array (
    '_id' => '内墙漆',
    'word' => '内墙漆',
    'hits' => 0,
    'score' => 0,
  ),
  1560 => 
  array (
    '_id' => '内墙乳胶漆',
    'word' => '内墙乳胶漆',
    'hits' => 0,
    'score' => 0,
  ),
  1561 => 
  array (
    '_id' => '内墙砖',
    'word' => '内墙砖',
    'hits' => 0,
    'score' => 0,
  ),
  1562 => 
  array (
    '_id' => '内销房',
    'word' => '内销房',
    'hits' => 0,
    'score' => 0,
  ),
  1563 => 
  array (
    '_id' => '纳米材料',
    'word' => '纳米材料',
    'hits' => 0,
    'score' => 0,
  ),
  1564 => 
  array (
    '_id' => '纳税保证金',
    'word' => '纳税保证金',
    'hits' => 0,
    'score' => 0,
  ),
  1565 => 
  array (
    '_id' => '奶酪王国家具',
    'word' => '奶酪王国家具',
    'hits' => 0,
    'score' => 0,
  ),
  1566 => 
  array (
    '_id' => '耐水腻子',
    'word' => '耐水腻子',
    'hits' => 0,
    'score' => 0,
  ),
  1567 => 
  array (
    '_id' => '南昌公积金贷款',
    'word' => '南昌公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1568 => 
  array (
    '_id' => '南昌住房公积金查询',
    'word' => '南昌住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1569 => 
  array (
    '_id' => '南昌住房公积金提取',
    'word' => '南昌住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1570 => 
  array (
    '_id' => '南充公积金贷款',
    'word' => '南充公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1571 => 
  array (
    '_id' => '南充住房公积金查询',
    'word' => '南充住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1572 => 
  array (
    '_id' => '南京保障房',
    'word' => '南京保障房',
    'hits' => 0,
    'score' => 0,
  ),
  1573 => 
  array (
    '_id' => '南京房产税',
    'word' => '南京房产税',
    'hits' => 0,
    'score' => 0,
  ),
  1574 => 
  array (
    '_id' => '南京公积金贷款',
    'word' => '南京公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1575 => 
  array (
    '_id' => '南京买房条件',
    'word' => '南京买房条件',
    'hits' => 0,
    'score' => 0,
  ),
  1576 => 
  array (
    '_id' => '南京住房公积金提取',
    'word' => '南京住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1577 => 
  array (
    '_id' => '南宁公积金贷款',
    'word' => '南宁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1578 => 
  array (
    '_id' => '南宁经济适用房',
    'word' => '南宁经济适用房',
    'hits' => 0,
    'score' => 0,
  ),
  1579 => 
  array (
    '_id' => '南平公积金贷款',
    'word' => '南平公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1580 => 
  array (
    '_id' => '南平住房公积金提取',
    'word' => '南平住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1581 => 
  array (
    '_id' => '南通公积金贷款',
    'word' => '南通公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1582 => 
  array (
    '_id' => '南阳公积金贷款',
    'word' => '南阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1583 => 
  array (
    '_id' => '南阳住房公积金查询',
    'word' => '南阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1584 => 
  array (
    '_id' => '南阳住房公积金提取',
    'word' => '南阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1585 => 
  array (
    '_id' => '能率热水器',
    'word' => '能率热水器',
    'hits' => 0,
    'score' => 0,
  ),
  1586 => 
  array (
    '_id' => '能源库浴霸',
    'word' => '能源库浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  1587 => 
  array (
    '_id' => '宁波住房公积金提取',
    'word' => '宁波住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1588 => 
  array (
    '_id' => '宁德公积金贷款',
    'word' => '宁德公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1589 => 
  array (
    '_id' => '宁海公积金贷款',
    'word' => '宁海公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1590 => 
  array (
    '_id' => '宁海住房公积金提取',
    'word' => '宁海住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1591 => 
  array (
    '_id' => '牛皮市',
    'word' => '牛皮市',
    'hits' => 0,
    'score' => 0,
  ),
  1592 => 
  array (
    '_id' => '牛市',
    'word' => '牛市',
    'hits' => 0,
    'score' => 0,
  ),
  1593 => 
  array (
    '_id' => '农村拆迁',
    'word' => '农村拆迁',
    'hits' => 0,
    'score' => 0,
  ),
  1594 => 
  array (
    '_id' => '农村产权',
    'word' => '农村产权',
    'hits' => 0,
    'score' => 0,
  ),
  1595 => 
  array (
    '_id' => '农村房屋买卖',
    'word' => '农村房屋买卖',
    'hits' => 0,
    'score' => 0,
  ),
  1596 => 
  array (
    '_id' => '农村集体土地使用权',
    'word' => '农村集体土地使用权',
    'hits' => 0,
    'score' => 0,
  ),
  1597 => 
  array (
    '_id' => '农村集体土地征收补偿条例',
    'word' => '农村集体土地征收补偿条例',
    'hits' => 0,
    'score' => 0,
  ),
  1598 => 
  array (
    '_id' => '农村建设用地',
    'word' => '农村建设用地',
    'hits' => 0,
    'score' => 0,
  ),
  1599 => 
  array (
    '_id' => '农村土地流转',
    'word' => '农村土地流转',
    'hits' => 0,
    'score' => 0,
  ),
  1600 => 
  array (
    '_id' => '农村土地使用证明范本',
    'word' => '农村土地使用证明范本',
    'hits' => 0,
    'score' => 0,
  ),
  1601 => 
  array (
    '_id' => '农村危房改造',
    'word' => '农村危房改造',
    'hits' => 0,
    'score' => 0,
  ),
  1602 => 
  array (
    '_id' => '农村危房改造登陆',
    'word' => '农村危房改造登陆',
    'hits' => 0,
    'score' => 0,
  ),
  1603 => 
  array (
    '_id' => '农村小产权房最新政策',
    'word' => '农村小产权房最新政策',
    'hits' => 0,
    'score' => 0,
  ),
  1604 => 
  array (
    '_id' => '农村宅基地',
    'word' => '农村宅基地',
    'hits' => 0,
    'score' => 0,
  ),
  1605 => 
  array (
    '_id' => '农村宅基地纠纷处理',
    'word' => '农村宅基地纠纷处理',
    'hits' => 0,
    'score' => 0,
  ),
  1606 => 
  array (
    '_id' => '农村住宅风水',
    'word' => '农村住宅风水',
    'hits' => 0,
    'score' => 0,
  ),
  1607 => 
  array (
    '_id' => '怒江公积金贷款',
    'word' => '怒江公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1608 => 
  array (
    '_id' => '女贞',
    'word' => '女贞',
    'hits' => 0,
    'score' => 0,
  ),
  1609 => 
  array (
    '_id' => '暖气',
    'word' => '暖气',
    'hits' => 0,
    'score' => 0,
  ),
  1610 => 
  array (
    '_id' => '暖气换热器',
    'word' => '暖气换热器',
    'hits' => 0,
    'score' => 0,
  ),
  1611 => 
  array (
    '_id' => '诺维家衣柜',
    'word' => '诺维家衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1612 => 
  array (
    '_id' => '欧风壁纸',
    'word' => '欧风壁纸',
    'hits' => 0,
    'score' => 0,
  ),
  1613 => 
  array (
    '_id' => '欧美装修风格',
    'word' => '欧美装修风格',
    'hits' => 0,
    'score' => 0,
  ),
  1614 => 
  array (
    '_id' => '欧派橱柜',
    'word' => '欧派橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  1615 => 
  array (
    '_id' => '欧派灯具',
    'word' => '欧派灯具',
    'hits' => 0,
    'score' => 0,
  ),
  1616 => 
  array (
    '_id' => '欧派集成吊顶',
    'word' => '欧派集成吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  1617 => 
  array (
    '_id' => '欧普插座',
    'word' => '欧普插座',
    'hits' => 0,
    'score' => 0,
  ),
  1618 => 
  array (
    '_id' => '欧普照明灯具',
    'word' => '欧普照明灯具',
    'hits' => 0,
    'score' => 0,
  ),
  1619 => 
  array (
    '_id' => '欧神诺瓷砖',
    'word' => '欧神诺瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1620 => 
  array (
    '_id' => '欧式背景墙',
    'word' => '欧式背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  1621 => 
  array (
    '_id' => '欧式厨房',
    'word' => '欧式厨房',
    'hits' => 0,
    'score' => 0,
  ),
  1622 => 
  array (
    '_id' => '欧式床',
    'word' => '欧式床',
    'hits' => 0,
    'score' => 0,
  ),
  1623 => 
  array (
    '_id' => '欧式灯具',
    'word' => '欧式灯具',
    'hits' => 0,
    'score' => 0,
  ),
  1624 => 
  array (
    '_id' => '欧式吊灯',
    'word' => '欧式吊灯',
    'hits' => 0,
    'score' => 0,
  ),
  1625 => 
  array (
    '_id' => '欧式家居装修',
    'word' => '欧式家居装修',
    'hits' => 0,
    'score' => 0,
  ),
  1626 => 
  array (
    '_id' => '欧式沙发',
    'word' => '欧式沙发',
    'hits' => 0,
    'score' => 0,
  ),
  1627 => 
  array (
    '_id' => '欧式卧室',
    'word' => '欧式卧室',
    'hits' => 0,
    'score' => 0,
  ),
  1628 => 
  array (
    '_id' => '欧洲债券',
    'word' => '欧洲债券',
    'hits' => 0,
    'score' => 0,
  ),
  1629 => 
  array (
    '_id' => '帕洛尼水槽',
    'word' => '帕洛尼水槽',
    'hits' => 0,
    'score' => 0,
  ),
  1630 => 
  array (
    '_id' => '排号',
    'word' => '排号',
    'hits' => 0,
    'score' => 0,
  ),
  1631 => 
  array (
    '_id' => '派息',
    'word' => '派息',
    'hits' => 0,
    'score' => 0,
  ),
  1632 => 
  array (
    '_id' => '攀枝花公积金贷款',
    'word' => '攀枝花公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1633 => 
  array (
    '_id' => '攀枝花住房公积金查询',
    'word' => '攀枝花住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1634 => 
  array (
    '_id' => '盘锦公积金贷款',
    'word' => '盘锦公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1635 => 
  array (
    '_id' => '盘锦住房公积金查询',
    'word' => '盘锦住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1636 => 
  array (
    '_id' => '盘锦住房公积金提取',
    'word' => '盘锦住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1637 => 
  array (
    '_id' => '盼盼防盗门',
    'word' => '盼盼防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  1638 => 
  array (
    '_id' => '盼盼木门',
    'word' => '盼盼木门',
    'hits' => 0,
    'score' => 0,
  ),
  1639 => 
  array (
    '_id' => '抛光砖',
    'word' => '抛光砖',
    'hits' => 0,
    'score' => 0,
  ),
  1640 => 
  array (
    '_id' => '抛光砖和抛釉砖的区别',
    'word' => '抛光砖和抛釉砖的区别',
    'hits' => 0,
    'score' => 0,
  ),
  1641 => 
  array (
    '_id' => '抛售',
    'word' => '抛售',
    'hits' => 0,
    'score' => 0,
  ),
  1642 => 
  array (
    '_id' => '配电柜',
    'word' => '配电柜',
    'hits' => 0,
    'score' => 0,
  ),
  1643 => 
  array (
    '_id' => '配电箱',
    'word' => '配电箱',
    'hits' => 0,
    'score' => 0,
  ),
  1644 => 
  array (
    '_id' => '配电箱接线图',
    'word' => '配电箱接线图',
    'hits' => 0,
    'score' => 0,
  ),
  1645 => 
  array (
    '_id' => '配股',
    'word' => '配股',
    'hits' => 0,
    'score' => 0,
  ),
  1646 => 
  array (
    '_id' => '配送中心',
    'word' => '配送中心',
    'hits' => 0,
    'score' => 0,
  ),
  1647 => 
  array (
    '_id' => '棚户区',
    'word' => '棚户区',
    'hits' => 0,
    'score' => 0,
  ),
  1648 => 
  array (
    '_id' => '棚户区改造',
    'word' => '棚户区改造',
    'hits' => 0,
    'score' => 0,
  ),
  1649 => 
  array (
    '_id' => '膨胀水箱',
    'word' => '膨胀水箱',
    'hits' => 0,
    'score' => 0,
  ),
  1650 => 
  array (
    '_id' => '皮床',
    'word' => '皮床',
    'hits' => 0,
    'score' => 0,
  ),
  1651 => 
  array (
    '_id' => '皮床好还是木床好',
    'word' => '皮床好还是木床好',
    'hits' => 0,
    'score' => 0,
  ),
  1652 => 
  array (
    '_id' => '皮尔萨水管',
    'word' => '皮尔萨水管',
    'hits' => 0,
    'score' => 0,
  ),
  1653 => 
  array (
    '_id' => '皮沙发好还是布沙发好',
    'word' => '皮沙发好还是布沙发好',
    'hits' => 0,
    'score' => 0,
  ),
  1654 => 
  array (
    '_id' => '皮沙发怎么清洗',
    'word' => '皮沙发怎么清洗',
    'hits' => 0,
    'score' => 0,
  ),
  1655 => 
  array (
    '_id' => '飘窗窗帘',
    'word' => '飘窗窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  1656 => 
  array (
    '_id' => '飘窗垫',
    'word' => '飘窗垫',
    'hits' => 0,
    'score' => 0,
  ),
  1657 => 
  array (
    '_id' => '拼花地板',
    'word' => '拼花地板',
    'hits' => 0,
    'score' => 0,
  ),
  1658 => 
  array (
    '_id' => '平板电脑',
    'word' => '平板电脑',
    'hits' => 0,
    'score' => 0,
  ),
  1659 => 
  array (
    '_id' => '平板电视',
    'word' => '平板电视',
    'hits' => 0,
    'score' => 0,
  ),
  1660 => 
  array (
    '_id' => '平顶山公积金贷款',
    'word' => '平顶山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1661 => 
  array (
    '_id' => '平顶山住房公积金查询',
    'word' => '平顶山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1662 => 
  array (
    '_id' => '平顶山住房公积金提取',
    'word' => '平顶山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1663 => 
  array (
    '_id' => '平湖公积金贷款',
    'word' => '平湖公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1664 => 
  array (
    '_id' => '平湖住房公积金查询',
    'word' => '平湖住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1665 => 
  array (
    '_id' => '平价房',
    'word' => '平价房',
    'hits' => 0,
    'score' => 0,
  ),
  1666 => 
  array (
    '_id' => '平凉住房公积金查询',
    'word' => '平凉住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1667 => 
  array (
    '_id' => '平凉住房公积金提取',
    'word' => '平凉住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1668 => 
  array (
    '_id' => '苹果家具',
    'word' => '苹果家具',
    'hits' => 0,
    'score' => 0,
  ),
  1669 => 
  array (
    '_id' => '屏风隔断',
    'word' => '屏风隔断',
    'hits' => 0,
    'score' => 0,
  ),
  1670 => 
  array (
    '_id' => '萍乡公积金贷款',
    'word' => '萍乡公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1671 => 
  array (
    '_id' => '萍乡住房公积金查询',
    'word' => '萍乡住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1672 => 
  array (
    '_id' => '铺地砖',
    'word' => '铺地砖',
    'hits' => 0,
    'score' => 0,
  ),
  1673 => 
  array (
    '_id' => '莆田公积金贷款',
    'word' => '莆田公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1674 => 
  array (
    '_id' => '莆田住房公积金提取',
    'word' => '莆田住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1675 => 
  array (
    '_id' => '菩提岛家具',
    'word' => '菩提岛家具',
    'hits' => 0,
    'score' => 0,
  ),
  1676 => 
  array (
    '_id' => '普洱公积金贷款',
    'word' => '普洱公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1677 => 
  array (
    '_id' => '普洱住房公积金查询',
    'word' => '普洱住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1678 => 
  array (
    '_id' => '普乐美水槽',
    'word' => '普乐美水槽',
    'hits' => 0,
    'score' => 0,
  ),
  1679 => 
  array (
    '_id' => '普乐美水龙头',
    'word' => '普乐美水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  1680 => 
  array (
    '_id' => '普田橱柜',
    'word' => '普田橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  1681 => 
  array (
    '_id' => '普通住房',
    'word' => '普通住房',
    'hits' => 0,
    'score' => 0,
  ),
  1682 => 
  array (
    '_id' => '普通住宅',
    'word' => '普通住宅',
    'hits' => 0,
    'score' => 0,
  ),
  1683 => 
  array (
    '_id' => 'RUN智能家居布线系统',
    'word' => 'RUN智能家居布线系统',
    'hits' => 0,
    'score' => 0,
  ),
  1684 => 
  array (
    '_id' => '七台河住房公积金提取',
    'word' => '七台河住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1685 => 
  array (
    '_id' => '七通一平',
    'word' => '七通一平',
    'hits' => 0,
    'score' => 0,
  ),
  1686 => 
  array (
    '_id' => '七星冰箱',
    'word' => '七星冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  1687 => 
  array (
    '_id' => '期房',
    'word' => '期房',
    'hits' => 0,
    'score' => 0,
  ),
  1688 => 
  array (
    '_id' => '期房和现房',
    'word' => '期房和现房',
    'hits' => 0,
    'score' => 0,
  ),
  1689 => 
  array (
    '_id' => '期房什么时候交首付',
    'word' => '期房什么时候交首付',
    'hits' => 0,
    'score' => 0,
  ),
  1690 => 
  array (
    '_id' => '期货保证金',
    'word' => '期货保证金',
    'hits' => 0,
    'score' => 0,
  ),
  1691 => 
  array (
    '_id' => '期货合约',
    'word' => '期货合约',
    'hits' => 0,
    'score' => 0,
  ),
  1692 => 
  array (
    '_id' => '期货建仓、持仓和平仓',
    'word' => '期货建仓、持仓和平仓',
    'hits' => 0,
    'score' => 0,
  ),
  1693 => 
  array (
    '_id' => '期货交易的逐日盯市制度',
    'word' => '期货交易的逐日盯市制度',
    'hits' => 0,
    'score' => 0,
  ),
  1694 => 
  array (
    '_id' => '期权合约',
    'word' => '期权合约',
    'hits' => 0,
    'score' => 0,
  ),
  1695 => 
  array (
    '_id' => '齐齐哈尔住房公积金查询',
    'word' => '齐齐哈尔住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1696 => 
  array (
    '_id' => '齐心插座',
    'word' => '齐心插座',
    'hits' => 0,
    'score' => 0,
  ),
  1697 => 
  array (
    '_id' => '奇田木门',
    'word' => '奇田木门',
    'hits' => 0,
    'score' => 0,
  ),
  1698 => 
  array (
    '_id' => '骑楼',
    'word' => '骑楼',
    'hits' => 0,
    'score' => 0,
  ),
  1699 => 
  array (
    '_id' => '旗航壁纸',
    'word' => '旗航壁纸',
    'hits' => 0,
    'score' => 0,
  ),
  1700 => 
  array (
    '_id' => '企业房产税',
    'word' => '企业房产税',
    'hits' => 0,
    'score' => 0,
  ),
  1701 => 
  array (
    '_id' => '起步价',
    'word' => '起步价',
    'hits' => 0,
    'score' => 0,
  ),
  1702 => 
  array (
    '_id' => '起价',
    'word' => '起价',
    'hits' => 0,
    'score' => 0,
  ),
  1703 => 
  array (
    '_id' => '气动阀门',
    'word' => '气动阀门',
    'hits' => 0,
    'score' => 0,
  ),
  1704 => 
  array (
    '_id' => '契税',
    'word' => '契税',
    'hits' => 0,
    'score' => 0,
  ),
  1705 => 
  array (
    '_id' => '契税新政策',
    'word' => '契税新政策',
    'hits' => 0,
    'score' => 0,
  ),
  1706 => 
  array (
    '_id' => '契税怎么算',
    'word' => '契税怎么算',
    'hits' => 0,
    'score' => 0,
  ),
  1707 => 
  array (
    '_id' => '砌体结构',
    'word' => '砌体结构',
    'hits' => 0,
    'score' => 0,
  ),
  1708 => 
  array (
    '_id' => '千里时衣柜',
    'word' => '千里时衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1709 => 
  array (
    '_id' => '牵引床',
    'word' => '牵引床',
    'hits' => 0,
    'score' => 0,
  ),
  1710 => 
  array (
    '_id' => '前期物业管理',
    'word' => '前期物业管理',
    'hits' => 0,
    'score' => 0,
  ),
  1711 => 
  array (
    '_id' => '潜江公积金贷款',
    'word' => '潜江公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1712 => 
  array (
    '_id' => '潜江住房公积金查询',
    'word' => '潜江住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1713 => 
  array (
    '_id' => '潜江住房公积金提取',
    'word' => '潜江住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1714 => 
  array (
    '_id' => '潜水艇水龙头',
    'word' => '潜水艇水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  1715 => 
  array (
    '_id' => '潜水艇五金',
    'word' => '潜水艇五金',
    'hits' => 0,
    'score' => 0,
  ),
  1716 => 
  array (
    '_id' => '黔东南住房公积金提取',
    'word' => '黔东南住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1717 => 
  array (
    '_id' => '黔南州公积金贷款',
    'word' => '黔南州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1718 => 
  array (
    '_id' => '黔西南住房公积金查询',
    'word' => '黔西南住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1719 => 
  array (
    '_id' => '强电和弱电',
    'word' => '强电和弱电',
    'hits' => 0,
    'score' => 0,
  ),
  1720 => 
  array (
    '_id' => '强化复合地板',
    'word' => '强化复合地板',
    'hits' => 0,
    'score' => 0,
  ),
  1721 => 
  array (
    '_id' => '强化木门',
    'word' => '强化木门',
    'hits' => 0,
    'score' => 0,
  ),
  1722 => 
  array (
    '_id' => '强力床垫',
    'word' => '强力床垫',
    'hits' => 0,
    'score' => 0,
  ),
  1723 => 
  array (
    '_id' => '强排式热水器',
    'word' => '强排式热水器',
    'hits' => 0,
    'score' => 0,
  ),
  1724 => 
  array (
    '_id' => '强制拆迁',
    'word' => '强制拆迁',
    'hits' => 0,
    'score' => 0,
  ),
  1725 => 
  array (
    '_id' => '墙面空鼓怎么处理',
    'word' => '墙面空鼓怎么处理',
    'hits' => 0,
    'score' => 0,
  ),
  1726 => 
  array (
    '_id' => '墙面砖',
    'word' => '墙面砖',
    'hits' => 0,
    'score' => 0,
  ),
  1727 => 
  array (
    '_id' => '墙面装修流程',
    'word' => '墙面装修流程',
    'hits' => 0,
    'score' => 0,
  ),
  1728 => 
  array (
    '_id' => '墙排马桶',
    'word' => '墙排马桶',
    'hits' => 0,
    'score' => 0,
  ),
  1729 => 
  array (
    '_id' => '墙体彩绘',
    'word' => '墙体彩绘',
    'hits' => 0,
    'score' => 0,
  ),
  1730 => 
  array (
    '_id' => '墙艺漆',
    'word' => '墙艺漆',
    'hits' => 0,
    'score' => 0,
  ),
  1731 => 
  array (
    '_id' => '墙纸',
    'word' => '墙纸',
    'hits' => 0,
    'score' => 0,
  ),
  1732 => 
  array (
    '_id' => '墙纸基膜',
    'word' => '墙纸基膜',
    'hits' => 0,
    'score' => 0,
  ),
  1733 => 
  array (
    '_id' => '墙砖',
    'word' => '墙砖',
    'hits' => 0,
    'score' => 0,
  ),
  1734 => 
  array (
    '_id' => '蔷美壁纸',
    'word' => '蔷美壁纸',
    'hits' => 0,
    'score' => 0,
  ),
  1735 => 
  array (
    '_id' => '钦州公积金贷款',
    'word' => '钦州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1736 => 
  array (
    '_id' => '钦州住房公积金查询',
    'word' => '钦州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1737 => 
  array (
    '_id' => '钦州住房公积金提取',
    'word' => '钦州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1738 => 
  array (
    '_id' => '秦皇岛住房公积金查询',
    'word' => '秦皇岛住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1739 => 
  array (
    '_id' => '秦皇岛住房公积金提取',
    'word' => '秦皇岛住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1740 => 
  array (
    '_id' => '青岛办理房产证流程',
    'word' => '青岛办理房产证流程',
    'hits' => 0,
    'score' => 0,
  ),
  1741 => 
  array (
    '_id' => '青岛公积金贷款',
    'word' => '青岛公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1742 => 
  array (
    '_id' => '青岛经济适用房',
    'word' => '青岛经济适用房',
    'hits' => 0,
    'score' => 0,
  ),
  1743 => 
  array (
    '_id' => '青金石',
    'word' => '青金石',
    'hits' => 0,
    'score' => 0,
  ),
  1744 => 
  array (
    '_id' => '青石板',
    'word' => '青石板',
    'hits' => 0,
    'score' => 0,
  ),
  1745 => 
  array (
    '_id' => '轻钢龙骨',
    'word' => '轻钢龙骨',
    'hits' => 0,
    'score' => 0,
  ),
  1746 => 
  array (
    '_id' => '轻钢龙骨吊顶',
    'word' => '轻钢龙骨吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  1747 => 
  array (
    '_id' => '轻集料混凝土',
    'word' => '轻集料混凝土',
    'hits' => 0,
    'score' => 0,
  ),
  1748 => 
  array (
    '_id' => '轻质混凝土',
    'word' => '轻质混凝土',
    'hits' => 0,
    'score' => 0,
  ),
  1749 => 
  array (
    '_id' => '轻质墙板',
    'word' => '轻质墙板',
    'hits' => 0,
    'score' => 0,
  ),
  1750 => 
  array (
    '_id' => '清华同方照明',
    'word' => '清华同方照明',
    'hits' => 0,
    'score' => 0,
  ),
  1751 => 
  array (
    '_id' => '清水房',
    'word' => '清水房',
    'hits' => 0,
    'score' => 0,
  ),
  1752 => 
  array (
    '_id' => '清油的施工工艺',
    'word' => '清油的施工工艺',
    'hits' => 0,
    'score' => 0,
  ),
  1753 => 
  array (
    '_id' => '清远公积金贷款',
    'word' => '清远公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1754 => 
  array (
    '_id' => '清远住房公积金查询',
    'word' => '清远住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1755 => 
  array (
    '_id' => '庆阳公积金贷款',
    'word' => '庆阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1756 => 
  array (
    '_id' => '庆阳住房公积金查询',
    'word' => '庆阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1757 => 
  array (
    '_id' => '琼海住房公积金提取',
    'word' => '琼海住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1758 => 
  array (
    '_id' => '秋叶原插座',
    'word' => '秋叶原插座',
    'hits' => 0,
    'score' => 0,
  ),
  1759 => 
  array (
    '_id' => '曲靖住房公积金查询',
    'word' => '曲靖住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1760 => 
  array (
    '_id' => '驱蚊草',
    'word' => '驱蚊草',
    'hits' => 0,
    'score' => 0,
  ),
  1761 => 
  array (
    '_id' => '趋势',
    'word' => '趋势',
    'hits' => 0,
    'score' => 0,
  ),
  1762 => 
  array (
    '_id' => '趋势线',
    'word' => '趋势线',
    'hits' => 0,
    'score' => 0,
  ),
  1763 => 
  array (
    '_id' => '衢州公积金贷款',
    'word' => '衢州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1764 => 
  array (
    '_id' => '取住房公积金材料',
    'word' => '取住房公积金材料',
    'hits' => 0,
    'score' => 0,
  ),
  1765 => 
  array (
    '_id' => '取住房公积金手续',
    'word' => '取住房公积金手续',
    'hits' => 0,
    'score' => 0,
  ),
  1766 => 
  array (
    '_id' => '全国房价排行',
    'word' => '全国房价排行',
    'hits' => 0,
    'score' => 0,
  ),
  1767 => 
  array (
    '_id' => '全抛釉和抛光砖的区别',
    'word' => '全抛釉和抛光砖的区别',
    'hits' => 0,
    'score' => 0,
  ),
  1768 => 
  array (
    '_id' => '全装',
    'word' => '全装',
    'hits' => 0,
    'score' => 0,
  ),
  1769 => 
  array (
    '_id' => '全自动过滤器',
    'word' => '全自动过滤器',
    'hits' => 0,
    'score' => 0,
  ),
  1770 => 
  array (
    '_id' => '全自动咖啡机',
    'word' => '全自动咖啡机',
    'hits' => 0,
    'score' => 0,
  ),
  1771 => 
  array (
    '_id' => '全自动洗衣机进水管安装图',
    'word' => '全自动洗衣机进水管安装图',
    'hits' => 0,
    'score' => 0,
  ),
  1772 => 
  array (
    '_id' => '全自动洗衣机水龙头安装',
    'word' => '全自动洗衣机水龙头安装',
    'hits' => 0,
    'score' => 0,
  ),
  1773 => 
  array (
    '_id' => '权证',
    'word' => '权证',
    'hits' => 0,
    'score' => 0,
  ),
  1774 => 
  array (
    '_id' => '泉天下热水器',
    'word' => '泉天下热水器',
    'hits' => 0,
    'score' => 0,
  ),
  1775 => 
  array (
    '_id' => '泉州住房公积金提取',
    'word' => '泉州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1776 => 
  array (
    '_id' => '裙楼',
    'word' => '裙楼',
    'hits' => 0,
    'score' => 0,
  ),
  1777 => 
  array (
    '_id' => '群升防盗门',
    'word' => '群升防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  1778 => 
  array (
    '_id' => '群租房',
    'word' => '群租房',
    'hits' => 0,
    'score' => 0,
  ),
  1779 => 
  array (
    '_id' => '群租房管理',
    'word' => '群租房管理',
    'hits' => 0,
    'score' => 0,
  ),
  1780 => 
  array (
    '_id' => '群租房举报',
    'word' => '群租房举报',
    'hits' => 0,
    'score' => 0,
  ),
  1781 => 
  array (
    '_id' => '燃气报警器',
    'word' => '燃气报警器',
    'hits' => 0,
    'score' => 0,
  ),
  1782 => 
  array (
    '_id' => '燃气炉',
    'word' => '燃气炉',
    'hits' => 0,
    'score' => 0,
  ),
  1783 => 
  array (
    '_id' => '燃气热水器',
    'word' => '燃气热水器',
    'hits' => 0,
    'score' => 0,
  ),
  1784 => 
  array (
    '_id' => '燃气灶',
    'word' => '燃气灶',
    'hits' => 0,
    'score' => 0,
  ),
  1785 => 
  array (
    '_id' => '认筹',
    'word' => '认筹',
    'hits' => 0,
    'score' => 0,
  ),
  1786 => 
  array (
    '_id' => '认购',
    'word' => '认购',
    'hits' => 0,
    'score' => 0,
  ),
  1787 => 
  array (
    '_id' => '认购权证',
    'word' => '认购权证',
    'hits' => 0,
    'score' => 0,
  ),
  1788 => 
  array (
    '_id' => '认购书',
    'word' => '认购书',
    'hits' => 0,
    'score' => 0,
  ),
  1789 => 
  array (
    '_id' => '认沽权证',
    'word' => '认沽权证',
    'hits' => 0,
    'score' => 0,
  ),
  1790 => 
  array (
    '_id' => '认股权证',
    'word' => '认股权证',
    'hits' => 0,
    'score' => 0,
  ),
  1791 => 
  array (
    '_id' => '日本房地产',
    'word' => '日本房地产',
    'hits' => 0,
    'score' => 0,
  ),
  1792 => 
  array (
    '_id' => '日成交额',
    'word' => '日成交额',
    'hits' => 0,
    'score' => 0,
  ),
  1793 => 
  array (
    '_id' => '日成交量',
    'word' => '日成交量',
    'hits' => 0,
    'score' => 0,
  ),
  1794 => 
  array (
    '_id' => '日丰水龙头',
    'word' => '日丰水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  1795 => 
  array (
    '_id' => '日经指数',
    'word' => '日经指数',
    'hits' => 0,
    'score' => 0,
  ),
  1796 => 
  array (
    '_id' => '日开盘价',
    'word' => '日开盘价',
    'hits' => 0,
    'score' => 0,
  ),
  1797 => 
  array (
    '_id' => '日立空调',
    'word' => '日立空调',
    'hits' => 0,
    'score' => 0,
  ),
  1798 => 
  array (
    '_id' => '日式榻榻米',
    'word' => '日式榻榻米',
    'hits' => 0,
    'score' => 0,
  ),
  1799 => 
  array (
    '_id' => '日式装修',
    'word' => '日式装修',
    'hits' => 0,
    'score' => 0,
  ),
  1800 => 
  array (
    '_id' => '日收盘价',
    'word' => '日收盘价',
    'hits' => 0,
    'score' => 0,
  ),
  1801 => 
  array (
    '_id' => '日照公积金贷款',
    'word' => '日照公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1802 => 
  array (
    '_id' => '日照住房公积金查询',
    'word' => '日照住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1803 => 
  array (
    '_id' => '日最低价',
    'word' => '日最低价',
    'hits' => 0,
    'score' => 0,
  ),
  1804 => 
  array (
    '_id' => '日最高价',
    'word' => '日最高价',
    'hits' => 0,
    'score' => 0,
  ),
  1805 => 
  array (
    '_id' => '荣登地板',
    'word' => '荣登地板',
    'hits' => 0,
    'score' => 0,
  ),
  1806 => 
  array (
    '_id' => '荣力斯合页',
    'word' => '荣力斯合页',
    'hits' => 0,
    'score' => 0,
  ),
  1807 => 
  array (
    '_id' => '荣事达洗衣机',
    'word' => '荣事达洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  1808 => 
  array (
    '_id' => '容积率',
    'word' => '容积率',
    'hits' => 0,
    'score' => 0,
  ),
  1809 => 
  array (
    '_id' => '容积式换热器',
    'word' => '容积式换热器',
    'hits' => 0,
    'score' => 0,
  ),
  1810 => 
  array (
    '_id' => '如皋公积金贷款',
    'word' => '如皋公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1811 => 
  array (
    '_id' => '如皋住房公积金查询',
    'word' => '如皋住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1812 => 
  array (
    '_id' => '如何成立业主委员会',
    'word' => '如何成立业主委员会',
    'hits' => 0,
    'score' => 0,
  ),
  1813 => 
  array (
    '_id' => '如何防止一房两卖',
    'word' => '如何防止一房两卖',
    'hits' => 0,
    'score' => 0,
  ),
  1814 => 
  array (
    '_id' => '如何刮腻子',
    'word' => '如何刮腻子',
    'hits' => 0,
    'score' => 0,
  ),
  1815 => 
  array (
    '_id' => '如何看房子风水',
    'word' => '如何看房子风水',
    'hits' => 0,
    'score' => 0,
  ),
  1816 => 
  array (
    '_id' => '如何买房',
    'word' => '如何买房',
    'hits' => 0,
    'score' => 0,
  ),
  1817 => 
  array (
    '_id' => '如何判断承重墙',
    'word' => '如何判断承重墙',
    'hits' => 0,
    'score' => 0,
  ),
  1818 => 
  array (
    '_id' => '如何取公积金',
    'word' => '如何取公积金',
    'hits' => 0,
    'score' => 0,
  ),
  1819 => 
  array (
    '_id' => '如何申请房贷',
    'word' => '如何申请房贷',
    'hits' => 0,
    'score' => 0,
  ),
  1820 => 
  array (
    '_id' => '如何收房验房',
    'word' => '如何收房验房',
    'hits' => 0,
    'score' => 0,
  ),
  1821 => 
  array (
    '_id' => '如何选购瓷砖',
    'word' => '如何选购瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1822 => 
  array (
    '_id' => '如何验收新房',
    'word' => '如何验收新房',
    'hits' => 0,
    'score' => 0,
  ),
  1823 => 
  array (
    '_id' => '乳胶漆',
    'word' => '乳胶漆',
    'hits' => 0,
    'score' => 0,
  ),
  1824 => 
  array (
    '_id' => '乳胶漆颜色',
    'word' => '乳胶漆颜色',
    'hits' => 0,
    'score' => 0,
  ),
  1825 => 
  array (
    '_id' => '入墙衣柜',
    'word' => '入墙衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1826 => 
  array (
    '_id' => '软门帘',
    'word' => '软门帘',
    'hits' => 0,
    'score' => 0,
  ),
  1827 => 
  array (
    '_id' => '软装修',
    'word' => '软装修',
    'hits' => 0,
    'score' => 0,
  ),
  1828 => 
  array (
    '_id' => '瑞诺瓷砖',
    'word' => '瑞诺瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1829 => 
  array (
    '_id' => '瑞信家具',
    'word' => '瑞信家具',
    'hits' => 0,
    'score' => 0,
  ),
  1830 => 
  array (
    '_id' => '弱电工程',
    'word' => '弱电工程',
    'hits' => 0,
    'score' => 0,
  ),
  1831 => 
  array (
    '_id' => '赛亿冰箱',
    'word' => '赛亿冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  1832 => 
  array (
    '_id' => '三和油漆',
    'word' => '三和油漆',
    'hits' => 0,
    'score' => 0,
  ),
  1833 => 
  array (
    '_id' => '三级钢筋',
    'word' => '三级钢筋',
    'hits' => 0,
    'score' => 0,
  ),
  1834 => 
  array (
    '_id' => '三角阀安装',
    'word' => '三角阀安装',
    'hits' => 0,
    'score' => 0,
  ),
  1835 => 
  array (
    '_id' => '三棵树油漆',
    'word' => '三棵树油漆',
    'hits' => 0,
    'score' => 0,
  ),
  1836 => 
  array (
    '_id' => '三控开关',
    'word' => '三控开关',
    'hits' => 0,
    'score' => 0,
  ),
  1837 => 
  array (
    '_id' => '三门峡公积金贷款',
    'word' => '三门峡公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1838 => 
  array (
    '_id' => '三门峡住房公积金查询',
    'word' => '三门峡住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1839 => 
  array (
    '_id' => '三门峡住房公积金提取',
    'word' => '三门峡住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1840 => 
  array (
    '_id' => '三明公积金贷款',
    'word' => '三明公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1841 => 
  array (
    '_id' => '三明住房公积金查询',
    'word' => '三明住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1842 => 
  array (
    '_id' => '三明住房公积金提取',
    'word' => '三明住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1843 => 
  array (
    '_id' => '三木插座',
    'word' => '三木插座',
    'hits' => 0,
    'score' => 0,
  ),
  1844 => 
  array (
    '_id' => '三森国际家居',
    'word' => '三森国际家居',
    'hits' => 0,
    'score' => 0,
  ),
  1845 => 
  array (
    '_id' => '三通一平',
    'word' => '三通一平',
    'hits' => 0,
    'score' => 0,
  ),
  1846 => 
  array (
    '_id' => '三星冰箱',
    'word' => '三星冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  1847 => 
  array (
    '_id' => '三星电视',
    'word' => '三星电视',
    'hits' => 0,
    'score' => 0,
  ),
  1848 => 
  array (
    '_id' => '三雄极光插座',
    'word' => '三雄极光插座',
    'hits' => 0,
    'score' => 0,
  ),
  1849 => 
  array (
    '_id' => '三洋电视',
    'word' => '三洋电视',
    'hits' => 0,
    'score' => 0,
  ),
  1850 => 
  array (
    '_id' => '三洋洗衣机',
    'word' => '三洋洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  1851 => 
  array (
    '_id' => '桑普浴霸',
    'word' => '桑普浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  1852 => 
  array (
    '_id' => '沙发背景墙',
    'word' => '沙发背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  1853 => 
  array (
    '_id' => '沙发尺寸',
    'word' => '沙发尺寸',
    'hits' => 0,
    'score' => 0,
  ),
  1854 => 
  array (
    '_id' => '沙发坐垫',
    'word' => '沙发坐垫',
    'hits' => 0,
    'score' => 0,
  ),
  1855 => 
  array (
    '_id' => '山山地板',
    'word' => '山山地板',
    'hits' => 0,
    'score' => 0,
  ),
  1856 => 
  array (
    '_id' => '汕头公积金贷款',
    'word' => '汕头公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1857 => 
  array (
    '_id' => '汕头住房公积金查询',
    'word' => '汕头住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1858 => 
  array (
    '_id' => '汕头住房公积金提取',
    'word' => '汕头住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1859 => 
  array (
    '_id' => '汕尾住房公积金提取',
    'word' => '汕尾住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1860 => 
  array (
    '_id' => '疝气灯',
    'word' => '疝气灯',
    'hits' => 0,
    'score' => 0,
  ),
  1861 => 
  array (
    '_id' => '商贷转公积金贷款',
    'word' => '商贷转公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1862 => 
  array (
    '_id' => '商洛公积金贷款',
    'word' => '商洛公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1863 => 
  array (
    '_id' => '商洛住房公积金查询',
    'word' => '商洛住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1864 => 
  array (
    '_id' => '商品房',
    'word' => '商品房',
    'hits' => 0,
    'score' => 0,
  ),
  1865 => 
  array (
    '_id' => '商品房的使用率',
    'word' => '商品房的使用率',
    'hits' => 0,
    'score' => 0,
  ),
  1866 => 
  array (
    '_id' => '商品房交房标准',
    'word' => '商品房交房标准',
    'hits' => 0,
    'score' => 0,
  ),
  1867 => 
  array (
    '_id' => '商品房买卖',
    'word' => '商品房买卖',
    'hits' => 0,
    'score' => 0,
  ),
  1868 => 
  array (
    '_id' => '商品房买卖合同',
    'word' => '商品房买卖合同',
    'hits' => 0,
    'score' => 0,
  ),
  1869 => 
  array (
    '_id' => '商品房买卖合同查询',
    'word' => '商品房买卖合同查询',
    'hits' => 0,
    'score' => 0,
  ),
  1870 => 
  array (
    '_id' => '商品房认购书',
    'word' => '商品房认购书',
    'hits' => 0,
    'score' => 0,
  ),
  1871 => 
  array (
    '_id' => '商品房使用年限',
    'word' => '商品房使用年限',
    'hits' => 0,
    'score' => 0,
  ),
  1872 => 
  array (
    '_id' => '商品房土地证',
    'word' => '商品房土地证',
    'hits' => 0,
    'score' => 0,
  ),
  1873 => 
  array (
    '_id' => '商品房维修基金',
    'word' => '商品房维修基金',
    'hits' => 0,
    'score' => 0,
  ),
  1874 => 
  array (
    '_id' => '商品房现售',
    'word' => '商品房现售',
    'hits' => 0,
    'score' => 0,
  ),
  1875 => 
  array (
    '_id' => '商品房销售',
    'word' => '商品房销售',
    'hits' => 0,
    'score' => 0,
  ),
  1876 => 
  array (
    '_id' => '商品房预售',
    'word' => '商品房预售',
    'hits' => 0,
    'score' => 0,
  ),
  1877 => 
  array (
    '_id' => '商品房预售管理',
    'word' => '商品房预售管理',
    'hits' => 0,
    'score' => 0,
  ),
  1878 => 
  array (
    '_id' => '商品房预售管理办法',
    'word' => '商品房预售管理办法',
    'hits' => 0,
    'score' => 0,
  ),
  1879 => 
  array (
    '_id' => '商品房预售合同',
    'word' => '商品房预售合同',
    'hits' => 0,
    'score' => 0,
  ),
  1880 => 
  array (
    '_id' => '商品房预售许可证',
    'word' => '商品房预售许可证',
    'hits' => 0,
    'score' => 0,
  ),
  1881 => 
  array (
    '_id' => '商品房预售证',
    'word' => '商品房预售证',
    'hits' => 0,
    'score' => 0,
  ),
  1882 => 
  array (
    '_id' => '商品期货',
    'word' => '商品期货',
    'hits' => 0,
    'score' => 0,
  ),
  1883 => 
  array (
    '_id' => '商品住宅',
    'word' => '商品住宅',
    'hits' => 0,
    'score' => 0,
  ),
  1884 => 
  array (
    '_id' => '商铺风水',
    'word' => '商铺风水',
    'hits' => 0,
    'score' => 0,
  ),
  1885 => 
  array (
    '_id' => '商铺过户费',
    'word' => '商铺过户费',
    'hits' => 0,
    'score' => 0,
  ),
  1886 => 
  array (
    '_id' => '商铺买卖合同',
    'word' => '商铺买卖合同',
    'hits' => 0,
    'score' => 0,
  ),
  1887 => 
  array (
    '_id' => '商铺投资',
    'word' => '商铺投资',
    'hits' => 0,
    'score' => 0,
  ),
  1888 => 
  array (
    '_id' => '商铺转租合同',
    'word' => '商铺转租合同',
    'hits' => 0,
    'score' => 0,
  ),
  1889 => 
  array (
    '_id' => '商铺租赁',
    'word' => '商铺租赁',
    'hits' => 0,
    'score' => 0,
  ),
  1890 => 
  array (
    '_id' => '商铺租赁合同',
    'word' => '商铺租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  1891 => 
  array (
    '_id' => '商丘公积金贷款',
    'word' => '商丘公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1892 => 
  array (
    '_id' => '商丘住房公积金查询',
    'word' => '商丘住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1893 => 
  array (
    '_id' => '商丘住房公积金提取',
    'word' => '商丘住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1894 => 
  array (
    '_id' => '商圈',
    'word' => '商圈',
    'hits' => 0,
    'score' => 0,
  ),
  1895 => 
  array (
    '_id' => '商业贷款',
    'word' => '商业贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1896 => 
  array (
    '_id' => '商业贷款利率',
    'word' => '商业贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  1897 => 
  array (
    '_id' => '商业贷款利率多少',
    'word' => '商业贷款利率多少',
    'hits' => 0,
    'score' => 0,
  ),
  1898 => 
  array (
    '_id' => '商业街',
    'word' => '商业街',
    'hits' => 0,
    'score' => 0,
  ),
  1899 => 
  array (
    '_id' => '商业配套',
    'word' => '商业配套',
    'hits' => 0,
    'score' => 0,
  ),
  1900 => 
  array (
    '_id' => '商业用房',
    'word' => '商业用房',
    'hits' => 0,
    'score' => 0,
  ),
  1901 => 
  array (
    '_id' => '商业住宅和普通住宅的区别',
    'word' => '商业住宅和普通住宅的区别',
    'hits' => 0,
    'score' => 0,
  ),
  1902 => 
  array (
    '_id' => '商住房',
    'word' => '商住房',
    'hits' => 0,
    'score' => 0,
  ),
  1903 => 
  array (
    '_id' => '商住两用房落户',
    'word' => '商住两用房落户',
    'hits' => 0,
    'score' => 0,
  ),
  1904 => 
  array (
    '_id' => '商住楼',
    'word' => '商住楼',
    'hits' => 0,
    'score' => 0,
  ),
  1905 => 
  array (
    '_id' => '上海房产税如何征收',
    'word' => '上海房产税如何征收',
    'hits' => 0,
    'score' => 0,
  ),
  1906 => 
  array (
    '_id' => '上海房产证',
    'word' => '上海房产证',
    'hits' => 0,
    'score' => 0,
  ),
  1907 => 
  array (
    '_id' => '上海房产证办理流程',
    'word' => '上海房产证办理流程',
    'hits' => 0,
    'score' => 0,
  ),
  1908 => 
  array (
    '_id' => '上海房贷利率',
    'word' => '上海房贷利率',
    'hits' => 0,
    'score' => 0,
  ),
  1909 => 
  array (
    '_id' => '上海公积金贷款',
    'word' => '上海公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1910 => 
  array (
    '_id' => '上海经济适用房申请条件',
    'word' => '上海经济适用房申请条件',
    'hits' => 0,
    'score' => 0,
  ),
  1911 => 
  array (
    '_id' => '上海市公积金基数上限',
    'word' => '上海市公积金基数上限',
    'hits' => 0,
    'score' => 0,
  ),
  1912 => 
  array (
    '_id' => '上跃式',
    'word' => '上跃式',
    'hits' => 0,
    'score' => 0,
  ),
  1913 => 
  array (
    '_id' => '尚高卫浴',
    'word' => '尚高卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  1914 => 
  array (
    '_id' => '尚品本色木门',
    'word' => '尚品本色木门',
    'hits' => 0,
    'score' => 0,
  ),
  1915 => 
  array (
    '_id' => '尚品宅配橱柜',
    'word' => '尚品宅配橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  1916 => 
  array (
    '_id' => '尚品宅配家具',
    'word' => '尚品宅配家具',
    'hits' => 0,
    'score' => 0,
  ),
  1917 => 
  array (
    '_id' => '尚品宅配衣柜',
    'word' => '尚品宅配衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1918 => 
  array (
    '_id' => '韶关住房公积金提取',
    'word' => '韶关住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1919 => 
  array (
    '_id' => '邵阳住房公积金提取',
    'word' => '邵阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1920 => 
  array (
    '_id' => '绍兴住房公积金查询',
    'word' => '绍兴住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1921 => 
  array (
    '_id' => '社区公摊',
    'word' => '社区公摊',
    'hits' => 0,
    'score' => 0,
  ),
  1922 => 
  array (
    '_id' => '申花洗衣机',
    'word' => '申花洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  1923 => 
  array (
    '_id' => '申鹭达浴缸',
    'word' => '申鹭达浴缸',
    'hits' => 0,
    'score' => 0,
  ),
  1924 => 
  array (
    '_id' => '伸缩缝',
    'word' => '伸缩缝',
    'hits' => 0,
    'score' => 0,
  ),
  1925 => 
  array (
    '_id' => '绅仕衣柜',
    'word' => '绅仕衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1926 => 
  array (
    '_id' => '玛瓷砖',
    'word' => '玛瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  1927 => 
  array (
    '_id' => '深圳公租房',
    'word' => '深圳公租房',
    'hits' => 0,
    'score' => 0,
  ),
  1928 => 
  array (
    '_id' => '深圳廉租房',
    'word' => '深圳廉租房',
    'hits' => 0,
    'score' => 0,
  ),
  1929 => 
  array (
    '_id' => '深圳首套房贷基准利率',
    'word' => '深圳首套房贷基准利率',
    'hits' => 0,
    'score' => 0,
  ),
  1930 => 
  array (
    '_id' => '深圳住房公积金提取',
    'word' => '深圳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1931 => 
  array (
    '_id' => '神农架公积金贷款',
    'word' => '神农架公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1932 => 
  array (
    '_id' => '神农架住房公积金查询',
    'word' => '神农架住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1933 => 
  array (
    '_id' => '沈阳公积金贷款',
    'word' => '沈阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1934 => 
  array (
    '_id' => '沈阳住房公积金提取',
    'word' => '沈阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1935 => 
  array (
    '_id' => '生活家地板',
    'word' => '生活家地板',
    'hits' => 0,
    'score' => 0,
  ),
  1936 => 
  array (
    '_id' => '生料带怎么缠',
    'word' => '生料带怎么缠',
    'hits' => 0,
    'score' => 0,
  ),
  1937 => 
  array (
    '_id' => '生态木吊顶',
    'word' => '生态木吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  1938 => 
  array (
    '_id' => '胜球灯饰',
    'word' => '胜球灯饰',
    'hits' => 0,
    'score' => 0,
  ),
  1939 => 
  array (
    '_id' => '圣加诺地板',
    'word' => '圣加诺地板',
    'hits' => 0,
    'score' => 0,
  ),
  1940 => 
  array (
    '_id' => '圣象地板',
    'word' => '圣象地板',
    'hits' => 0,
    'score' => 0,
  ),
  1941 => 
  array (
    '_id' => '十堰公积金贷款',
    'word' => '十堰公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1942 => 
  array (
    '_id' => '十堰住房公积金提取',
    'word' => '十堰住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1943 => 
  array (
    '_id' => '什么床垫比较好',
    'word' => '什么床垫比较好',
    'hits' => 0,
    'score' => 0,
  ),
  1944 => 
  array (
    '_id' => '什么瓷砖性价比高',
    'word' => '什么瓷砖性价比高',
    'hits' => 0,
    'score' => 0,
  ),
  1945 => 
  array (
    '_id' => '什么叫期房',
    'word' => '什么叫期房',
    'hits' => 0,
    'score' => 0,
  ),
  1946 => 
  array (
    '_id' => '什么叫印花税',
    'word' => '什么叫印花税',
    'hits' => 0,
    'score' => 0,
  ),
  1947 => 
  array (
    '_id' => '什么是格式条款',
    'word' => '什么是格式条款',
    'hits' => 0,
    'score' => 0,
  ),
  1948 => 
  array (
    '_id' => '什么是棚户区',
    'word' => '什么是棚户区',
    'hits' => 0,
    'score' => 0,
  ),
  1949 => 
  array (
    '_id' => '什么是容积率',
    'word' => '什么是容积率',
    'hits' => 0,
    'score' => 0,
  ),
  1950 => 
  array (
    '_id' => '什么是塔楼',
    'word' => '什么是塔楼',
    'hits' => 0,
    'score' => 0,
  ),
  1951 => 
  array (
    '_id' => '什么是以房养老',
    'word' => '什么是以房养老',
    'hits' => 0,
    'score' => 0,
  ),
  1952 => 
  array (
    '_id' => '什木坊木门',
    'word' => '什木坊木门',
    'hits' => 0,
    'score' => 0,
  ),
  1953 => 
  array (
    '_id' => '石材',
    'word' => '石材',
    'hits' => 0,
    'score' => 0,
  ),
  1954 => 
  array (
    '_id' => '石家庄住房公积金提取',
    'word' => '石家庄住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1955 => 
  array (
    '_id' => '石榴石',
    'word' => '石榴石',
    'hits' => 0,
    'score' => 0,
  ),
  1956 => 
  array (
    '_id' => '石狮子',
    'word' => '石狮子',
    'hits' => 0,
    'score' => 0,
  ),
  1957 => 
  array (
    '_id' => '石塑地板',
    'word' => '石塑地板',
    'hits' => 0,
    'score' => 0,
  ),
  1958 => 
  array (
    '_id' => '石英石',
    'word' => '石英石',
    'hits' => 0,
    'score' => 0,
  ),
  1959 => 
  array (
    '_id' => '石嘴山公积金贷款',
    'word' => '石嘴山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  1960 => 
  array (
    '_id' => '石嘴山住房公积金查询',
    'word' => '石嘴山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  1961 => 
  array (
    '_id' => '石嘴山住房公积金提取',
    'word' => '石嘴山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  1962 => 
  array (
    '_id' => '实测面积',
    'word' => '实测面积',
    'hits' => 0,
    'score' => 0,
  ),
  1963 => 
  array (
    '_id' => '实木茶几',
    'word' => '实木茶几',
    'hits' => 0,
    'score' => 0,
  ),
  1964 => 
  array (
    '_id' => '实木橱柜',
    'word' => '实木橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  1965 => 
  array (
    '_id' => '实木地板',
    'word' => '实木地板',
    'hits' => 0,
    'score' => 0,
  ),
  1966 => 
  array (
    '_id' => '实木地板怎么保养',
    'word' => '实木地板怎么保养',
    'hits' => 0,
    'score' => 0,
  ),
  1967 => 
  array (
    '_id' => '实木复合地板',
    'word' => '实木复合地板',
    'hits' => 0,
    'score' => 0,
  ),
  1968 => 
  array (
    '_id' => '实木家具保养',
    'word' => '实木家具保养',
    'hits' => 0,
    'score' => 0,
  ),
  1969 => 
  array (
    '_id' => '实木门',
    'word' => '实木门',
    'hits' => 0,
    'score' => 0,
  ),
  1970 => 
  array (
    '_id' => '实木沙发',
    'word' => '实木沙发',
    'hits' => 0,
    'score' => 0,
  ),
  1971 => 
  array (
    '_id' => '实木双层床',
    'word' => '实木双层床',
    'hits' => 0,
    'score' => 0,
  ),
  1972 => 
  array (
    '_id' => '实木衣柜',
    'word' => '实木衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1973 => 
  array (
    '_id' => '实体',
    'word' => '实体',
    'hits' => 0,
    'score' => 0,
  ),
  1974 => 
  array (
    '_id' => '实用率',
    'word' => '实用率',
    'hits' => 0,
    'score' => 0,
  ),
  1975 => 
  array (
    '_id' => '实用面积',
    'word' => '实用面积',
    'hits' => 0,
    'score' => 0,
  ),
  1976 => 
  array (
    '_id' => '史丹利衣柜',
    'word' => '史丹利衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  1977 => 
  array (
    '_id' => '史密斯热水器',
    'word' => '史密斯热水器',
    'hits' => 0,
    'score' => 0,
  ),
  1978 => 
  array (
    '_id' => '使用面积',
    'word' => '使用面积',
    'hits' => 0,
    'score' => 0,
  ),
  1979 => 
  array (
    '_id' => '市场价格',
    'word' => '市场价格',
    'hits' => 0,
    'score' => 0,
  ),
  1980 => 
  array (
    '_id' => '市场租金',
    'word' => '市场租金',
    'hits' => 0,
    'score' => 0,
  ),
  1981 => 
  array (
    '_id' => '市政公用设施用地',
    'word' => '市政公用设施用地',
    'hits' => 0,
    'score' => 0,
  ),
  1982 => 
  array (
    '_id' => '市值',
    'word' => '市值',
    'hits' => 0,
    'score' => 0,
  ),
  1983 => 
  array (
    '_id' => '室内除甲醛植物',
    'word' => '室内除甲醛植物',
    'hits' => 0,
    'score' => 0,
  ),
  1984 => 
  array (
    '_id' => '室内门',
    'word' => '室内门',
    'hits' => 0,
    'score' => 0,
  ),
  1985 => 
  array (
    '_id' => '室内配置',
    'word' => '室内配置',
    'hits' => 0,
    'score' => 0,
  ),
  1986 => 
  array (
    '_id' => '室内设计手绘',
    'word' => '室内设计手绘',
    'hits' => 0,
    'score' => 0,
  ),
  1987 => 
  array (
    '_id' => '室内手绘效果图',
    'word' => '室内手绘效果图',
    'hits' => 0,
    'score' => 0,
  ),
  1988 => 
  array (
    '_id' => '室内装饰材料',
    'word' => '室内装饰材料',
    'hits' => 0,
    'score' => 0,
  ),
  1989 => 
  array (
    '_id' => '室内装饰设计',
    'word' => '室内装饰设计',
    'hits' => 0,
    'score' => 0,
  ),
  1990 => 
  array (
    '_id' => '室内装饰装修施工组织设计方案',
    'word' => '室内装饰装修施工组织设计方案',
    'hits' => 0,
    'score' => 0,
  ),
  1991 => 
  array (
    '_id' => '室内装修',
    'word' => '室内装修',
    'hits' => 0,
    'score' => 0,
  ),
  1992 => 
  array (
    '_id' => '室内装修材料',
    'word' => '室内装修材料',
    'hits' => 0,
    'score' => 0,
  ),
  1993 => 
  array (
    '_id' => '室内装修风格',
    'word' => '室内装修风格',
    'hits' => 0,
    'score' => 0,
  ),
  1994 => 
  array (
    '_id' => '室内装修风水大忌',
    'word' => '室内装修风水大忌',
    'hits' => 0,
    'score' => 0,
  ),
  1995 => 
  array (
    '_id' => '室内装修设计',
    'word' => '室内装修设计',
    'hits' => 0,
    'score' => 0,
  ),
  1996 => 
  array (
    '_id' => '收房',
    'word' => '收房',
    'hits' => 0,
    'score' => 0,
  ),
  1997 => 
  array (
    '_id' => '收入证明范本',
    'word' => '收入证明范本',
    'hits' => 0,
    'score' => 0,
  ),
  1998 => 
  array (
    '_id' => '收入证明房贷',
    'word' => '收入证明房贷',
    'hits' => 0,
    'score' => 0,
  ),
  1999 => 
  array (
    '_id' => '收入证明模板下载',
    'word' => '收入证明模板下载',
    'hits' => 0,
    'score' => 0,
  ),
  2000 => 
  array (
    '_id' => '收入证明怎么开',
    'word' => '收入证明怎么开',
    'hits' => 0,
    'score' => 0,
  ),
  2001 => 
  array (
    '_id' => '手绘背景墙',
    'word' => '手绘背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  2002 => 
  array (
    '_id' => '手绘电视墙价格',
    'word' => '手绘电视墙价格',
    'hits' => 0,
    'score' => 0,
  ),
  2003 => 
  array (
    '_id' => '手绘墙画价格',
    'word' => '手绘墙画价格',
    'hits' => 0,
    'score' => 0,
  ),
  2004 => 
  array (
    '_id' => '首付比例',
    'word' => '首付比例',
    'hits' => 0,
    'score' => 0,
  ),
  2005 => 
  array (
    '_id' => '首付贷款',
    'word' => '首付贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2006 => 
  array (
    '_id' => '首付分期',
    'word' => '首付分期',
    'hits' => 0,
    'score' => 0,
  ),
  2007 => 
  array (
    '_id' => '首套房',
    'word' => '首套房',
    'hits' => 0,
    'score' => 0,
  ),
  2008 => 
  array (
    '_id' => '首套房贷',
    'word' => '首套房贷',
    'hits' => 0,
    'score' => 0,
  ),
  2009 => 
  array (
    '_id' => '首套房贷利率变化',
    'word' => '首套房贷利率变化',
    'hits' => 0,
    'score' => 0,
  ),
  2010 => 
  array (
    '_id' => '首套房定义',
    'word' => '首套房定义',
    'hits' => 0,
    'score' => 0,
  ),
  2011 => 
  array (
    '_id' => '首套房契税',
    'word' => '首套房契税',
    'hits' => 0,
    'score' => 0,
  ),
  2012 => 
  array (
    '_id' => '首套房证明',
    'word' => '首套房证明',
    'hits' => 0,
    'score' => 0,
  ),
  2013 => 
  array (
    '_id' => '寿光公积金贷款',
    'word' => '寿光公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2014 => 
  array (
    '_id' => '寿光住房公积金提取',
    'word' => '寿光住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2015 => 
  array (
    '_id' => '售后公房',
    'word' => '售后公房',
    'hits' => 0,
    'score' => 0,
  ),
  2016 => 
  array (
    '_id' => '书房风水',
    'word' => '书房风水',
    'hits' => 0,
    'score' => 0,
  ),
  2017 => 
  array (
    '_id' => '书房装修',
    'word' => '书房装修',
    'hits' => 0,
    'score' => 0,
  ),
  2018 => 
  array (
    '_id' => '书柜',
    'word' => '书柜',
    'hits' => 0,
    'score' => 0,
  ),
  2019 => 
  array (
    '_id' => '书架',
    'word' => '书架',
    'hits' => 0,
    'score' => 0,
  ),
  2020 => 
  array (
    '_id' => '树桩盆景',
    'word' => '树桩盆景',
    'hits' => 0,
    'score' => 0,
  ),
  2021 => 
  array (
    '_id' => '数字电视安装',
    'word' => '数字电视安装',
    'hits' => 0,
    'score' => 0,
  ),
  2022 => 
  array (
    '_id' => '帅康热水器',
    'word' => '帅康热水器',
    'hits' => 0,
    'score' => 0,
  ),
  2023 => 
  array (
    '_id' => '双壁波纹管',
    'word' => '双壁波纹管',
    'hits' => 0,
    'score' => 0,
  ),
  2024 => 
  array (
    '_id' => '双缸洗衣机',
    'word' => '双缸洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  2025 => 
  array (
    '_id' => '双虎家私',
    'word' => '双虎家私',
    'hits' => 0,
    'score' => 0,
  ),
  2026 => 
  array (
    '_id' => '双孔水龙头',
    'word' => '双孔水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  2027 => 
  array (
    '_id' => '双控开关',
    'word' => '双控开关',
    'hits' => 0,
    'score' => 0,
  ),
  2028 => 
  array (
    '_id' => '双拼别墅',
    'word' => '双拼别墅',
    'hits' => 0,
    'score' => 0,
  ),
  2029 => 
  array (
    '_id' => '双塔油漆',
    'word' => '双塔油漆',
    'hits' => 0,
    'score' => 0,
  ),
  2030 => 
  array (
    '_id' => '双鸭山公积金贷款',
    'word' => '双鸭山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2031 => 
  array (
    '_id' => '双鸭山住房公积金查询',
    'word' => '双鸭山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2032 => 
  array (
    '_id' => '双鸭山住房公积金提取',
    'word' => '双鸭山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2033 => 
  array (
    '_id' => '水电施工之标准水电验收',
    'word' => '水电施工之标准水电验收',
    'hits' => 0,
    'score' => 0,
  ),
  2034 => 
  array (
    '_id' => '水电装修注意事项',
    'word' => '水电装修注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  2035 => 
  array (
    '_id' => '水晶灯',
    'word' => '水晶灯',
    'hits' => 0,
    'score' => 0,
  ),
  2036 => 
  array (
    '_id' => '水晶灯箱',
    'word' => '水晶灯箱',
    'hits' => 0,
    'score' => 0,
  ),
  2037 => 
  array (
    '_id' => '水晶吊灯',
    'word' => '水晶吊灯',
    'hits' => 0,
    'score' => 0,
  ),
  2038 => 
  array (
    '_id' => '水晶石',
    'word' => '水晶石',
    'hits' => 0,
    'score' => 0,
  ),
  2039 => 
  array (
    '_id' => '水晶珠帘',
    'word' => '水晶珠帘',
    'hits' => 0,
    'score' => 0,
  ),
  2040 => 
  array (
    '_id' => '水景住宅',
    'word' => '水景住宅',
    'hits' => 0,
    'score' => 0,
  ),
  2041 => 
  array (
    '_id' => '水龙头',
    'word' => '水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  2042 => 
  array (
    '_id' => '水龙头品牌',
    'word' => '水龙头品牌',
    'hits' => 0,
    'score' => 0,
  ),
  2043 => 
  array (
    '_id' => '水磨石',
    'word' => '水磨石',
    'hits' => 0,
    'score' => 0,
  ),
  2044 => 
  array (
    '_id' => '水泥',
    'word' => '水泥',
    'hits' => 0,
    'score' => 0,
  ),
  2045 => 
  array (
    '_id' => '水泥橱柜',
    'word' => '水泥橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  2046 => 
  array (
    '_id' => '水泥地面做法',
    'word' => '水泥地面做法',
    'hits' => 0,
    'score' => 0,
  ),
  2047 => 
  array (
    '_id' => '水星家纺',
    'word' => '水星家纺',
    'hits' => 0,
    'score' => 0,
  ),
  2048 => 
  array (
    '_id' => '税费',
    'word' => '税费',
    'hits' => 0,
    'score' => 0,
  ),
  2049 => 
  array (
    '_id' => '顺辉瓷砖',
    'word' => '顺辉瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  2050 => 
  array (
    '_id' => '朔州公积金贷款',
    'word' => '朔州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2051 => 
  array (
    '_id' => '朔州住房公积金查询',
    'word' => '朔州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2052 => 
  array (
    '_id' => '朔州住房公积金提取',
    'word' => '朔州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2053 => 
  array (
    '_id' => '私房',
    'word' => '私房',
    'hits' => 0,
    'score' => 0,
  ),
  2054 => 
  array (
    '_id' => '私密性',
    'word' => '私密性',
    'hits' => 0,
    'score' => 0,
  ),
  2055 => 
  array (
    '_id' => '私有(自有)房产',
    'word' => '私有(自有)房产',
    'hits' => 0,
    'score' => 0,
  ),
  2056 => 
  array (
    '_id' => '四平住房公积金查询',
    'word' => '四平住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2057 => 
  array (
    '_id' => '松下灯具',
    'word' => '松下灯具',
    'hits' => 0,
    'score' => 0,
  ),
  2058 => 
  array (
    '_id' => '松下电视',
    'word' => '松下电视',
    'hits' => 0,
    'score' => 0,
  ),
  2059 => 
  array (
    '_id' => '松下空调',
    'word' => '松下空调',
    'hits' => 0,
    'score' => 0,
  ),
  2060 => 
  array (
    '_id' => '松下马桶',
    'word' => '松下马桶',
    'hits' => 0,
    'score' => 0,
  ),
  2061 => 
  array (
    '_id' => '松下卫浴',
    'word' => '松下卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  2062 => 
  array (
    '_id' => '松下浴霸',
    'word' => '松下浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  2063 => 
  array (
    '_id' => '松宇壁纸',
    'word' => '松宇壁纸',
    'hits' => 0,
    'score' => 0,
  ),
  2064 => 
  array (
    '_id' => '松原住房公积金提取',
    'word' => '松原住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2065 => 
  array (
    '_id' => '苏州住房公积金查询',
    'word' => '苏州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2066 => 
  array (
    '_id' => '苏州住房公积金提取',
    'word' => '苏州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2067 => 
  array (
    '_id' => '宿迁公积金贷款',
    'word' => '宿迁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2068 => 
  array (
    '_id' => '宿州公积金贷款',
    'word' => '宿州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2069 => 
  array (
    '_id' => '宿州住房公积金查询',
    'word' => '宿州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2070 => 
  array (
    '_id' => '宿州住房公积金提取',
    'word' => '宿州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2071 => 
  array (
    '_id' => '塑钢窗',
    'word' => '塑钢窗',
    'hits' => 0,
    'score' => 0,
  ),
  2072 => 
  array (
    '_id' => '塑钢门窗',
    'word' => '塑钢门窗',
    'hits' => 0,
    'score' => 0,
  ),
  2073 => 
  array (
    '_id' => '塑料地板',
    'word' => '塑料地板',
    'hits' => 0,
    'score' => 0,
  ),
  2074 => 
  array (
    '_id' => '绥化公积金贷款',
    'word' => '绥化公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2075 => 
  array (
    '_id' => '绥化住房公积金查询',
    'word' => '绥化住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2076 => 
  array (
    '_id' => '绥化住房公积金提取',
    'word' => '绥化住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2077 => 
  array (
    '_id' => '随州公积金贷款',
    'word' => '随州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2078 => 
  array (
    '_id' => '随州住房公积金查询',
    'word' => '随州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2079 => 
  array (
    '_id' => '随州住房公积金提取',
    'word' => '随州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2080 => 
  array (
    '_id' => '遂宁住房公积金查询',
    'word' => '遂宁住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2081 => 
  array (
    '_id' => '遂宁住房公积金提取',
    'word' => '遂宁住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2082 => 
  array (
    '_id' => '榫卯结合',
    'word' => '榫卯结合',
    'hits' => 0,
    'score' => 0,
  ),
  2083 => 
  array (
    '_id' => '榫头折断',
    'word' => '榫头折断',
    'hits' => 0,
    'score' => 0,
  ),
  2084 => 
  array (
    '_id' => '索菲亚衣柜',
    'word' => '索菲亚衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  2085 => 
  array (
    '_id' => '锁具',
    'word' => '锁具',
    'hits' => 0,
    'score' => 0,
  ),
  2086 => 
  array (
    '_id' => '他项权证',
    'word' => '他项权证',
    'hits' => 0,
    'score' => 0,
  ),
  2087 => 
  array (
    '_id' => '塔城公积金贷款',
    'word' => '塔城公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2088 => 
  array (
    '_id' => '塔城住房公积金提取',
    'word' => '塔城住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2089 => 
  array (
    '_id' => '塔式高层住宅',
    'word' => '塔式高层住宅',
    'hits' => 0,
    'score' => 0,
  ),
  2090 => 
  array (
    '_id' => '榻榻米',
    'word' => '榻榻米',
    'hits' => 0,
    'score' => 0,
  ),
  2091 => 
  array (
    '_id' => '台州住房公积金提取',
    'word' => '台州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2092 => 
  array (
    '_id' => '太仓住房公积金查询',
    'word' => '太仓住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2093 => 
  array (
    '_id' => '太湖山木门',
    'word' => '太湖山木门',
    'hits' => 0,
    'score' => 0,
  ),
  2094 => 
  array (
    '_id' => '太阳能灯',
    'word' => '太阳能灯',
    'hits' => 0,
    'score' => 0,
  ),
  2095 => 
  array (
    '_id' => '太阳能空调',
    'word' => '太阳能空调',
    'hits' => 0,
    'score' => 0,
  ),
  2096 => 
  array (
    '_id' => '太阳能路灯',
    'word' => '太阳能路灯',
    'hits' => 0,
    'score' => 0,
  ),
  2097 => 
  array (
    '_id' => '太阳能热水器',
    'word' => '太阳能热水器',
    'hits' => 0,
    'score' => 0,
  ),
  2098 => 
  array (
    '_id' => '太阳能庭院灯',
    'word' => '太阳能庭院灯',
    'hits' => 0,
    'score' => 0,
  ),
  2099 => 
  array (
    '_id' => '太原住房公积金查询',
    'word' => '太原住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2100 => 
  array (
    '_id' => '钛镁合金推拉门',
    'word' => '钛镁合金推拉门',
    'hits' => 0,
    'score' => 0,
  ),
  2101 => 
  array (
    '_id' => '泰安住房公积金查询',
    'word' => '泰安住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2102 => 
  array (
    '_id' => '泰普尔床垫',
    'word' => '泰普尔床垫',
    'hits' => 0,
    'score' => 0,
  ),
  2103 => 
  array (
    '_id' => '泰山石',
    'word' => '泰山石',
    'hits' => 0,
    'score' => 0,
  ),
  2104 => 
  array (
    '_id' => '泰州住房公积金查询',
    'word' => '泰州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2105 => 
  array (
    '_id' => '泰州住房公积金提取',
    'word' => '泰州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2106 => 
  array (
    '_id' => '碳晶地暖',
    'word' => '碳晶地暖',
    'hits' => 0,
    'score' => 0,
  ),
  2107 => 
  array (
    '_id' => '唐山公积金贷款',
    'word' => '唐山公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2108 => 
  array (
    '_id' => '唐山住房公积金查询',
    'word' => '唐山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2109 => 
  array (
    '_id' => '唐山住房公积金提取',
    'word' => '唐山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2110 => 
  array (
    '_id' => '躺椅',
    'word' => '躺椅',
    'hits' => 0,
    'score' => 0,
  ),
  2111 => 
  array (
    '_id' => '陶瓷茶具',
    'word' => '陶瓷茶具',
    'hits' => 0,
    'score' => 0,
  ),
  2112 => 
  array (
    '_id' => '陶瓷工艺品',
    'word' => '陶瓷工艺品',
    'hits' => 0,
    'score' => 0,
  ),
  2113 => 
  array (
    '_id' => '陶粒混凝土',
    'word' => '陶粒混凝土',
    'hits' => 0,
    'score' => 0,
  ),
  2114 => 
  array (
    '_id' => '套房家具',
    'word' => '套房家具',
    'hits' => 0,
    'score' => 0,
  ),
  2115 => 
  array (
    '_id' => '套内公摊',
    'word' => '套内公摊',
    'hits' => 0,
    'score' => 0,
  ),
  2116 => 
  array (
    '_id' => '套内建筑面积',
    'word' => '套内建筑面积',
    'hits' => 0,
    'score' => 0,
  ),
  2117 => 
  array (
    '_id' => '套内建筑面积是什么意思',
    'word' => '套内建筑面积是什么意思',
    'hits' => 0,
    'score' => 0,
  ),
  2118 => 
  array (
    '_id' => '套内面积',
    'word' => '套内面积',
    'hits' => 0,
    'score' => 0,
  ),
  2119 => 
  array (
    '_id' => '套内使用面积系数',
    'word' => '套内使用面积系数',
    'hits' => 0,
    'score' => 0,
  ),
  2120 => 
  array (
    '_id' => '藤制家具',
    'word' => '藤制家具',
    'hits' => 0,
    'score' => 0,
  ),
  2121 => 
  array (
    '_id' => '踢脚线尺寸',
    'word' => '踢脚线尺寸',
    'hits' => 0,
    'score' => 0,
  ),
  2122 => 
  array (
    '_id' => '提前还贷',
    'word' => '提前还贷',
    'hits' => 0,
    'score' => 0,
  ),
  2123 => 
  array (
    '_id' => '提前还贷划算吗',
    'word' => '提前还贷划算吗',
    'hits' => 0,
    'score' => 0,
  ),
  2124 => 
  array (
    '_id' => '提前还贷利息怎么算',
    'word' => '提前还贷利息怎么算',
    'hits' => 0,
    'score' => 0,
  ),
  2125 => 
  array (
    '_id' => '提前还贷流程',
    'word' => '提前还贷流程',
    'hits' => 0,
    'score' => 0,
  ),
  2126 => 
  array (
    '_id' => '提前还房贷',
    'word' => '提前还房贷',
    'hits' => 0,
    'score' => 0,
  ),
  2127 => 
  array (
    '_id' => '提前还房贷利息',
    'word' => '提前还房贷利息',
    'hits' => 0,
    'score' => 0,
  ),
  2128 => 
  array (
    '_id' => '提取住房公积金',
    'word' => '提取住房公积金',
    'hits' => 0,
    'score' => 0,
  ),
  2129 => 
  array (
    '_id' => '天花板',
    'word' => '天花板',
    'hits' => 0,
    'score' => 0,
  ),
  2130 => 
  array (
    '_id' => '天花灯',
    'word' => '天花灯',
    'hits' => 0,
    'score' => 0,
  ),
  2131 => 
  array (
    '_id' => '天津德曼合页',
    'word' => '天津德曼合页',
    'hits' => 0,
    'score' => 0,
  ),
  2132 => 
  array (
    '_id' => '天津公积金贷款',
    'word' => '天津公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2133 => 
  array (
    '_id' => '天津住房公积金提取',
    'word' => '天津住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2134 => 
  array (
    '_id' => '天伦地毯',
    'word' => '天伦地毯',
    'hits' => 0,
    'score' => 0,
  ),
  2135 => 
  array (
    '_id' => '天门住房公积金查询',
    'word' => '天门住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2136 => 
  array (
    '_id' => '天门住房公积金提取',
    'word' => '天门住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2137 => 
  array (
    '_id' => '天然林地板',
    'word' => '天然林地板',
    'hits' => 0,
    'score' => 0,
  ),
  2138 => 
  array (
    '_id' => '天然气热水器',
    'word' => '天然气热水器',
    'hits' => 0,
    'score' => 0,
  ),
  2139 => 
  array (
    '_id' => '天水公积金贷款',
    'word' => '天水公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2140 => 
  array (
    '_id' => '天水住房公积金查询',
    'word' => '天水住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2141 => 
  array (
    '_id' => '天天木门',
    'word' => '天天木门',
    'hits' => 0,
    'score' => 0,
  ),
  2142 => 
  array (
    '_id' => '天雅地毯',
    'word' => '天雅地毯',
    'hits' => 0,
    'score' => 0,
  ),
  2143 => 
  array (
    '_id' => '铁岭公积金贷款',
    'word' => '铁岭公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2144 => 
  array (
    '_id' => '铁岭住房公积金查询',
    'word' => '铁岭住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2145 => 
  array (
    '_id' => '铁岭住房公积金提取',
    'word' => '铁岭住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2146 => 
  array (
    '_id' => '铁艺护栏',
    'word' => '铁艺护栏',
    'hits' => 0,
    'score' => 0,
  ),
  2147 => 
  array (
    '_id' => '铁艺花架',
    'word' => '铁艺花架',
    'hits' => 0,
    'score' => 0,
  ),
  2148 => 
  array (
    '_id' => '铁艺家具',
    'word' => '铁艺家具',
    'hits' => 0,
    'score' => 0,
  ),
  2149 => 
  array (
    '_id' => '铁艺栏杆',
    'word' => '铁艺栏杆',
    'hits' => 0,
    'score' => 0,
  ),
  2150 => 
  array (
    '_id' => '庭院风水',
    'word' => '庭院风水',
    'hits' => 0,
    'score' => 0,
  ),
  2151 => 
  array (
    '_id' => '通化公积金贷款',
    'word' => '通化公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2152 => 
  array (
    '_id' => '通化住房公积金查询',
    'word' => '通化住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2153 => 
  array (
    '_id' => '通廊式高层住宅',
    'word' => '通廊式高层住宅',
    'hits' => 0,
    'score' => 0,
  ),
  2154 => 
  array (
    '_id' => '通辽住房公积金提取',
    'word' => '通辽住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2155 => 
  array (
    '_id' => '通体砖',
    'word' => '通体砖',
    'hits' => 0,
    'score' => 0,
  ),
  2156 => 
  array (
    '_id' => '桐城住房公积金查询',
    'word' => '桐城住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2157 => 
  array (
    '_id' => '桐乡住房公积金查询',
    'word' => '桐乡住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2158 => 
  array (
    '_id' => '桐乡住房公积金提取',
    'word' => '桐乡住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2159 => 
  array (
    '_id' => '铜陵公积金贷款',
    'word' => '铜陵公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2160 => 
  array (
    '_id' => '铜陵住房公积金查询',
    'word' => '铜陵住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2161 => 
  array (
    '_id' => '铜门',
    'word' => '铜门',
    'hits' => 0,
    'score' => 0,
  ),
  2162 => 
  array (
    '_id' => '铜仁公积金贷款',
    'word' => '铜仁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2163 => 
  array (
    '_id' => '铜仁住房公积金提取',
    'word' => '铜仁住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2164 => 
  array (
    '_id' => '童装店装修效果图',
    'word' => '童装店装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  2165 => 
  array (
    '_id' => '统帅空调',
    'word' => '统帅空调',
    'hits' => 0,
    'score' => 0,
  ),
  2166 => 
  array (
    '_id' => '投资性房地产',
    'word' => '投资性房地产',
    'hits' => 0,
    'score' => 0,
  ),
  2167 => 
  array (
    '_id' => '土地出让',
    'word' => '土地出让',
    'hits' => 0,
    'score' => 0,
  ),
  2168 => 
  array (
    '_id' => '土地出让合同',
    'word' => '土地出让合同',
    'hits' => 0,
    'score' => 0,
  ),
  2169 => 
  array (
    '_id' => '土地出让金',
    'word' => '土地出让金',
    'hits' => 0,
    'score' => 0,
  ),
  2170 => 
  array (
    '_id' => '土地出让金标准',
    'word' => '土地出让金标准',
    'hits' => 0,
    'score' => 0,
  ),
  2171 => 
  array (
    '_id' => '土地的挂牌交易',
    'word' => '土地的挂牌交易',
    'hits' => 0,
    'score' => 0,
  ),
  2172 => 
  array (
    '_id' => '土地登记',
    'word' => '土地登记',
    'hits' => 0,
    'score' => 0,
  ),
  2173 => 
  array (
    '_id' => '土地抵押贷款',
    'word' => '土地抵押贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2174 => 
  array (
    '_id' => '土地公有制',
    'word' => '土地公有制',
    'hits' => 0,
    'score' => 0,
  ),
  2175 => 
  array (
    '_id' => '土地管理法',
    'word' => '土地管理法',
    'hits' => 0,
    'score' => 0,
  ),
  2176 => 
  array (
    '_id' => '土地合同',
    'word' => '土地合同',
    'hits' => 0,
    'score' => 0,
  ),
  2177 => 
  array (
    '_id' => '土地划拨',
    'word' => '土地划拨',
    'hits' => 0,
    'score' => 0,
  ),
  2178 => 
  array (
    '_id' => '土地开发费',
    'word' => '土地开发费',
    'hits' => 0,
    'score' => 0,
  ),
  2179 => 
  array (
    '_id' => '土地开发流程',
    'word' => '土地开发流程',
    'hits' => 0,
    'score' => 0,
  ),
  2180 => 
  array (
    '_id' => '土地利用年度计划',
    'word' => '土地利用年度计划',
    'hits' => 0,
    'score' => 0,
  ),
  2181 => 
  array (
    '_id' => '土地利用总体规划',
    'word' => '土地利用总体规划',
    'hits' => 0,
    'score' => 0,
  ),
  2182 => 
  array (
    '_id' => '土地面积',
    'word' => '土地面积',
    'hits' => 0,
    'score' => 0,
  ),
  2183 => 
  array (
    '_id' => '土地契税',
    'word' => '土地契税',
    'hits' => 0,
    'score' => 0,
  ),
  2184 => 
  array (
    '_id' => '土地使用权',
    'word' => '土地使用权',
    'hits' => 0,
    'score' => 0,
  ),
  2185 => 
  array (
    '_id' => '土地使用权出让',
    'word' => '土地使用权出让',
    'hits' => 0,
    'score' => 0,
  ),
  2186 => 
  array (
    '_id' => '土地使用权出让合同',
    'word' => '土地使用权出让合同',
    'hits' => 0,
    'score' => 0,
  ),
  2187 => 
  array (
    '_id' => '土地使用权出让金',
    'word' => '土地使用权出让金',
    'hits' => 0,
    'score' => 0,
  ),
  2188 => 
  array (
    '_id' => '土地使用权出让相关条例',
    'word' => '土地使用权出让相关条例',
    'hits' => 0,
    'score' => 0,
  ),
  2189 => 
  array (
    '_id' => '土地使用权初始登记',
    'word' => '土地使用权初始登记',
    'hits' => 0,
    'score' => 0,
  ),
  2190 => 
  array (
    '_id' => '土地使用权抵押',
    'word' => '土地使用权抵押',
    'hits' => 0,
    'score' => 0,
  ),
  2191 => 
  array (
    '_id' => '土地使用权划拨',
    'word' => '土地使用权划拨',
    'hits' => 0,
    'score' => 0,
  ),
  2192 => 
  array (
    '_id' => '土地使用权收回',
    'word' => '土地使用权收回',
    'hits' => 0,
    'score' => 0,
  ),
  2193 => 
  array (
    '_id' => '土地使用权终止',
    'word' => '土地使用权终止',
    'hits' => 0,
    'score' => 0,
  ),
  2194 => 
  array (
    '_id' => '土地使用权总登记',
    'word' => '土地使用权总登记',
    'hits' => 0,
    'score' => 0,
  ),
  2195 => 
  array (
    '_id' => '土地使用税',
    'word' => '土地使用税',
    'hits' => 0,
    'score' => 0,
  ),
  2196 => 
  array (
    '_id' => '土地使用证',
    'word' => '土地使用证',
    'hits' => 0,
    'score' => 0,
  ),
  2197 => 
  array (
    '_id' => '土地收益金',
    'word' => '土地收益金',
    'hits' => 0,
    'score' => 0,
  ),
  2198 => 
  array (
    '_id' => '土地收益金(土地增值费)',
    'word' => '土地收益金(土地增值费)',
    'hits' => 0,
    'score' => 0,
  ),
  2199 => 
  array (
    '_id' => '土地增值税',
    'word' => '土地增值税',
    'hits' => 0,
    'score' => 0,
  ),
  2200 => 
  array (
    '_id' => '土地增值税清算',
    'word' => '土地增值税清算',
    'hits' => 0,
    'score' => 0,
  ),
  2201 => 
  array (
    '_id' => '土地证',
    'word' => '土地证',
    'hits' => 0,
    'score' => 0,
  ),
  2202 => 
  array (
    '_id' => '土地证丢失更名',
    'word' => '土地证丢失更名',
    'hits' => 0,
    'score' => 0,
  ),
  2203 => 
  array (
    '_id' => '土地证过户',
    'word' => '土地证过户',
    'hits' => 0,
    'score' => 0,
  ),
  2204 => 
  array (
    '_id' => '土地证号查询',
    'word' => '土地证号查询',
    'hits' => 0,
    'score' => 0,
  ),
  2205 => 
  array (
    '_id' => '土地证有什么用',
    'word' => '土地证有什么用',
    'hits' => 0,
    'score' => 0,
  ),
  2206 => 
  array (
    '_id' => '土地租赁合同',
    'word' => '土地租赁合同',
    'hits' => 0,
    'score' => 0,
  ),
  2207 => 
  array (
    '_id' => '吐鲁番住房公积金提取',
    'word' => '吐鲁番住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2208 => 
  array (
    '_id' => '推拉门轨道',
    'word' => '推拉门轨道',
    'hits' => 0,
    'score' => 0,
  ),
  2209 => 
  array (
    '_id' => '托梁换柱',
    'word' => '托梁换柱',
    'hits' => 0,
    'score' => 0,
  ),
  2210 => 
  array (
    '_id' => '托斯卡纳风格',
    'word' => '托斯卡纳风格',
    'hits' => 0,
    'score' => 0,
  ),
  2211 => 
  array (
    '_id' => '厦门公积金贷款',
    'word' => '厦门公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2212 => 
  array (
    '_id' => '厦门住房公积金查询',
    'word' => '厦门住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2213 => 
  array (
    '_id' => '长春公积金贷款',
    'word' => '长春公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2214 => 
  array (
    '_id' => '长春住房公积金查询',
    'word' => '长春住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2215 => 
  array (
    '_id' => '长春住房公积金提取',
    'word' => '长春住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2216 => 
  array (
    '_id' => '长治住房公积金查询',
    'word' => '长治住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2217 => 
  array (
    '_id' => '外国房产税',
    'word' => '外国房产税',
    'hits' => 0,
    'score' => 0,
  ),
  2218 => 
  array (
    '_id' => '外飘窗',
    'word' => '外飘窗',
    'hits' => 0,
    'score' => 0,
  ),
  2219 => 
  array (
    '_id' => '外墙漆',
    'word' => '外墙漆',
    'hits' => 0,
    'score' => 0,
  ),
  2220 => 
  array (
    '_id' => '外墙真石漆',
    'word' => '外墙真石漆',
    'hits' => 0,
    'score' => 0,
  ),
  2221 => 
  array (
    '_id' => '外墙砖',
    'word' => '外墙砖',
    'hits' => 0,
    'score' => 0,
  ),
  2222 => 
  array (
    '_id' => '外销房',
    'word' => '外销房',
    'hits' => 0,
    'score' => 0,
  ),
  2223 => 
  array (
    '_id' => '完税证明',
    'word' => '完税证明',
    'hits' => 0,
    'score' => 0,
  ),
  2224 => 
  array (
    '_id' => '万宝冰柜',
    'word' => '万宝冰柜',
    'hits' => 0,
    'score' => 0,
  ),
  2225 => 
  array (
    '_id' => '万宝冰箱',
    'word' => '万宝冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  2226 => 
  array (
    '_id' => '万宁公积金贷款',
    'word' => '万宁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2227 => 
  array (
    '_id' => '万宁住房公积金查询',
    'word' => '万宁住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2228 => 
  array (
    '_id' => '王牌木门',
    'word' => '王牌木门',
    'hits' => 0,
    'score' => 0,
  ),
  2229 => 
  array (
    '_id' => '网签',
    'word' => '网签',
    'hits' => 0,
    'score' => 0,
  ),
  2230 => 
  array (
    '_id' => '危房改建申请',
    'word' => '危房改建申请',
    'hits' => 0,
    'score' => 0,
  ),
  2231 => 
  array (
    '_id' => '危房率',
    'word' => '危房率',
    'hits' => 0,
    'score' => 0,
  ),
  2232 => 
  array (
    '_id' => '威尔登水槽',
    'word' => '威尔登水槽',
    'hits' => 0,
    'score' => 0,
  ),
  2233 => 
  array (
    '_id' => '威尔顿地毯',
    'word' => '威尔顿地毯',
    'hits' => 0,
    'score' => 0,
  ),
  2234 => 
  array (
    '_id' => '威海住房公积金查询',
    'word' => '威海住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2235 => 
  array (
    '_id' => '威海住房公积金提取',
    'word' => '威海住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2236 => 
  array (
    '_id' => '威能地暖',
    'word' => '威能地暖',
    'hits' => 0,
    'score' => 0,
  ),
  2237 => 
  array (
    '_id' => '威士合页',
    'word' => '威士合页',
    'hits' => 0,
    'score' => 0,
  ),
  2238 => 
  array (
    '_id' => '微利房',
    'word' => '微利房',
    'hits' => 0,
    'score' => 0,
  ),
  2239 => 
  array (
    '_id' => '围墙大门',
    'word' => '围墙大门',
    'hits' => 0,
    'score' => 0,
  ),
  2240 => 
  array (
    '_id' => '违约金',
    'word' => '违约金',
    'hits' => 0,
    'score' => 0,
  ),
  2241 => 
  array (
    '_id' => '维科家纺',
    'word' => '维科家纺',
    'hits' => 0,
    'score' => 0,
  ),
  2242 => 
  array (
    '_id' => '维修工具',
    'word' => '维修工具',
    'hits' => 0,
    'score' => 0,
  ),
  2243 => 
  array (
    '_id' => '维修基金',
    'word' => '维修基金',
    'hits' => 0,
    'score' => 0,
  ),
  2244 => 
  array (
    '_id' => '维意衣柜',
    'word' => '维意衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  2245 => 
  array (
    '_id' => '潍坊公积金贷款',
    'word' => '潍坊公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2246 => 
  array (
    '_id' => '伟星水管',
    'word' => '伟星水管',
    'hits' => 0,
    'score' => 0,
  ),
  2247 => 
  array (
    '_id' => '尾房',
    'word' => '尾房',
    'hits' => 0,
    'score' => 0,
  ),
  2248 => 
  array (
    '_id' => '卫生级阀门',
    'word' => '卫生级阀门',
    'hits' => 0,
    'score' => 0,
  ),
  2249 => 
  array (
    '_id' => '卫生间瓷砖选择',
    'word' => '卫生间瓷砖选择',
    'hits' => 0,
    'score' => 0,
  ),
  2250 => 
  array (
    '_id' => '卫生间地砖',
    'word' => '卫生间地砖',
    'hits' => 0,
    'score' => 0,
  ),
  2251 => 
  array (
    '_id' => '卫生间吊顶',
    'word' => '卫生间吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  2252 => 
  array (
    '_id' => '卫生间防水做法',
    'word' => '卫生间防水做法',
    'hits' => 0,
    'score' => 0,
  ),
  2253 => 
  array (
    '_id' => '卫生间漏水',
    'word' => '卫生间漏水',
    'hits' => 0,
    'score' => 0,
  ),
  2254 => 
  array (
    '_id' => '卫生间装修效果图',
    'word' => '卫生间装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  2255 => 
  array (
    '_id' => '卫生洁具安装方案',
    'word' => '卫生洁具安装方案',
    'hits' => 0,
    'score' => 0,
  ),
  2256 => 
  array (
    '_id' => '卫浴产品',
    'word' => '卫浴产品',
    'hits' => 0,
    'score' => 0,
  ),
  2257 => 
  array (
    '_id' => '卫浴洁具',
    'word' => '卫浴洁具',
    'hits' => 0,
    'score' => 0,
  ),
  2258 => 
  array (
    '_id' => '卫浴三大件',
    'word' => '卫浴三大件',
    'hits' => 0,
    'score' => 0,
  ),
  2259 => 
  array (
    '_id' => '卫浴五金',
    'word' => '卫浴五金',
    'hits' => 0,
    'score' => 0,
  ),
  2260 => 
  array (
    '_id' => '卫浴装修效果图',
    'word' => '卫浴装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  2261 => 
  array (
    '_id' => '未婚证明',
    'word' => '未婚证明',
    'hits' => 0,
    'score' => 0,
  ),
  2262 => 
  array (
    '_id' => '渭南公积金贷款',
    'word' => '渭南公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2263 => 
  array (
    '_id' => '渭南住房公积金提取',
    'word' => '渭南住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2264 => 
  array (
    '_id' => '温岭住房公积金查询',
    'word' => '温岭住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2265 => 
  array (
    '_id' => '温岭住房公积金提取',
    'word' => '温岭住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2266 => 
  array (
    '_id' => '温州住房公积金提取',
    'word' => '温州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2267 => 
  array (
    '_id' => '文昌公积金贷款',
    'word' => '文昌公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2268 => 
  array (
    '_id' => '文昌住房公积金提取',
    'word' => '文昌住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2269 => 
  array (
    '_id' => '文化石背景墙',
    'word' => '文化石背景墙',
    'hits' => 0,
    'score' => 0,
  ),
  2270 => 
  array (
    '_id' => '文山住房公积金提取',
    'word' => '文山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2271 => 
  array (
    '_id' => '卧室窗帘',
    'word' => '卧室窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  2272 => 
  array (
    '_id' => '卧室灯具',
    'word' => '卧室灯具',
    'hits' => 0,
    'score' => 0,
  ),
  2273 => 
  array (
    '_id' => '卧室风水布局与禁忌',
    'word' => '卧室风水布局与禁忌',
    'hits' => 0,
    'score' => 0,
  ),
  2274 => 
  array (
    '_id' => '卧室风水禁忌',
    'word' => '卧室风水禁忌',
    'hits' => 0,
    'score' => 0,
  ),
  2275 => 
  array (
    '_id' => '卧室家具摆放风水',
    'word' => '卧室家具摆放风水',
    'hits' => 0,
    'score' => 0,
  ),
  2276 => 
  array (
    '_id' => '卧室衣柜',
    'word' => '卧室衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  2277 => 
  array (
    '_id' => '卧室装修效果图',
    'word' => '卧室装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  2278 => 
  array (
    '_id' => '乌海公积金贷款',
    'word' => '乌海公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2279 => 
  array (
    '_id' => '乌海住房公积金查询',
    'word' => '乌海住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2280 => 
  array (
    '_id' => '乌海住房公积金提取',
    'word' => '乌海住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2281 => 
  array (
    '_id' => '乌兰察布公积金贷款',
    'word' => '乌兰察布公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2282 => 
  array (
    '_id' => '乌兰察布住房公积金查询',
    'word' => '乌兰察布住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2283 => 
  array (
    '_id' => '乌兰察布住房公积金提取',
    'word' => '乌兰察布住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2284 => 
  array (
    '_id' => '乌鲁木齐住房公积金查询',
    'word' => '乌鲁木齐住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2285 => 
  array (
    '_id' => '无担保贷款',
    'word' => '无担保贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2286 => 
  array (
    '_id' => '无抵押贷款',
    'word' => '无抵押贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2287 => 
  array (
    '_id' => '无抵押个人贷款',
    'word' => '无抵押个人贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2288 => 
  array (
    '_id' => '无房证明怎么开',
    'word' => '无房证明怎么开',
    'hits' => 0,
    'score' => 0,
  ),
  2289 => 
  array (
    '_id' => '无纺布壁纸',
    'word' => '无纺布壁纸',
    'hits' => 0,
    'score' => 0,
  ),
  2290 => 
  array (
    '_id' => '无机富锌底漆',
    'word' => '无机富锌底漆',
    'hits' => 0,
    'score' => 0,
  ),
  2291 => 
  array (
    '_id' => '无铅水龙头',
    'word' => '无铅水龙头',
    'hits' => 0,
    'score' => 0,
  ),
  2292 => 
  array (
    '_id' => '无锡公积金贷款',
    'word' => '无锡公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2293 => 
  array (
    '_id' => '无锡住房公积金提取',
    'word' => '无锡住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2294 => 
  array (
    '_id' => '无线门铃',
    'word' => '无线门铃',
    'hits' => 0,
    'score' => 0,
  ),
  2295 => 
  array (
    '_id' => '无烟烧烤炉',
    'word' => '无烟烧烤炉',
    'hits' => 0,
    'score' => 0,
  ),
  2296 => 
  array (
    '_id' => '吴忠公积金贷款',
    'word' => '吴忠公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2297 => 
  array (
    '_id' => '吴忠住房公积金查询',
    'word' => '吴忠住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2298 => 
  array (
    '_id' => '吴忠住房公积金提取',
    'word' => '吴忠住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2299 => 
  array (
    '_id' => '吾申橱柜',
    'word' => '吾申橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  2300 => 
  array (
    '_id' => '芜湖住房公积金查询',
    'word' => '芜湖住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2301 => 
  array (
    '_id' => '梧州公积金贷款',
    'word' => '梧州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2302 => 
  array (
    '_id' => '梧州住房公积金提取',
    'word' => '梧州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2303 => 
  array (
    '_id' => '五斗柜',
    'word' => '五斗柜',
    'hits' => 0,
    'score' => 0,
  ),
  2304 => 
  array (
    '_id' => '五金',
    'word' => '五金',
    'hits' => 0,
    'score' => 0,
  ),
  2305 => 
  array (
    '_id' => '五孔插座',
    'word' => '五孔插座',
    'hits' => 0,
    'score' => 0,
  ),
  2306 => 
  array (
    '_id' => '五证',
    'word' => '五证',
    'hits' => 0,
    'score' => 0,
  ),
  2307 => 
  array (
    '_id' => '五证二书',
    'word' => '五证二书',
    'hits' => 0,
    'score' => 0,
  ),
  2308 => 
  array (
    '_id' => '五指山住房公积金查询',
    'word' => '五指山住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2309 => 
  array (
    '_id' => '武汉高楼',
    'word' => '武汉高楼',
    'hits' => 0,
    'score' => 0,
  ),
  2310 => 
  array (
    '_id' => '武汉公租房申请条件',
    'word' => '武汉公租房申请条件',
    'hits' => 0,
    'score' => 0,
  ),
  2311 => 
  array (
    '_id' => '武汉购房资格',
    'word' => '武汉购房资格',
    'hits' => 0,
    'score' => 0,
  ),
  2312 => 
  array (
    '_id' => '武汉住房公积金提取',
    'word' => '武汉住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2313 => 
  array (
    '_id' => '武威住房公积金查询',
    'word' => '武威住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2314 => 
  array (
    '_id' => '武威住房公积金提取',
    'word' => '武威住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2315 => 
  array (
    '_id' => '物业',
    'word' => '物业',
    'hits' => 0,
    'score' => 0,
  ),
  2316 => 
  array (
    '_id' => '物业费',
    'word' => '物业费',
    'hits' => 0,
    'score' => 0,
  ),
  2317 => 
  array (
    '_id' => '物业费标准',
    'word' => '物业费标准',
    'hits' => 0,
    'score' => 0,
  ),
  2318 => 
  array (
    '_id' => '物业费收取标准管理',
    'word' => '物业费收取标准管理',
    'hits' => 0,
    'score' => 0,
  ),
  2319 => 
  array (
    '_id' => '物业费滞纳金',
    'word' => '物业费滞纳金',
    'hits' => 0,
    'score' => 0,
  ),
  2320 => 
  array (
    '_id' => '物业服务',
    'word' => '物业服务',
    'hits' => 0,
    'score' => 0,
  ),
  2321 => 
  array (
    '_id' => '物业公司',
    'word' => '物业公司',
    'hits' => 0,
    'score' => 0,
  ),
  2322 => 
  array (
    '_id' => '物业管理',
    'word' => '物业管理',
    'hits' => 0,
    'score' => 0,
  ),
  2323 => 
  array (
    '_id' => '物业管理案例',
    'word' => '物业管理案例',
    'hits' => 0,
    'score' => 0,
  ),
  2324 => 
  array (
    '_id' => '物业管理单位',
    'word' => '物业管理单位',
    'hits' => 0,
    'score' => 0,
  ),
  2325 => 
  array (
    '_id' => '物业管理服务',
    'word' => '物业管理服务',
    'hits' => 0,
    'score' => 0,
  ),
  2326 => 
  array (
    '_id' => '物业管理机制',
    'word' => '物业管理机制',
    'hits' => 0,
    'score' => 0,
  ),
  2327 => 
  array (
    '_id' => '物业管理接管验收',
    'word' => '物业管理接管验收',
    'hits' => 0,
    'score' => 0,
  ),
  2328 => 
  array (
    '_id' => '物业管理收费',
    'word' => '物业管理收费',
    'hits' => 0,
    'score' => 0,
  ),
  2329 => 
  array (
    '_id' => '物业管理收入',
    'word' => '物业管理收入',
    'hits' => 0,
    'score' => 0,
  ),
  2330 => 
  array (
    '_id' => '物业管理体制',
    'word' => '物业管理体制',
    'hits' => 0,
    'score' => 0,
  ),
  2331 => 
  array (
    '_id' => '物业管理委员会',
    'word' => '物业管理委员会',
    'hits' => 0,
    'score' => 0,
  ),
  2332 => 
  array (
    '_id' => '物业纠纷',
    'word' => '物业纠纷',
    'hits' => 0,
    'score' => 0,
  ),
  2333 => 
  array (
    '_id' => '物业收费',
    'word' => '物业收费',
    'hits' => 0,
    'score' => 0,
  ),
  2334 => 
  array (
    '_id' => '物业收费标准',
    'word' => '物业收费标准',
    'hits' => 0,
    'score' => 0,
  ),
  2335 => 
  array (
    '_id' => '物业税',
    'word' => '物业税',
    'hits' => 0,
    'score' => 0,
  ),
  2336 => 
  array (
    '_id' => '西安住房公积金查询',
    'word' => '西安住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2337 => 
  array (
    '_id' => '西门子洗衣机',
    'word' => '西门子洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  2338 => 
  array (
    '_id' => '西宁住房公积金提取',
    'word' => '西宁住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2339 => 
  array (
    '_id' => '西双版纳公积金贷款',
    'word' => '西双版纳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2340 => 
  array (
    '_id' => '西双版纳住房公积金查询',
    'word' => '西双版纳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2341 => 
  array (
    '_id' => '西双版纳住房公积金提取',
    'word' => '西双版纳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2342 => 
  array (
    '_id' => '席玛卫浴',
    'word' => '席玛卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  2343 => 
  array (
    '_id' => '洗盘',
    'word' => '洗盘',
    'hits' => 0,
    'score' => 0,
  ),
  2344 => 
  array (
    '_id' => '洗手盆',
    'word' => '洗手盆',
    'hits' => 0,
    'score' => 0,
  ),
  2345 => 
  array (
    '_id' => '洗漱台',
    'word' => '洗漱台',
    'hits' => 0,
    'score' => 0,
  ),
  2346 => 
  array (
    '_id' => '玺泽卫浴',
    'word' => '玺泽卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  2347 => 
  array (
    '_id' => '玺泽五金',
    'word' => '玺泽五金',
    'hits' => 0,
    'score' => 0,
  ),
  2348 => 
  array (
    '_id' => '喜临门床垫',
    'word' => '喜临门床垫',
    'hits' => 0,
    'score' => 0,
  ),
  2349 => 
  array (
    '_id' => '喜临门家具',
    'word' => '喜临门家具',
    'hits' => 0,
    'score' => 0,
  ),
  2350 => 
  array (
    '_id' => '喜梦宝实木家具',
    'word' => '喜梦宝实木家具',
    'hits' => 0,
    'score' => 0,
  ),
  2351 => 
  array (
    '_id' => '细雨阳光浴霸',
    'word' => '细雨阳光浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  2352 => 
  array (
    '_id' => '夏普冰箱',
    'word' => '夏普冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  2353 => 
  array (
    '_id' => '夏普空调',
    'word' => '夏普空调',
    'hits' => 0,
    'score' => 0,
  ),
  2354 => 
  array (
    '_id' => '仙桃公积金贷款',
    'word' => '仙桃公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2355 => 
  array (
    '_id' => '仙桃住房公积金提取',
    'word' => '仙桃住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2356 => 
  array (
    '_id' => '先科冰箱',
    'word' => '先科冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  2357 => 
  array (
    '_id' => '闲置土地',
    'word' => '闲置土地',
    'hits' => 0,
    'score' => 0,
  ),
  2358 => 
  array (
    '_id' => '咸宁公积金贷款',
    'word' => '咸宁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2359 => 
  array (
    '_id' => '咸宁住房公积金查询',
    'word' => '咸宁住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2360 => 
  array (
    '_id' => '咸阳公积金贷款',
    'word' => '咸阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2361 => 
  array (
    '_id' => '咸阳住房公积金查询',
    'word' => '咸阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2362 => 
  array (
    '_id' => '咸阳住房公积金提取',
    'word' => '咸阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2363 => 
  array (
    '_id' => '现代冰箱',
    'word' => '现代冰箱',
    'hits' => 0,
    'score' => 0,
  ),
  2364 => 
  array (
    '_id' => '现代简约装修效果图',
    'word' => '现代简约装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  2365 => 
  array (
    '_id' => '现代美式风格',
    'word' => '现代美式风格',
    'hits' => 0,
    'score' => 0,
  ),
  2366 => 
  array (
    '_id' => '现代中式风格',
    'word' => '现代中式风格',
    'hits' => 0,
    'score' => 0,
  ),
  2367 => 
  array (
    '_id' => '现代装修风格',
    'word' => '现代装修风格',
    'hits' => 0,
    'score' => 0,
  ),
  2368 => 
  array (
    '_id' => '现房',
    'word' => '现房',
    'hits' => 0,
    'score' => 0,
  ),
  2369 => 
  array (
    '_id' => '现房抵押贷款',
    'word' => '现房抵押贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2370 => 
  array (
    '_id' => '现在贷款利率是多少',
    'word' => '现在贷款利率是多少',
    'hits' => 0,
    'score' => 0,
  ),
  2371 => 
  array (
    '_id' => '现在买房合适吗',
    'word' => '现在买房合适吗',
    'hits' => 0,
    'score' => 0,
  ),
  2372 => 
  array (
    '_id' => '限仓制度',
    'word' => '限仓制度',
    'hits' => 0,
    'score' => 0,
  ),
  2373 => 
  array (
    '_id' => '限购',
    'word' => '限购',
    'hits' => 0,
    'score' => 0,
  ),
  2374 => 
  array (
    '_id' => '限购令',
    'word' => '限购令',
    'hits' => 0,
    'score' => 0,
  ),
  2375 => 
  array (
    '_id' => '限购令取消',
    'word' => '限购令取消',
    'hits' => 0,
    'score' => 0,
  ),
  2376 => 
  array (
    '_id' => '限购限贷',
    'word' => '限购限贷',
    'hits' => 0,
    'score' => 0,
  ),
  2377 => 
  array (
    '_id' => '限价房买卖',
    'word' => '限价房买卖',
    'hits' => 0,
    'score' => 0,
  ),
  2378 => 
  array (
    '_id' => '限价房申请流程',
    'word' => '限价房申请流程',
    'hits' => 0,
    'score' => 0,
  ),
  2379 => 
  array (
    '_id' => '限价房申请条件',
    'word' => '限价房申请条件',
    'hits' => 0,
    'score' => 0,
  ),
  2380 => 
  array (
    '_id' => '香柏木家具',
    'word' => '香柏木家具',
    'hits' => 0,
    'score' => 0,
  ),
  2381 => 
  array (
    '_id' => '香港豪宅',
    'word' => '香港豪宅',
    'hits' => 0,
    'score' => 0,
  ),
  2382 => 
  array (
    '_id' => '湘潭住房公积金查询',
    'word' => '湘潭住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2383 => 
  array (
    '_id' => '湘西公积金贷款',
    'word' => '湘西公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2384 => 
  array (
    '_id' => '湘西住房公积金查询',
    'word' => '湘西住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2385 => 
  array (
    '_id' => '襄阳住房公积金查询',
    'word' => '襄阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2386 => 
  array (
    '_id' => '襄阳住房公积金提取',
    'word' => '襄阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2387 => 
  array (
    '_id' => '橡胶地板',
    'word' => '橡胶地板',
    'hits' => 0,
    'score' => 0,
  ),
  2388 => 
  array (
    '_id' => '橡胶地砖',
    'word' => '橡胶地砖',
    'hits' => 0,
    'score' => 0,
  ),
  2389 => 
  array (
    '_id' => '橡胶木家具',
    'word' => '橡胶木家具',
    'hits' => 0,
    'score' => 0,
  ),
  2390 => 
  array (
    '_id' => '橡木地板',
    'word' => '橡木地板',
    'hits' => 0,
    'score' => 0,
  ),
  2391 => 
  array (
    '_id' => '消防电梯',
    'word' => '消防电梯',
    'hits' => 0,
    'score' => 0,
  ),
  2392 => 
  array (
    '_id' => '销售面积',
    'word' => '销售面积',
    'hits' => 0,
    'score' => 0,
  ),
  2393 => 
  array (
    '_id' => '小产权',
    'word' => '小产权',
    'hits' => 0,
    'score' => 0,
  ),
  2394 => 
  array (
    '_id' => '小产权房',
    'word' => '小产权房',
    'hits' => 0,
    'score' => 0,
  ),
  2395 => 
  array (
    '_id' => '小产权房买卖',
    'word' => '小产权房买卖',
    'hits' => 0,
    'score' => 0,
  ),
  2396 => 
  array (
    '_id' => '小产权房清理整治方案',
    'word' => '小产权房清理整治方案',
    'hits' => 0,
    'score' => 0,
  ),
  2397 => 
  array (
    '_id' => '小产权房屋买卖合同',
    'word' => '小产权房屋买卖合同',
    'hits' => 0,
    'score' => 0,
  ),
  2398 => 
  array (
    '_id' => '小产权房最新消息政策',
    'word' => '小产权房最新消息政策',
    'hits' => 0,
    'score' => 0,
  ),
  2399 => 
  array (
    '_id' => '小产权房最新政策消息',
    'word' => '小产权房最新政策消息',
    'hits' => 0,
    'score' => 0,
  ),
  2400 => 
  array (
    '_id' => '小厨房设计',
    'word' => '小厨房设计',
    'hits' => 0,
    'score' => 0,
  ),
  2401 => 
  array (
    '_id' => '小额贷款',
    'word' => '小额贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2402 => 
  array (
    '_id' => '小房间装修技巧',
    'word' => '小房间装修技巧',
    'hits' => 0,
    'score' => 0,
  ),
  2403 => 
  array (
    '_id' => '小高层',
    'word' => '小高层',
    'hits' => 0,
    'score' => 0,
  ),
  2404 => 
  array (
    '_id' => '小高层房屋',
    'word' => '小高层房屋',
    'hits' => 0,
    'score' => 0,
  ),
  2405 => 
  array (
    '_id' => '小户型厨房装修',
    'word' => '小户型厨房装修',
    'hits' => 0,
    'score' => 0,
  ),
  2406 => 
  array (
    '_id' => '小户型电视墙',
    'word' => '小户型电视墙',
    'hits' => 0,
    'score' => 0,
  ),
  2407 => 
  array (
    '_id' => '小户型家装设计',
    'word' => '小户型家装设计',
    'hits' => 0,
    'score' => 0,
  ),
  2408 => 
  array (
    '_id' => '小户型客厅装修',
    'word' => '小户型客厅装修',
    'hits' => 0,
    'score' => 0,
  ),
  2409 => 
  array (
    '_id' => '小户型沙发',
    'word' => '小户型沙发',
    'hits' => 0,
    'score' => 0,
  ),
  2410 => 
  array (
    '_id' => '小户型装修攻略',
    'word' => '小户型装修攻略',
    'hits' => 0,
    'score' => 0,
  ),
  2411 => 
  array (
    '_id' => '小户型装修手册',
    'word' => '小户型装修手册',
    'hits' => 0,
    'score' => 0,
  ),
  2412 => 
  array (
    '_id' => '小户型装修效果图',
    'word' => '小户型装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  2413 => 
  array (
    '_id' => '小区布局形式',
    'word' => '小区布局形式',
    'hits' => 0,
    'score' => 0,
  ),
  2414 => 
  array (
    '_id' => '小区绿化',
    'word' => '小区绿化',
    'hits' => 0,
    'score' => 0,
  ),
  2415 => 
  array (
    '_id' => '小区密度',
    'word' => '小区密度',
    'hits' => 0,
    'score' => 0,
  ),
  2416 => 
  array (
    '_id' => '小区配套',
    'word' => '小区配套',
    'hits' => 0,
    'score' => 0,
  ),
  2417 => 
  array (
    '_id' => '小区物业费',
    'word' => '小区物业费',
    'hits' => 0,
    'score' => 0,
  ),
  2418 => 
  array (
    '_id' => '小区物业管理服务范围',
    'word' => '小区物业管理服务范围',
    'hits' => 0,
    'score' => 0,
  ),
  2419 => 
  array (
    '_id' => '小书房',
    'word' => '小书房',
    'hits' => 0,
    'score' => 0,
  ),
  2420 => 
  array (
    '_id' => '小天鹅洗衣机',
    'word' => '小天鹅洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  2421 => 
  array (
    '_id' => '孝感住房公积金查询',
    'word' => '孝感住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2422 => 
  array (
    '_id' => '孝感住房公积金提取',
    'word' => '孝感住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2423 => 
  array (
    '_id' => '鞋柜玄关',
    'word' => '鞋柜玄关',
    'hits' => 0,
    'score' => 0,
  ),
  2424 => 
  array (
    '_id' => '鞋架',
    'word' => '鞋架',
    'hits' => 0,
    'score' => 0,
  ),
  2425 => 
  array (
    '_id' => '写字楼',
    'word' => '写字楼',
    'hits' => 0,
    'score' => 0,
  ),
  2426 => 
  array (
    '_id' => '忻州住房公积金查询',
    'word' => '忻州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2427 => 
  array (
    '_id' => '忻州住房公积金提取',
    'word' => '忻州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2428 => 
  array (
    '_id' => '新拆迁法',
    'word' => '新拆迁法',
    'hits' => 0,
    'score' => 0,
  ),
  2429 => 
  array (
    '_id' => '新多防盗门',
    'word' => '新多防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  2430 => 
  array (
    '_id' => '新房交房注意事项',
    'word' => '新房交房注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  2431 => 
  array (
    '_id' => '新房契税',
    'word' => '新房契税',
    'hits' => 0,
    'score' => 0,
  ),
  2432 => 
  array (
    '_id' => '新房如何办理房产证',
    'word' => '新房如何办理房产证',
    'hits' => 0,
    'score' => 0,
  ),
  2433 => 
  array (
    '_id' => '新房入住注意事项',
    'word' => '新房入住注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  2434 => 
  array (
    '_id' => '新房装修除味',
    'word' => '新房装修除味',
    'hits' => 0,
    'score' => 0,
  ),
  2435 => 
  array (
    '_id' => '新房装修多久能入住',
    'word' => '新房装修多久能入住',
    'hits' => 0,
    'score' => 0,
  ),
  2436 => 
  array (
    '_id' => '新房装修流程',
    'word' => '新房装修流程',
    'hits' => 0,
    'score' => 0,
  ),
  2437 => 
  array (
    '_id' => '新房装修入住',
    'word' => '新房装修入住',
    'hits' => 0,
    'score' => 0,
  ),
  2438 => 
  array (
    '_id' => '新房装修注意事项',
    'word' => '新房装修注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  2439 => 
  array (
    '_id' => '新房子装修步骤',
    'word' => '新房子装修步骤',
    'hits' => 0,
    'score' => 0,
  ),
  2440 => 
  array (
    '_id' => '新飞热水器',
    'word' => '新飞热水器',
    'hits' => 0,
    'score' => 0,
  ),
  2441 => 
  array (
    '_id' => '新飞洗衣机',
    'word' => '新飞洗衣机',
    'hits' => 0,
    'score' => 0,
  ),
  2442 => 
  array (
    '_id' => '新飞浴霸',
    'word' => '新飞浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  2443 => 
  array (
    '_id' => '新供应量',
    'word' => '新供应量',
    'hits' => 0,
    'score' => 0,
  ),
  2444 => 
  array (
    '_id' => '新古典主义风格',
    'word' => '新古典主义风格',
    'hits' => 0,
    'score' => 0,
  ),
  2445 => 
  array (
    '_id' => '新国八条',
    'word' => '新国八条',
    'hits' => 0,
    'score' => 0,
  ),
  2446 => 
  array (
    '_id' => '新国十条',
    'word' => '新国十条',
    'hits' => 0,
    'score' => 0,
  ),
  2447 => 
  array (
    '_id' => '新国五条',
    'word' => '新国五条',
    'hits' => 0,
    'score' => 0,
  ),
  2448 => 
  array (
    '_id' => '新婚姻法',
    'word' => '新婚姻法',
    'hits' => 0,
    'score' => 0,
  ),
  2449 => 
  array (
    '_id' => '新婚姻法财产分割',
    'word' => '新婚姻法财产分割',
    'hits' => 0,
    'score' => 0,
  ),
  2450 => 
  array (
    '_id' => '新婚姻法房产',
    'word' => '新婚姻法房产',
    'hits' => 0,
    'score' => 0,
  ),
  2451 => 
  array (
    '_id' => '新科壁纸',
    'word' => '新科壁纸',
    'hits' => 0,
    'score' => 0,
  ),
  2452 => 
  array (
    '_id' => '新科空调',
    'word' => '新科空调',
    'hits' => 0,
    'score' => 0,
  ),
  2453 => 
  array (
    '_id' => '新润成瓷砖',
    'word' => '新润成瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  2454 => 
  array (
    '_id' => '新乡住房公积金查询',
    'word' => '新乡住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2455 => 
  array (
    '_id' => '新余住房公积金查询',
    'word' => '新余住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2456 => 
  array (
    '_id' => '新中式',
    'word' => '新中式',
    'hits' => 0,
    'score' => 0,
  ),
  2457 => 
  array (
    '_id' => '新中式风格',
    'word' => '新中式风格',
    'hits' => 0,
    'score' => 0,
  ),
  2458 => 
  array (
    '_id' => '信阳公积金贷款',
    'word' => '信阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2459 => 
  array (
    '_id' => '信阳住房公积金查询',
    'word' => '信阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2460 => 
  array (
    '_id' => '信阳住房公积金提取',
    'word' => '信阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2461 => 
  array (
    '_id' => '信用卡还房贷',
    'word' => '信用卡还房贷',
    'hits' => 0,
    'score' => 0,
  ),
  2462 => 
  array (
    '_id' => '兴安盟公积金贷款',
    'word' => '兴安盟公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2463 => 
  array (
    '_id' => '兴安盟住房公积金提取',
    'word' => '兴安盟住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2464 => 
  array (
    '_id' => '星星点灯灯具',
    'word' => '星星点灯灯具',
    'hits' => 0,
    'score' => 0,
  ),
  2465 => 
  array (
    '_id' => '星星冷柜',
    'word' => '星星冷柜',
    'hits' => 0,
    'score' => 0,
  ),
  2466 => 
  array (
    '_id' => '星月神防盗门',
    'word' => '星月神防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  2467 => 
  array (
    '_id' => '邢台住房公积金查询',
    'word' => '邢台住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2468 => 
  array (
    '_id' => '邢台住房公积金提取',
    'word' => '邢台住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2469 => 
  array (
    '_id' => '徐州公积金贷款',
    'word' => '徐州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2470 => 
  array (
    '_id' => '徐州住房公积金提取',
    'word' => '徐州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2471 => 
  array (
    '_id' => '许昌住房公积金查询',
    'word' => '许昌住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2472 => 
  array (
    '_id' => '许昌住房公积金提取',
    'word' => '许昌住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2473 => 
  array (
    '_id' => '宣城公积金贷款',
    'word' => '宣城公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2474 => 
  array (
    '_id' => '宣城住房公积金提取',
    'word' => '宣城住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2475 => 
  array (
    '_id' => '玄关',
    'word' => '玄关',
    'hits' => 0,
    'score' => 0,
  ),
  2476 => 
  array (
    '_id' => '玄关吊顶',
    'word' => '玄关吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  2477 => 
  array (
    '_id' => '玄关风水',
    'word' => '玄关风水',
    'hits' => 0,
    'score' => 0,
  ),
  2478 => 
  array (
    '_id' => '玄关柜',
    'word' => '玄关柜',
    'hits' => 0,
    'score' => 0,
  ),
  2479 => 
  array (
    '_id' => '玄关鞋柜',
    'word' => '玄关鞋柜',
    'hits' => 0,
    'score' => 0,
  ),
  2480 => 
  array (
    '_id' => '玄空风水',
    'word' => '玄空风水',
    'hits' => 0,
    'score' => 0,
  ),
  2481 => 
  array (
    '_id' => '学区',
    'word' => '学区',
    'hits' => 0,
    'score' => 0,
  ),
  2482 => 
  array (
    '_id' => '学区房',
    'word' => '学区房',
    'hits' => 0,
    'score' => 0,
  ),
  2483 => 
  array (
    '_id' => '学位房',
    'word' => '学位房',
    'hits' => 0,
    'score' => 0,
  ),
  2484 => 
  array (
    '_id' => '压力线',
    'word' => '压力线',
    'hits' => 0,
    'score' => 0,
  ),
  2485 => 
  array (
    '_id' => '雅安住房公积金查询',
    'word' => '雅安住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2486 => 
  array (
    '_id' => '雅安住房公积金提取',
    'word' => '雅安住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2487 => 
  array (
    '_id' => '雅立橱柜',
    'word' => '雅立橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  2488 => 
  array (
    '_id' => '雅路家纺',
    'word' => '雅路家纺',
    'hits' => 0,
    'score' => 0,
  ),
  2489 => 
  array (
    '_id' => '雅士利油漆',
    'word' => '雅士利油漆',
    'hits' => 0,
    'score' => 0,
  ),
  2490 => 
  array (
    '_id' => '亚斯王防盗门',
    'word' => '亚斯王防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  2491 => 
  array (
    '_id' => '烟台公积金贷款',
    'word' => '烟台公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2492 => 
  array (
    '_id' => '烟台住房公积金提取',
    'word' => '烟台住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2493 => 
  array (
    '_id' => '延安公积金贷款',
    'word' => '延安公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2494 => 
  array (
    '_id' => '延边公积金贷款',
    'word' => '延边公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2495 => 
  array (
    '_id' => '延边住房公积金提取',
    'word' => '延边住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2496 => 
  array (
    '_id' => '岩棉复合板',
    'word' => '岩棉复合板',
    'hits' => 0,
    'score' => 0,
  ),
  2497 => 
  array (
    '_id' => '盐城公积金贷款',
    'word' => '盐城公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2498 => 
  array (
    '_id' => '盐城住房公积金提取',
    'word' => '盐城住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2499 => 
  array (
    '_id' => '盐灯',
    'word' => '盐灯',
    'hits' => 0,
    'score' => 0,
  ),
  2500 => 
  array (
    '_id' => '晏记壁纸',
    'word' => '晏记壁纸',
    'hits' => 0,
    'score' => 0,
  ),
  2501 => 
  array (
    '_id' => '验房步骤',
    'word' => '验房步骤',
    'hits' => 0,
    'score' => 0,
  ),
  2502 => 
  array (
    '_id' => '验房工具',
    'word' => '验房工具',
    'hits' => 0,
    'score' => 0,
  ),
  2503 => 
  array (
    '_id' => '验房师',
    'word' => '验房师',
    'hits' => 0,
    'score' => 0,
  ),
  2504 => 
  array (
    '_id' => '扬州公积金贷款',
    'word' => '扬州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2505 => 
  array (
    '_id' => '扬州住房公积金查询',
    'word' => '扬州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2506 => 
  array (
    '_id' => '扬子地板',
    'word' => '扬子地板',
    'hits' => 0,
    'score' => 0,
  ),
  2507 => 
  array (
    '_id' => '扬子空调',
    'word' => '扬子空调',
    'hits' => 0,
    'score' => 0,
  ),
  2508 => 
  array (
    '_id' => '阳光板',
    'word' => '阳光板',
    'hits' => 0,
    'score' => 0,
  ),
  2509 => 
  array (
    '_id' => '阳光房',
    'word' => '阳光房',
    'hits' => 0,
    'score' => 0,
  ),
  2510 => 
  array (
    '_id' => '阳江公积金贷款',
    'word' => '阳江公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2511 => 
  array (
    '_id' => '阳江住房公积金查询',
    'word' => '阳江住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2512 => 
  array (
    '_id' => '阳泉公积金贷款',
    'word' => '阳泉公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2513 => 
  array (
    '_id' => '阳泉住房公积金查询',
    'word' => '阳泉住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2514 => 
  array (
    '_id' => '阳泉住房公积金提取',
    'word' => '阳泉住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2515 => 
  array (
    '_id' => '阳台',
    'word' => '阳台',
    'hits' => 0,
    'score' => 0,
  ),
  2516 => 
  array (
    '_id' => '阳台吊顶',
    'word' => '阳台吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  2517 => 
  array (
    '_id' => '阳台设计',
    'word' => '阳台设计',
    'hits' => 0,
    'score' => 0,
  ),
  2518 => 
  array (
    '_id' => '阳台榻榻米',
    'word' => '阳台榻榻米',
    'hits' => 0,
    'score' => 0,
  ),
  2519 => 
  array (
    '_id' => '阳台装修效果图',
    'word' => '阳台装修效果图',
    'hits' => 0,
    'score' => 0,
  ),
  2520 => 
  array (
    '_id' => '阳线(红线)',
    'word' => '阳线(红线)',
    'hits' => 0,
    'score' => 0,
  ),
  2521 => 
  array (
    '_id' => '洋房',
    'word' => '洋房',
    'hits' => 0,
    'score' => 0,
  ),
  2522 => 
  array (
    '_id' => '养老房',
    'word' => '养老房',
    'hits' => 0,
    'score' => 0,
  ),
  2523 => 
  array (
    '_id' => '样板房',
    'word' => '样板房',
    'hits' => 0,
    'score' => 0,
  ),
  2524 => 
  array (
    '_id' => '样板间',
    'word' => '样板间',
    'hits' => 0,
    'score' => 0,
  ),
  2525 => 
  array (
    '_id' => '遥控开关',
    'word' => '遥控开关',
    'hits' => 0,
    'score' => 0,
  ),
  2526 => 
  array (
    '_id' => '业委会',
    'word' => '业委会',
    'hits' => 0,
    'score' => 0,
  ),
  2527 => 
  array (
    '_id' => '业主',
    'word' => '业主',
    'hits' => 0,
    'score' => 0,
  ),
  2528 => 
  array (
    '_id' => '业主公约',
    'word' => '业主公约',
    'hits' => 0,
    'score' => 0,
  ),
  2529 => 
  array (
    '_id' => '业主手册',
    'word' => '业主手册',
    'hits' => 0,
    'score' => 0,
  ),
  2530 => 
  array (
    '_id' => '业主委员会',
    'word' => '业主委员会',
    'hits' => 0,
    'score' => 0,
  ),
  2531 => 
  array (
    '_id' => '业主委员会的作用与职责',
    'word' => '业主委员会的作用与职责',
    'hits' => 0,
    'score' => 0,
  ),
  2532 => 
  array (
    '_id' => '液体墙纸',
    'word' => '液体墙纸',
    'hits' => 0,
    'score' => 0,
  ),
  2533 => 
  array (
    '_id' => '一般市场回报率',
    'word' => '一般市场回报率',
    'hits' => 0,
    'score' => 0,
  ),
  2534 => 
  array (
    '_id' => '一次性付款',
    'word' => '一次性付款',
    'hits' => 0,
    'score' => 0,
  ),
  2535 => 
  array (
    '_id' => '一次性买断价',
    'word' => '一次性买断价',
    'hits' => 0,
    'score' => 0,
  ),
  2536 => 
  array (
    '_id' => '一级市场',
    'word' => '一级市场',
    'hits' => 0,
    'score' => 0,
  ),
  2537 => 
  array (
    '_id' => '一口价',
    'word' => '一口价',
    'hits' => 0,
    'score' => 0,
  ),
  2538 => 
  array (
    '_id' => '一年贷款利率',
    'word' => '一年贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  2539 => 
  array (
    '_id' => '一品迪邦漆',
    'word' => '一品迪邦漆',
    'hits' => 0,
    'score' => 0,
  ),
  2540 => 
  array (
    '_id' => '一手房',
    'word' => '一手房',
    'hits' => 0,
    'score' => 0,
  ),
  2541 => 
  array (
    '_id' => '一统木门',
    'word' => '一统木门',
    'hits' => 0,
    'score' => 0,
  ),
  2542 => 
  array (
    '_id' => '一叶兰',
    'word' => '一叶兰',
    'hits' => 0,
    'score' => 0,
  ),
  2543 => 
  array (
    '_id' => '一一木门',
    'word' => '一一木门',
    'hits' => 0,
    'score' => 0,
  ),
  2544 => 
  array (
    '_id' => '伊春住房公积金查询',
    'word' => '伊春住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2545 => 
  array (
    '_id' => '伊春住房公积金提取',
    'word' => '伊春住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2546 => 
  array (
    '_id' => '伊犁公积金贷款',
    'word' => '伊犁公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2547 => 
  array (
    '_id' => '伊莎莱窗帘',
    'word' => '伊莎莱窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  2548 => 
  array (
    '_id' => '衣柜门',
    'word' => '衣柜门',
    'hits' => 0,
    'score' => 0,
  ),
  2549 => 
  array (
    '_id' => '衣柜推拉门',
    'word' => '衣柜推拉门',
    'hits' => 0,
    'score' => 0,
  ),
  2550 => 
  array (
    '_id' => '衣帽架',
    'word' => '衣帽架',
    'hits' => 0,
    'score' => 0,
  ),
  2551 => 
  array (
    '_id' => '衣帽间设计',
    'word' => '衣帽间设计',
    'hits' => 0,
    'score' => 0,
  ),
  2552 => 
  array (
    '_id' => '依诺瓷砖',
    'word' => '依诺瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  2553 => 
  array (
    '_id' => '宜昌公积金贷款',
    'word' => '宜昌公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2554 => 
  array (
    '_id' => '宜昌住房公积金查询',
    'word' => '宜昌住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2555 => 
  array (
    '_id' => '宜春住房公积金查询',
    'word' => '宜春住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2556 => 
  array (
    '_id' => '宜灯灯饰',
    'word' => '宜灯灯饰',
    'hits' => 0,
    'score' => 0,
  ),
  2557 => 
  array (
    '_id' => '宜家风格',
    'word' => '宜家风格',
    'hits' => 0,
    'score' => 0,
  ),
  2558 => 
  array (
    '_id' => '移门',
    'word' => '移门',
    'hits' => 0,
    'score' => 0,
  ),
  2559 => 
  array (
    '_id' => '遗产税暂行条例',
    'word' => '遗产税暂行条例',
    'hits' => 0,
    'score' => 0,
  ),
  2560 => 
  array (
    '_id' => '以房养老',
    'word' => '以房养老',
    'hits' => 0,
    'score' => 0,
  ),
  2561 => 
  array (
    '_id' => '以房养老是什么意思',
    'word' => '以房养老是什么意思',
    'hits' => 0,
    'score' => 0,
  ),
  2562 => 
  array (
    '_id' => '义乌公积金贷款',
    'word' => '义乌公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2563 => 
  array (
    '_id' => '义乌住房公积金查询',
    'word' => '义乌住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2564 => 
  array (
    '_id' => '义乌住房公积金提取',
    'word' => '义乌住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2565 => 
  array (
    '_id' => '艺术玻璃',
    'word' => '艺术玻璃',
    'hits' => 0,
    'score' => 0,
  ),
  2566 => 
  array (
    '_id' => '艺术漆',
    'word' => '艺术漆',
    'hits' => 0,
    'score' => 0,
  ),
  2567 => 
  array (
    '_id' => '艺王木门',
    'word' => '艺王木门',
    'hits' => 0,
    'score' => 0,
  ),
  2568 => 
  array (
    '_id' => '异产毗邻',
    'word' => '异产毗邻',
    'hits' => 0,
    'score' => 0,
  ),
  2569 => 
  array (
    '_id' => '异地购房',
    'word' => '异地购房',
    'hits' => 0,
    'score' => 0,
  ),
  2570 => 
  array (
    '_id' => '异地住房公积金贷款',
    'word' => '异地住房公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2571 => 
  array (
    '_id' => '易高整体衣柜',
    'word' => '易高整体衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  2572 => 
  array (
    '_id' => '易经风水',
    'word' => '易经风水',
    'hits' => 0,
    'score' => 0,
  ),
  2573 => 
  array (
    '_id' => '益高卫浴',
    'word' => '益高卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  2574 => 
  array (
    '_id' => '益盟照明',
    'word' => '益盟照明',
    'hits' => 0,
    'score' => 0,
  ),
  2575 => 
  array (
    '_id' => '益园木门',
    'word' => '益园木门',
    'hits' => 0,
    'score' => 0,
  ),
  2576 => 
  array (
    '_id' => '阴宅风水',
    'word' => '阴宅风水',
    'hits' => 0,
    'score' => 0,
  ),
  2577 => 
  array (
    '_id' => '银皇后',
    'word' => '银皇后',
    'hits' => 0,
    'score' => 0,
  ),
  2578 => 
  array (
    '_id' => '银行按揭',
    'word' => '银行按揭',
    'hits' => 0,
    'score' => 0,
  ),
  2579 => 
  array (
    '_id' => '银行贷款利率',
    'word' => '银行贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  2580 => 
  array (
    '_id' => '银行贷款利息怎么算',
    'word' => '银行贷款利息怎么算',
    'hits' => 0,
    'score' => 0,
  ),
  2581 => 
  array (
    '_id' => '银行贷款条件',
    'word' => '银行贷款条件',
    'hits' => 0,
    'score' => 0,
  ),
  2582 => 
  array (
    '_id' => '银行个人贷款条件',
    'word' => '银行个人贷款条件',
    'hits' => 0,
    'score' => 0,
  ),
  2583 => 
  array (
    '_id' => '银行无抵押贷款',
    'word' => '银行无抵押贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2584 => 
  array (
    '_id' => '隐形纱窗',
    'word' => '隐形纱窗',
    'hits' => 0,
    'score' => 0,
  ),
  2585 => 
  array (
    '_id' => '印花税计算',
    'word' => '印花税计算',
    'hits' => 0,
    'score' => 0,
  ),
  2586 => 
  array (
    '_id' => '印花税率表',
    'word' => '印花税率表',
    'hits' => 0,
    'score' => 0,
  ),
  2587 => 
  array (
    '_id' => '应急照明灯',
    'word' => '应急照明灯',
    'hits' => 0,
    'score' => 0,
  ),
  2588 => 
  array (
    '_id' => '英伦华庄家具',
    'word' => '英伦华庄家具',
    'hits' => 0,
    'score' => 0,
  ),
  2589 => 
  array (
    '_id' => '英式田园风格',
    'word' => '英式田园风格',
    'hits' => 0,
    'score' => 0,
  ),
  2590 => 
  array (
    '_id' => '樱花热水器',
    'word' => '樱花热水器',
    'hits' => 0,
    'score' => 0,
  ),
  2591 => 
  array (
    '_id' => '樱花水槽',
    'word' => '樱花水槽',
    'hits' => 0,
    'score' => 0,
  ),
  2592 => 
  array (
    '_id' => '鹦鹉油漆',
    'word' => '鹦鹉油漆',
    'hits' => 0,
    'score' => 0,
  ),
  2593 => 
  array (
    '_id' => '鹰牌马桶',
    'word' => '鹰牌马桶',
    'hits' => 0,
    'score' => 0,
  ),
  2594 => 
  array (
    '_id' => '鹰牌陶瓷',
    'word' => '鹰牌陶瓷',
    'hits' => 0,
    'score' => 0,
  ),
  2595 => 
  array (
    '_id' => '鹰潭住房公积金查询',
    'word' => '鹰潭住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2596 => 
  array (
    '_id' => '鹰潭住房公积金提取',
    'word' => '鹰潭住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2597 => 
  array (
    '_id' => '鹰卫浴',
    'word' => '鹰卫浴',
    'hits' => 0,
    'score' => 0,
  ),
  2598 => 
  array (
    '_id' => '鹰卫浴马桶',
    'word' => '鹰卫浴马桶',
    'hits' => 0,
    'score' => 0,
  ),
  2599 => 
  array (
    '_id' => '盈润佳门铃',
    'word' => '盈润佳门铃',
    'hits' => 0,
    'score' => 0,
  ),
  2600 => 
  array (
    '_id' => '荧光漆',
    'word' => '荧光漆',
    'hits' => 0,
    'score' => 0,
  ),
  2601 => 
  array (
    '_id' => '营口公积金贷款',
    'word' => '营口公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2602 => 
  array (
    '_id' => '营口住房公积金查询',
    'word' => '营口住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2603 => 
  array (
    '_id' => '营口住房公积金提取',
    'word' => '营口住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2604 => 
  array (
    '_id' => '营业税',
    'word' => '营业税',
    'hits' => 0,
    'score' => 0,
  ),
  2605 => 
  array (
    '_id' => '营业税附加税',
    'word' => '营业税附加税',
    'hits' => 0,
    'score' => 0,
  ),
  2606 => 
  array (
    '_id' => '永通电线',
    'word' => '永通电线',
    'hits' => 0,
    'score' => 0,
  ),
  2607 => 
  array (
    '_id' => '永州公积金贷款',
    'word' => '永州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2608 => 
  array (
    '_id' => '永州住房公积金查询',
    'word' => '永州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2609 => 
  array (
    '_id' => '用地性质',
    'word' => '用地性质',
    'hits' => 0,
    'score' => 0,
  ),
  2610 => 
  array (
    '_id' => '用房产证贷款',
    'word' => '用房产证贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2611 => 
  array (
    '_id' => '优廉门铃',
    'word' => '优廉门铃',
    'hits' => 0,
    'score' => 0,
  ),
  2612 => 
  array (
    '_id' => '油漆',
    'word' => '油漆',
    'hits' => 0,
    'score' => 0,
  ),
  2613 => 
  array (
    '_id' => '油漆工施工规范及验收标准',
    'word' => '油漆工施工规范及验收标准',
    'hits' => 0,
    'score' => 0,
  ),
  2614 => 
  array (
    '_id' => '油漆品牌',
    'word' => '油漆品牌',
    'hits' => 0,
    'score' => 0,
  ),
  2615 => 
  array (
    '_id' => '油烟机',
    'word' => '油烟机',
    'hits' => 0,
    'score' => 0,
  ),
  2616 => 
  array (
    '_id' => '柚木地板',
    'word' => '柚木地板',
    'hits' => 0,
    'score' => 0,
  ),
  2617 => 
  array (
    '_id' => '友邦浴霸',
    'word' => '友邦浴霸',
    'hits' => 0,
    'score' => 0,
  ),
  2618 => 
  array (
    '_id' => '有机硅',
    'word' => '有机硅',
    'hits' => 0,
    'score' => 0,
  ),
  2619 => 
  array (
    '_id' => '有权证',
    'word' => '有权证',
    'hits' => 0,
    'score' => 0,
  ),
  2620 => 
  array (
    '_id' => '有限产权房',
    'word' => '有限产权房',
    'hits' => 0,
    'score' => 0,
  ),
  2621 => 
  array (
    '_id' => '釉面砖',
    'word' => '釉面砖',
    'hits' => 0,
    'score' => 0,
  ),
  2622 => 
  array (
    '_id' => '余姚住房公积金查询',
    'word' => '余姚住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2623 => 
  array (
    '_id' => '余姚住房公积金提取',
    'word' => '余姚住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2624 => 
  array (
    '_id' => '鱼缸的摆放位置',
    'word' => '鱼缸的摆放位置',
    'hits' => 0,
    'score' => 0,
  ),
  2625 => 
  array (
    '_id' => '逾期收房',
    'word' => '逾期收房',
    'hits' => 0,
    'score' => 0,
  ),
  2626 => 
  array (
    '_id' => '逾期违约金',
    'word' => '逾期违约金',
    'hits' => 0,
    'score' => 0,
  ),
  2627 => 
  array (
    '_id' => '榆林公积金贷款',
    'word' => '榆林公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2628 => 
  array (
    '_id' => '榆林住房公积金查询',
    'word' => '榆林住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2629 => 
  array (
    '_id' => '榆林住房公积金提取',
    'word' => '榆林住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2630 => 
  array (
    '_id' => '玉兰墙纸',
    'word' => '玉兰墙纸',
    'hits' => 0,
    'score' => 0,
  ),
  2631 => 
  array (
    '_id' => '玉林公积金贷款',
    'word' => '玉林公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2632 => 
  array (
    '_id' => '玉林住房公积金提取',
    'word' => '玉林住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2633 => 
  array (
    '_id' => '玉溪住房公积金查询',
    'word' => '玉溪住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2634 => 
  array (
    '_id' => '玉溪住房公积金提取',
    'word' => '玉溪住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2635 => 
  array (
    '_id' => '浴缸',
    'word' => '浴缸',
    'hits' => 0,
    'score' => 0,
  ),
  2636 => 
  array (
    '_id' => '浴缸尺寸',
    'word' => '浴缸尺寸',
    'hits' => 0,
    'score' => 0,
  ),
  2637 => 
  array (
    '_id' => '浴室柜',
    'word' => '浴室柜',
    'hits' => 0,
    'score' => 0,
  ),
  2638 => 
  array (
    '_id' => '预售价',
    'word' => '预售价',
    'hits' => 0,
    'score' => 0,
  ),
  2639 => 
  array (
    '_id' => '预售什么意思',
    'word' => '预售什么意思',
    'hits' => 0,
    'score' => 0,
  ),
  2640 => 
  array (
    '_id' => '预售许可证',
    'word' => '预售许可证',
    'hits' => 0,
    'score' => 0,
  ),
  2641 => 
  array (
    '_id' => '预应力混凝土',
    'word' => '预应力混凝土',
    'hits' => 0,
    'score' => 0,
  ),
  2642 => 
  array (
    '_id' => '预租售',
    'word' => '预租售',
    'hits' => 0,
    'score' => 0,
  ),
  2643 => 
  array (
    '_id' => '原木家具',
    'word' => '原木家具',
    'hits' => 0,
    'score' => 0,
  ),
  2644 => 
  array (
    '_id' => '院子风水',
    'word' => '院子风水',
    'hits' => 0,
    'score' => 0,
  ),
  2645 => 
  array (
    '_id' => '约克空调',
    'word' => '约克空调',
    'hits' => 0,
    'score' => 0,
  ),
  2646 => 
  array (
    '_id' => '岳阳公积金贷款',
    'word' => '岳阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2647 => 
  array (
    '_id' => '岳阳住房公积金查询',
    'word' => '岳阳住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2648 => 
  array (
    '_id' => '跃层',
    'word' => '跃层',
    'hits' => 0,
    'score' => 0,
  ),
  2649 => 
  array (
    '_id' => '跃层式商品房',
    'word' => '跃层式商品房',
    'hits' => 0,
    'score' => 0,
  ),
  2650 => 
  array (
    '_id' => '跃层式住宅',
    'word' => '跃层式住宅',
    'hits' => 0,
    'score' => 0,
  ),
  2651 => 
  array (
    '_id' => '跃升式住宅',
    'word' => '跃升式住宅',
    'hits' => 0,
    'score' => 0,
  ),
  2652 => 
  array (
    '_id' => '云浮住房公积金查询',
    'word' => '云浮住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2653 => 
  array (
    '_id' => '云浮住房公积金提取',
    'word' => '云浮住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2654 => 
  array (
    '_id' => '云石灯',
    'word' => '云石灯',
    'hits' => 0,
    'score' => 0,
  ),
  2655 => 
  array (
    '_id' => '运城公积金贷款',
    'word' => '运城公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2656 => 
  array (
    '_id' => '运城住房公积金提取',
    'word' => '运城住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2657 => 
  array (
    '_id' => '再上市房',
    'word' => '再上市房',
    'hits' => 0,
    'score' => 0,
  ),
  2658 => 
  array (
    '_id' => '在建工程',
    'word' => '在建工程',
    'hits' => 0,
    'score' => 0,
  ),
  2659 => 
  array (
    '_id' => '枣庄公积金贷款',
    'word' => '枣庄公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2660 => 
  array (
    '_id' => '枣庄住房公积金提取',
    'word' => '枣庄住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2661 => 
  array (
    '_id' => '怎么看风水',
    'word' => '怎么看风水',
    'hits' => 0,
    'score' => 0,
  ),
  2662 => 
  array (
    '_id' => '怎么买房',
    'word' => '怎么买房',
    'hits' => 0,
    'score' => 0,
  ),
  2663 => 
  array (
    '_id' => '怎么取公积金',
    'word' => '怎么取公积金',
    'hits' => 0,
    'score' => 0,
  ),
  2664 => 
  array (
    '_id' => '怎么去除油漆味',
    'word' => '怎么去除油漆味',
    'hits' => 0,
    'score' => 0,
  ),
  2665 => 
  array (
    '_id' => '赠送面积',
    'word' => '赠送面积',
    'hits' => 0,
    'score' => 0,
  ),
  2666 => 
  array (
    '_id' => '赠与房产过户费用',
    'word' => '赠与房产过户费用',
    'hits' => 0,
    'score' => 0,
  ),
  2667 => 
  array (
    '_id' => '宅基地',
    'word' => '宅基地',
    'hits' => 0,
    'score' => 0,
  ),
  2668 => 
  array (
    '_id' => '宅基地继承',
    'word' => '宅基地继承',
    'hits' => 0,
    'score' => 0,
  ),
  2669 => 
  array (
    '_id' => '宅基地流转',
    'word' => '宅基地流转',
    'hits' => 0,
    'score' => 0,
  ),
  2670 => 
  array (
    '_id' => '宅基地使用权',
    'word' => '宅基地使用权',
    'hits' => 0,
    'score' => 0,
  ),
  2671 => 
  array (
    '_id' => '宅基地证',
    'word' => '宅基地证',
    'hits' => 0,
    'score' => 0,
  ),
  2672 => 
  array (
    '_id' => '宅基地证明',
    'word' => '宅基地证明',
    'hits' => 0,
    'score' => 0,
  ),
  2673 => 
  array (
    '_id' => '展鹏瓷砖',
    'word' => '展鹏瓷砖',
    'hits' => 0,
    'score' => 0,
  ),
  2674 => 
  array (
    '_id' => '占地面积',
    'word' => '占地面积',
    'hits' => 0,
    'score' => 0,
  ),
  2675 => 
  array (
    '_id' => '占用面积',
    'word' => '占用面积',
    'hits' => 0,
    'score' => 0,
  ),
  2676 => 
  array (
    '_id' => '湛江公积金贷款',
    'word' => '湛江公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2677 => 
  array (
    '_id' => '湛江住房公积金查询',
    'word' => '湛江住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2678 => 
  array (
    '_id' => '张家界住房公积金查询',
    'word' => '张家界住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2679 => 
  array (
    '_id' => '张家界住房公积金提取',
    'word' => '张家界住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2680 => 
  array (
    '_id' => '张家口公积金贷款',
    'word' => '张家口公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2681 => 
  array (
    '_id' => '张家口住房公积金查询',
    'word' => '张家口住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2682 => 
  array (
    '_id' => '张家口住房公积金提取',
    'word' => '张家口住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2683 => 
  array (
    '_id' => '漳州公积金贷款',
    'word' => '漳州公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2684 => 
  array (
    '_id' => '昭通公积金贷款',
    'word' => '昭通公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2685 => 
  array (
    '_id' => '昭通住房公积金提取',
    'word' => '昭通住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2686 => 
  array (
    '_id' => '肇庆公积金贷款',
    'word' => '肇庆公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2687 => 
  array (
    '_id' => '肇庆住房公积金提取',
    'word' => '肇庆住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2688 => 
  array (
    '_id' => '遮光窗帘',
    'word' => '遮光窗帘',
    'hits' => 0,
    'score' => 0,
  ),
  2689 => 
  array (
    '_id' => '遮阳布',
    'word' => '遮阳布',
    'hits' => 0,
    'score' => 0,
  ),
  2690 => 
  array (
    '_id' => '真皮沙发',
    'word' => '真皮沙发',
    'hits' => 0,
    'score' => 0,
  ),
  2691 => 
  array (
    '_id' => '真皮沙发保养',
    'word' => '真皮沙发保养',
    'hits' => 0,
    'score' => 0,
  ),
  2692 => 
  array (
    '_id' => '真皮沙发如何保养',
    'word' => '真皮沙发如何保养',
    'hits' => 0,
    'score' => 0,
  ),
  2693 => 
  array (
    '_id' => '真皮座椅',
    'word' => '真皮座椅',
    'hits' => 0,
    'score' => 0,
  ),
  2694 => 
  array (
    '_id' => '真石漆',
    'word' => '真石漆',
    'hits' => 0,
    'score' => 0,
  ),
  2695 => 
  array (
    '_id' => '镇江住房公积金查询',
    'word' => '镇江住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2696 => 
  array (
    '_id' => '镇江住房公积金提取',
    'word' => '镇江住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2697 => 
  array (
    '_id' => '征地',
    'word' => '征地',
    'hits' => 0,
    'score' => 0,
  ),
  2698 => 
  array (
    '_id' => '征地补偿',
    'word' => '征地补偿',
    'hits' => 0,
    'score' => 0,
  ),
  2699 => 
  array (
    '_id' => '征地拆迁',
    'word' => '征地拆迁',
    'hits' => 0,
    'score' => 0,
  ),
  2700 => 
  array (
    '_id' => '整体厨房价格',
    'word' => '整体厨房价格',
    'hits' => 0,
    'score' => 0,
  ),
  2701 => 
  array (
    '_id' => '整体橱柜',
    'word' => '整体橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  2702 => 
  array (
    '_id' => '整体家具',
    'word' => '整体家具',
    'hits' => 0,
    'score' => 0,
  ),
  2703 => 
  array (
    '_id' => '整体衣柜',
    'word' => '整体衣柜',
    'hits' => 0,
    'score' => 0,
  ),
  2704 => 
  array (
    '_id' => '整体衣柜十大品牌',
    'word' => '整体衣柜十大品牌',
    'hits' => 0,
    'score' => 0,
  ),
  2705 => 
  array (
    '_id' => '正杨家具',
    'word' => '正杨家具',
    'hits' => 0,
    'score' => 0,
  ),
  2706 => 
  array (
    '_id' => '郑州经济适用房',
    'word' => '郑州经济适用房',
    'hits' => 0,
    'score' => 0,
  ),
  2707 => 
  array (
    '_id' => '郑州住房公积金查询',
    'word' => '郑州住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2708 => 
  array (
    '_id' => '郑州住房公积金提取',
    'word' => '郑州住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2709 => 
  array (
    '_id' => '政务配套',
    'word' => '政务配套',
    'hits' => 0,
    'score' => 0,
  ),
  2710 => 
  array (
    '_id' => '直系亲属房产赠与',
    'word' => '直系亲属房产赠与',
    'hits' => 0,
    'score' => 0,
  ),
  2711 => 
  array (
    '_id' => '纸尚美学墙纸',
    'word' => '纸尚美学墙纸',
    'hits' => 0,
    'score' => 0,
  ),
  2712 => 
  array (
    '_id' => '志邦橱柜',
    'word' => '志邦橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  2713 => 
  array (
    '_id' => '制式合同',
    'word' => '制式合同',
    'hits' => 0,
    'score' => 0,
  ),
  2714 => 
  array (
    '_id' => '质感涂料',
    'word' => '质感涂料',
    'hits' => 0,
    'score' => 0,
  ),
  2715 => 
  array (
    '_id' => '智能化小区',
    'word' => '智能化小区',
    'hits' => 0,
    'score' => 0,
  ),
  2716 => 
  array (
    '_id' => '智能家居',
    'word' => '智能家居',
    'hits' => 0,
    'score' => 0,
  ),
  2717 => 
  array (
    '_id' => '智能开关',
    'word' => '智能开关',
    'hits' => 0,
    'score' => 0,
  ),
  2718 => 
  array (
    '_id' => '智能马桶',
    'word' => '智能马桶',
    'hits' => 0,
    'score' => 0,
  ),
  2719 => 
  array (
    '_id' => '中国第一高楼',
    'word' => '中国第一高楼',
    'hits' => 0,
    'score' => 0,
  ),
  2720 => 
  array (
    '_id' => '中国房产',
    'word' => '中国房产',
    'hits' => 0,
    'score' => 0,
  ),
  2721 => 
  array (
    '_id' => '中国房地产排名',
    'word' => '中国房地产排名',
    'hits' => 0,
    'score' => 0,
  ),
  2722 => 
  array (
    '_id' => '中国房地产泡沫',
    'word' => '中国房地产泡沫',
    'hits' => 0,
    'score' => 0,
  ),
  2723 => 
  array (
    '_id' => '中国房价',
    'word' => '中国房价',
    'hits' => 0,
    'score' => 0,
  ),
  2724 => 
  array (
    '_id' => '中国房价会跌',
    'word' => '中国房价会跌',
    'hits' => 0,
    'score' => 0,
  ),
  2725 => 
  array (
    '_id' => '中国房价排名',
    'word' => '中国房价排名',
    'hits' => 0,
    'score' => 0,
  ),
  2726 => 
  array (
    '_id' => '中国房市',
    'word' => '中国房市',
    'hits' => 0,
    'score' => 0,
  ),
  2727 => 
  array (
    '_id' => '中国豪宅',
    'word' => '中国豪宅',
    'hits' => 0,
    'score' => 0,
  ),
  2728 => 
  array (
    '_id' => '中国婚姻法',
    'word' => '中国婚姻法',
    'hits' => 0,
    'score' => 0,
  ),
  2729 => 
  array (
    '_id' => '中介买房注意事项',
    'word' => '中介买房注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  2730 => 
  array (
    '_id' => '中式餐厅',
    'word' => '中式餐厅',
    'hits' => 0,
    'score' => 0,
  ),
  2731 => 
  array (
    '_id' => '中式吊顶',
    'word' => '中式吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  2732 => 
  array (
    '_id' => '中式风格',
    'word' => '中式风格',
    'hits' => 0,
    'score' => 0,
  ),
  2733 => 
  array (
    '_id' => '中式家具',
    'word' => '中式家具',
    'hits' => 0,
    'score' => 0,
  ),
  2734 => 
  array (
    '_id' => '中式客厅',
    'word' => '中式客厅',
    'hits' => 0,
    'score' => 0,
  ),
  2735 => 
  array (
    '_id' => '中式设计',
    'word' => '中式设计',
    'hits' => 0,
    'score' => 0,
  ),
  2736 => 
  array (
    '_id' => '中式装修风格',
    'word' => '中式装修风格',
    'hits' => 0,
    'score' => 0,
  ),
  2737 => 
  array (
    '_id' => '中水处理',
    'word' => '中水处理',
    'hits' => 0,
    'score' => 0,
  ),
  2738 => 
  array (
    '_id' => '中卫住房公积金查询',
    'word' => '中卫住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2739 => 
  array (
    '_id' => '中卫住房公积金提取',
    'word' => '中卫住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2740 => 
  array (
    '_id' => '中修工程',
    'word' => '中修工程',
    'hits' => 0,
    'score' => 0,
  ),
  2741 => 
  array (
    '_id' => '中央空调',
    'word' => '中央空调',
    'hits' => 0,
    'score' => 0,
  ),
  2742 => 
  array (
    '_id' => '中央空调安装',
    'word' => '中央空调安装',
    'hits' => 0,
    'score' => 0,
  ),
  2743 => 
  array (
    '_id' => '中央空调工作原理',
    'word' => '中央空调工作原理',
    'hits' => 0,
    'score' => 0,
  ),
  2744 => 
  array (
    '_id' => '中央空调清洗',
    'word' => '中央空调清洗',
    'hits' => 0,
    'score' => 0,
  ),
  2745 => 
  array (
    '_id' => '重庆房产税',
    'word' => '重庆房产税',
    'hits' => 0,
    'score' => 0,
  ),
  2746 => 
  array (
    '_id' => '重庆住房公积金查询',
    'word' => '重庆住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2747 => 
  array (
    '_id' => '重庆住房公积金提取',
    'word' => '重庆住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2748 => 
  array (
    '_id' => '舟山住房公积金提取',
    'word' => '舟山住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2749 => 
  array (
    '_id' => '周口公积金贷款',
    'word' => '周口公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2750 => 
  array (
    '_id' => '周口住房公积金查询',
    'word' => '周口住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2751 => 
  array (
    '_id' => '周口住房公积金提取',
    'word' => '周口住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2752 => 
  array (
    '_id' => '株洲公积金贷款',
    'word' => '株洲公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2753 => 
  array (
    '_id' => '株洲住房公积金查询',
    'word' => '株洲住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2754 => 
  array (
    '_id' => '株洲住房公积金提取',
    'word' => '株洲住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2755 => 
  array (
    '_id' => '珠海住房公积金查询',
    'word' => '珠海住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2756 => 
  array (
    '_id' => '竹地板好还是木地板好',
    'word' => '竹地板好还是木地板好',
    'hits' => 0,
    'score' => 0,
  ),
  2757 => 
  array (
    '_id' => '住房保障',
    'word' => '住房保障',
    'hits' => 0,
    'score' => 0,
  ),
  2758 => 
  array (
    '_id' => '住房储蓄贷款',
    'word' => '住房储蓄贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2759 => 
  array (
    '_id' => '住房风水',
    'word' => '住房风水',
    'hits' => 0,
    'score' => 0,
  ),
  2760 => 
  array (
    '_id' => '住房公积金',
    'word' => '住房公积金',
    'hits' => 0,
    'score' => 0,
  ),
  2761 => 
  array (
    '_id' => '住房公积金查询个人账户',
    'word' => '住房公积金查询个人账户',
    'hits' => 0,
    'score' => 0,
  ),
  2762 => 
  array (
    '_id' => '住房公积金查询密码',
    'word' => '住房公积金查询密码',
    'hits' => 0,
    'score' => 0,
  ),
  2763 => 
  array (
    '_id' => '住房公积金查询余额',
    'word' => '住房公积金查询余额',
    'hits' => 0,
    'score' => 0,
  ),
  2764 => 
  array (
    '_id' => '住房公积金贷款比例',
    'word' => '住房公积金贷款比例',
    'hits' => 0,
    'score' => 0,
  ),
  2765 => 
  array (
    '_id' => '住房公积金贷款额度',
    'word' => '住房公积金贷款额度',
    'hits' => 0,
    'score' => 0,
  ),
  2766 => 
  array (
    '_id' => '住房公积金贷款计算',
    'word' => '住房公积金贷款计算',
    'hits' => 0,
    'score' => 0,
  ),
  2767 => 
  array (
    '_id' => '住房公积金贷款买房',
    'word' => '住房公积金贷款买房',
    'hits' => 0,
    'score' => 0,
  ),
  2768 => 
  array (
    '_id' => '住房公积金贷款申请',
    'word' => '住房公积金贷款申请',
    'hits' => 0,
    'score' => 0,
  ),
  2769 => 
  array (
    '_id' => '住房公积金贷款要求',
    'word' => '住房公积金贷款要求',
    'hits' => 0,
    'score' => 0,
  ),
  2770 => 
  array (
    '_id' => '住房公积金管理',
    'word' => '住房公积金管理',
    'hits' => 0,
    'score' => 0,
  ),
  2771 => 
  array (
    '_id' => '住房公积金缴纳',
    'word' => '住房公积金缴纳',
    'hits' => 0,
    'score' => 0,
  ),
  2772 => 
  array (
    '_id' => '住房公积金提取',
    'word' => '住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2773 => 
  array (
    '_id' => '住房公积金提取申请',
    'word' => '住房公积金提取申请',
    'hits' => 0,
    'score' => 0,
  ),
  2774 => 
  array (
    '_id' => '住房公积金提取条件',
    'word' => '住房公积金提取条件',
    'hits' => 0,
    'score' => 0,
  ),
  2775 => 
  array (
    '_id' => '住房公积金销户提取',
    'word' => '住房公积金销户提取',
    'hits' => 0,
    'score' => 0,
  ),
  2776 => 
  array (
    '_id' => '住房公积金怎么查',
    'word' => '住房公积金怎么查',
    'hits' => 0,
    'score' => 0,
  ),
  2777 => 
  array (
    '_id' => '住房公积金怎么贷款',
    'word' => '住房公积金怎么贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2778 => 
  array (
    '_id' => '住房合作社',
    'word' => '住房合作社',
    'hits' => 0,
    'score' => 0,
  ),
  2779 => 
  array (
    '_id' => '住房基金',
    'word' => '住房基金',
    'hits' => 0,
    'score' => 0,
  ),
  2780 => 
  array (
    '_id' => '住房商业贷款',
    'word' => '住房商业贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2781 => 
  array (
    '_id' => '住房商业贷款利率',
    'word' => '住房商业贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  2782 => 
  array (
    '_id' => '住房维修基金',
    'word' => '住房维修基金',
    'hits' => 0,
    'score' => 0,
  ),
  2783 => 
  array (
    '_id' => '住房制度改革',
    'word' => '住房制度改革',
    'hits' => 0,
    'score' => 0,
  ),
  2784 => 
  array (
    '_id' => '住宅单方综合造价',
    'word' => '住宅单方综合造价',
    'hits' => 0,
    'score' => 0,
  ),
  2785 => 
  array (
    '_id' => '住宅风水布局与禁忌',
    'word' => '住宅风水布局与禁忌',
    'hits' => 0,
    'score' => 0,
  ),
  2786 => 
  array (
    '_id' => '住宅共用部位',
    'word' => '住宅共用部位',
    'hits' => 0,
    'score' => 0,
  ),
  2787 => 
  array (
    '_id' => '住宅共用部位共用设施设备维修基金',
    'word' => '住宅共用部位共用设施设备维修基金',
    'hits' => 0,
    'score' => 0,
  ),
  2788 => 
  array (
    '_id' => '住宅共用设施设备',
    'word' => '住宅共用设施设备',
    'hits' => 0,
    'score' => 0,
  ),
  2789 => 
  array (
    '_id' => '住宅容积率',
    'word' => '住宅容积率',
    'hits' => 0,
    'score' => 0,
  ),
  2790 => 
  array (
    '_id' => '住宅效果图设计',
    'word' => '住宅效果图设计',
    'hits' => 0,
    'score' => 0,
  ),
  2791 => 
  array (
    '_id' => '住宅用地',
    'word' => '住宅用地',
    'hits' => 0,
    'score' => 0,
  ),
  2792 => 
  array (
    '_id' => '注册物业管理',
    'word' => '注册物业管理',
    'hits' => 0,
    'score' => 0,
  ),
  2793 => 
  array (
    '_id' => '驻马店住房公积金查询',
    'word' => '驻马店住房公积金查询',
    'hits' => 0,
    'score' => 0,
  ),
  2794 => 
  array (
    '_id' => '铸诚防盗门',
    'word' => '铸诚防盗门',
    'hits' => 0,
    'score' => 0,
  ),
  2795 => 
  array (
    '_id' => '铸造涂料',
    'word' => '铸造涂料',
    'hits' => 0,
    'score' => 0,
  ),
  2796 => 
  array (
    '_id' => '专有所有权',
    'word' => '专有所有权',
    'hits' => 0,
    'score' => 0,
  ),
  2797 => 
  array (
    '_id' => '砖混结构',
    'word' => '砖混结构',
    'hits' => 0,
    'score' => 0,
  ),
  2798 => 
  array (
    '_id' => '砖混结构施工',
    'word' => '砖混结构施工',
    'hits' => 0,
    'score' => 0,
  ),
  2799 => 
  array (
    '_id' => '砖木结构',
    'word' => '砖木结构',
    'hits' => 0,
    'score' => 0,
  ),
  2800 => 
  array (
    '_id' => '砖砌橱柜',
    'word' => '砖砌橱柜',
    'hits' => 0,
    'score' => 0,
  ),
  2801 => 
  array (
    '_id' => '转换插头',
    'word' => '转换插头',
    'hits' => 0,
    'score' => 0,
  ),
  2802 => 
  array (
    '_id' => '转角书桌',
    'word' => '转角书桌',
    'hits' => 0,
    'score' => 0,
  ),
  2803 => 
  array (
    '_id' => '转托管',
    'word' => '转托管',
    'hits' => 0,
    'score' => 0,
  ),
  2804 => 
  array (
    '_id' => '装潢效果图',
    'word' => '装潢效果图',
    'hits' => 0,
    'score' => 0,
  ),
  2805 => 
  array (
    '_id' => '装饰材料',
    'word' => '装饰材料',
    'hits' => 0,
    'score' => 0,
  ),
  2806 => 
  array (
    '_id' => '装饰柜',
    'word' => '装饰柜',
    'hits' => 0,
    'score' => 0,
  ),
  2807 => 
  array (
    '_id' => '装饰品',
    'word' => '装饰品',
    'hits' => 0,
    'score' => 0,
  ),
  2808 => 
  array (
    '_id' => '装饰设计',
    'word' => '装饰设计',
    'hits' => 0,
    'score' => 0,
  ),
  2809 => 
  array (
    '_id' => '装饰装修',
    'word' => '装饰装修',
    'hits' => 0,
    'score' => 0,
  ),
  2810 => 
  array (
    '_id' => '装修步骤',
    'word' => '装修步骤',
    'hits' => 0,
    'score' => 0,
  ),
  2811 => 
  array (
    '_id' => '装修步骤和流程',
    'word' => '装修步骤和流程',
    'hits' => 0,
    'score' => 0,
  ),
  2812 => 
  array (
    '_id' => '装修材料',
    'word' => '装修材料',
    'hits' => 0,
    'score' => 0,
  ),
  2813 => 
  array (
    '_id' => '装修材料壁纸大全',
    'word' => '装修材料壁纸大全',
    'hits' => 0,
    'score' => 0,
  ),
  2814 => 
  array (
    '_id' => '装修的步骤',
    'word' => '装修的步骤',
    'hits' => 0,
    'score' => 0,
  ),
  2815 => 
  array (
    '_id' => '装修多久入住',
    'word' => '装修多久入住',
    'hits' => 0,
    'score' => 0,
  ),
  2816 => 
  array (
    '_id' => '装修房子的步骤',
    'word' => '装修房子的步骤',
    'hits' => 0,
    'score' => 0,
  ),
  2817 => 
  array (
    '_id' => '装修风格大全',
    'word' => '装修风格大全',
    'hits' => 0,
    'score' => 0,
  ),
  2818 => 
  array (
    '_id' => '装修风格选择',
    'word' => '装修风格选择',
    'hits' => 0,
    'score' => 0,
  ),
  2819 => 
  array (
    '_id' => '装修风水',
    'word' => '装修风水',
    'hits' => 0,
    'score' => 0,
  ),
  2820 => 
  array (
    '_id' => '装修风水知识',
    'word' => '装修风水知识',
    'hits' => 0,
    'score' => 0,
  ),
  2821 => 
  array (
    '_id' => '装修风水注意事项',
    'word' => '装修风水注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  2822 => 
  array (
    '_id' => '装修公司起名',
    'word' => '装修公司起名',
    'hits' => 0,
    'score' => 0,
  ),
  2823 => 
  array (
    '_id' => '装修合同模板',
    'word' => '装修合同模板',
    'hits' => 0,
    'score' => 0,
  ),
  2824 => 
  array (
    '_id' => '装修后放什么植物好',
    'word' => '装修后放什么植物好',
    'hits' => 0,
    'score' => 0,
  ),
  2825 => 
  array (
    '_id' => '装修监理',
    'word' => '装修监理',
    'hits' => 0,
    'score' => 0,
  ),
  2826 => 
  array (
    '_id' => '装修流程',
    'word' => '装修流程',
    'hits' => 0,
    'score' => 0,
  ),
  2827 => 
  array (
    '_id' => '装修门的选择',
    'word' => '装修门的选择',
    'hits' => 0,
    'score' => 0,
  ),
  2828 => 
  array (
    '_id' => '装修木工价格表',
    'word' => '装修木工价格表',
    'hits' => 0,
    'score' => 0,
  ),
  2829 => 
  array (
    '_id' => '装修墙面颜色',
    'word' => '装修墙面颜色',
    'hits' => 0,
    'score' => 0,
  ),
  2830 => 
  array (
    '_id' => '装修墙纸',
    'word' => '装修墙纸',
    'hits' => 0,
    'score' => 0,
  ),
  2831 => 
  array (
    '_id' => '装修全包好还是半包好',
    'word' => '装修全包好还是半包好',
    'hits' => 0,
    'score' => 0,
  ),
  2832 => 
  array (
    '_id' => '装修污染危害与解决',
    'word' => '装修污染危害与解决',
    'hits' => 0,
    'score' => 0,
  ),
  2833 => 
  array (
    '_id' => '装修验收标准',
    'word' => '装修验收标准',
    'hits' => 0,
    'score' => 0,
  ),
  2834 => 
  array (
    '_id' => '装修预算',
    'word' => '装修预算',
    'hits' => 0,
    'score' => 0,
  ),
  2835 => 
  array (
    '_id' => '装修预算表',
    'word' => '装修预算表',
    'hits' => 0,
    'score' => 0,
  ),
  2836 => 
  array (
    '_id' => '装修状况',
    'word' => '装修状况',
    'hits' => 0,
    'score' => 0,
  ),
  2837 => 
  array (
    '_id' => '准现房',
    'word' => '准现房',
    'hits' => 0,
    'score' => 0,
  ),
  2838 => 
  array (
    '_id' => '资阳公积金贷款',
    'word' => '资阳公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2839 => 
  array (
    '_id' => '资阳住房公积金提取',
    'word' => '资阳住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2840 => 
  array (
    '_id' => '自动伸缩门',
    'word' => '自动伸缩门',
    'hits' => 0,
    'score' => 0,
  ),
  2841 => 
  array (
    '_id' => '自动旋转门',
    'word' => '自动旋转门',
    'hits' => 0,
    'score' => 0,
  ),
  2842 => 
  array (
    '_id' => '自发热地板',
    'word' => '自发热地板',
    'hits' => 0,
    'score' => 0,
  ),
  2843 => 
  array (
    '_id' => '自贡公积金贷款',
    'word' => '自贡公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2844 => 
  array (
    '_id' => '自贡住房公积金提取',
    'word' => '自贡住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2845 => 
  array (
    '_id' => '自管房产',
    'word' => '自管房产',
    'hits' => 0,
    'score' => 0,
  ),
  2846 => 
  array (
    '_id' => '自然梦山棕床垫',
    'word' => '自然梦山棕床垫',
    'hits' => 0,
    'score' => 0,
  ),
  2847 => 
  array (
    '_id' => '自热地板',
    'word' => '自热地板',
    'hits' => 0,
    'score' => 0,
  ),
  2848 => 
  array (
    '_id' => '自住商品房',
    'word' => '自住商品房',
    'hits' => 0,
    'score' => 0,
  ),
  2849 => 
  array (
    '_id' => '自住型商品房',
    'word' => '自住型商品房',
    'hits' => 0,
    'score' => 0,
  ),
  2850 => 
  array (
    '_id' => '宗地',
    'word' => '宗地',
    'hits' => 0,
    'score' => 0,
  ),
  2851 => 
  array (
    '_id' => '宗匠家具',
    'word' => '宗匠家具',
    'hits' => 0,
    'score' => 0,
  ),
  2852 => 
  array (
    '_id' => '走廊',
    'word' => '走廊',
    'hits' => 0,
    'score' => 0,
  ),
  2853 => 
  array (
    '_id' => '走廊吊顶',
    'word' => '走廊吊顶',
    'hits' => 0,
    'score' => 0,
  ),
  2854 => 
  array (
    '_id' => '租房公积金提取',
    'word' => '租房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2855 => 
  array (
    '_id' => '租房合同注意事项',
    'word' => '租房合同注意事项',
    'hits' => 0,
    'score' => 0,
  ),
  2856 => 
  array (
    '_id' => '租房纠纷',
    'word' => '租房纠纷',
    'hits' => 0,
    'score' => 0,
  ),
  2857 => 
  array (
    '_id' => '租房中介',
    'word' => '租房中介',
    'hits' => 0,
    'score' => 0,
  ),
  2858 => 
  array (
    '_id' => '租金',
    'word' => '租金',
    'hits' => 0,
    'score' => 0,
  ),
  2859 => 
  array (
    '_id' => '租赁合同印花税',
    'word' => '租赁合同印花税',
    'hits' => 0,
    'score' => 0,
  ),
  2860 => 
  array (
    '_id' => '租售比',
    'word' => '租售比',
    'hits' => 0,
    'score' => 0,
  ),
  2861 => 
  array (
    '_id' => '组合贷款',
    'word' => '组合贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2862 => 
  array (
    '_id' => '组合家具',
    'word' => '组合家具',
    'hits' => 0,
    'score' => 0,
  ),
  2863 => 
  array (
    '_id' => '最高价',
    'word' => '最高价',
    'hits' => 0,
    'score' => 0,
  ),
  2864 => 
  array (
    '_id' => '最新贷款利率',
    'word' => '最新贷款利率',
    'hits' => 0,
    'score' => 0,
  ),
  2865 => 
  array (
    '_id' => '最新婚姻法房产分配',
    'word' => '最新婚姻法房产分配',
    'hits' => 0,
    'score' => 0,
  ),
  2866 => 
  array (
    '_id' => '最新商品房预售管理',
    'word' => '最新商品房预售管理',
    'hits' => 0,
    'score' => 0,
  ),
  2867 => 
  array (
    '_id' => '最优物业回报率',
    'word' => '最优物业回报率',
    'hits' => 0,
    'score' => 0,
  ),
  2868 => 
  array (
    '_id' => '最优租金',
    'word' => '最优租金',
    'hits' => 0,
    'score' => 0,
  ),
  2869 => 
  array (
    '_id' => '遵义公积金贷款',
    'word' => '遵义公积金贷款',
    'hits' => 0,
    'score' => 0,
  ),
  2870 => 
  array (
    '_id' => '遵义住房公积金提取',
    'word' => '遵义住房公积金提取',
    'hits' => 0,
    'score' => 0,
  ),
  2871 => 
  array (
    '_id' => '座向',
    'word' => '座向',
    'hits' => 0,
    'score' => 0,
  ),
);