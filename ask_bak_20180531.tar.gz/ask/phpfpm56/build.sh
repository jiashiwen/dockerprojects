#!/bin/bash

echo ''
echo '# 构建 PHP-fpm Image 5.6'
docker build -t app-phpfpm:5.6 .
echo '.... done!'
echo ''
