<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh">
<head>
	<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, minimal-ui">
<meta name="format-detection" content="telephone=no" />
<meta name="applicable-device" content="mobile">
<title><?php echo ($pageinfo["seo_title"]); ?></title>
<link rel="stylesheet" href="<?php echo (C("ASSETS_ROOT")); ?>/styles/styles.css">

<script type="text/javascript" src="<?php echo (C("ASSETS_ROOT")); ?>/js/index.js"></script>
<script type="text/javascript" src="//res.leju.com/scripts/libs/zepto/v1/zepto.js"></script>
<script type="text/javascript" src="//cdn.leju.com/sso/sso.js"></script>
<?php
if ( ( $p_ctl=='question' && $p_act=='detail' ) || ( $p_ctl=='answer' && in_array($p_act, ['answer', 'edit', ]) ) || ( $p_ctl=='list' && in_array($p_act, ['company', 'person', 'house', 'topic']) ) ) { ?>
<script type="text/javascript" src="//res.bch.leju.com/scripts/app/qawap/v1/house_detail.js"></script>
<?php
} else if ( ( $p_ctl=='answer' && in_array($p_act, ['detail', ]) ) ) { } else if ( ( $p_ctl=='index' && in_array($p_act, ['local_hots', 'topics',]) ) ) { ?>
<script type="text/javascript" src="//res.bch.leju.com/scripts/app/qawap/v1/attent_list.js"></script>
<?php
} else if ( ( $p_ctl=='index' && in_array($p_act, ['favourites', ]) ) ) { ?>
<script type="text/javascript" src="//res.bch.leju.com/scripts/app/qawap/v1/not_attent.js"></script>
<?php
} else { ?>
<script type="text/javascript" src="//res.bch.leju.com/scripts/app/qawap/v1/home.js"></script>
<?php } ?>

</head>
<body>
	<div class="scrollBox zwt_bodycolor">
		<!-- 页面内容 -->
		<!-- 页头 -->
<?php
 ?>
<?php
$imsgs = ''; if ( intval($current_userinfo['i_updated']) > 0 ) { $imsgs = intval($current_userinfo['i_updated']); } if ( ( $p_ctl=='index' && in_array($p_act, ['map', ]) ) ) { } else if ( ( $p_ctl=='index' && in_array($p_act, ['local_hots', 'topics', ]) ) || ( $p_ctl=='list' && in_array($p_act, ['topic', 'house', 'company', 'person', ]) ) || ( $p_ctl=='question' && in_array($p_act, ['detail', ]) ) || ( $p_ctl=='answer' && in_array($p_act, ['detail', 'answer', 'edit', ]) ) || ( $p_ctl=='ask' && in_array($p_act, ['', 'index', ]) ) ) { ?>
<div class="y_top">
    <div class="y_back" onclick="history.back()"></div>
    <div class="y_txt"><img src="<?php echo (C("ASSETS_ROOT")); ?>/images/y_txt.png"></div>
    <div class="y_icBox">
        <i class="ic01"></i>
        <i class="ic02"><em><?php echo ($imsgs); ?></em></i>
    </div>
</div>
<?php
} else { ?>
<div class="y_top">
    <div class="y_logo"><img src="<?php echo (C("ASSETS_ROOT")); ?>/images/leju.png"></div>
    <div class="y_txt"><img src="<?php echo (C("ASSETS_ROOT")); ?>/images/y_txt.png"></div>
    <div class="y_icBox">
        <i class="ic01"></i>
        <i class="ic02"><em><?php echo ($imsgs); ?></em></i>
    </div>
    <!-- <div class="y_City">北京</div> -->
</div>
<!-- 导航 -->
<div class="zwt_dhnav">
    <div class="zwt_homepage_nav">
        <ul>
            <li<?php if ($column=='favourites' ) { echo ' class="zwt_on2"'; } ?>><a href="<?php echo url('Favourites');?>" data-column="favourites">关注</a></li>
            <li<?php if ($column=='recommends' ) { echo ' class="zwt_on2"'; } ?>><a href="<?php echo url('Recommends');?>" data-column="recommends">推荐</a></li>
            <li<?php if (substr($column, 0, 5)=='local' ) { echo ' class="zwt_on2"'; } ?>><a href="<?php echo url('Local');?>" data-column="local">本地买房</a></li>
            <li<?php if ($column=='companies' ) { echo ' class="zwt_on2"'; } ?>><a href="<?php echo url('Companies');?>" data-column="companies">地产公司</a></li>
            <li<?php if ($column=='persons' ) { echo ' class="zwt_on2"'; } ?>><a href="<?php echo url('Persons');?>" data-column="persons">地产人物</a></li>
            <li<?php if ($column=='decorates' ) { echo ' class="zwt_on2"'; } ?>><a href="<?php echo url('Decorates');?>" data-column="decorates">家居装修</a></li>
            <li<?php if ($column=='overseas' ) { echo ' class="zwt_on2"'; } ?>><a href="<?php echo url('Overseas');?>" data-column="overseas">海外置业</a></li>
        </ul>
    </div>
</div>
<div id="nav-sub-column" class="zwt_homepage_fxstyle<?php if (substr($column, 0, 5)!='local' ) { echo ' none'; } ?>">
    <span class="zwt_homepage_city"><?php echo ($current_city["cn"]); ?></span>
    <ul class="zwt_homepage_ul clearfix">
            <a href="<?php echo url('CateHouse');?>" data-column="local_house">
            <li> <i class="zwt_homeicon1"></i> <span>买新房</span> </li>
            </a>
            <a href="<?php echo url('Cate2Hands');?>" data-column="local_2hands">
            <li> <i class="zwt_homeicon2"></i> <span>买二手房</span> </li>
            </a>
            <a href="<?php echo url('Houses');?>" data-column="local_hots">
            <li> <i class="zwt_homeicon3"></i> <span>热议楼盘</span> </li>
            </a>
    </ul>
</div>

<?php } ?>


		<!-- 页面内容 -->
		<div class="y_list01 zwt_list">
	<ul id="list" class="changetabhtml" data-column="<?php echo ($column); ?>"
		data-page="<?php echo ($pager["page"]); ?>" data-size="<?php echo ($pager["size"]); ?>"
		data-total="<?php echo ($pager["total"]); ?>" data-count="<?php echo ($pager["count"]); ?>"
		data-next="<?php echo (intval($pager["next"])); ?>">

		<?php if ( $pager['page']==1 ) { ?>
		<!--
		<div class="zwt_groom_header">
			<div class="zwt_groom_tit clearfix">
				<h2>热门话题</h2>
				<a href="/index/topics" data-column="topics">更多</a>
			</div>
			<div class="zwt_groom_ullb">
				<ul>
				<?php foreach ( $topics as $i => $topic ) { ?>
					<li>
						<img src="<?php echo $topic['extra']['images'][0]; ?>" alt="<?php echo ($topic["title"]); ?>">
						<div class="zwt_groomrt">
							<h2><a href="#<?php echo ($topic["id"]); ?>">#<?php echo ($topic["title"]); ?>#</a><?php echo ($topic["extra"]["desc"]); ?></h2>
						</div>
					</li>
				<?php } ?>
				</ul>
			</div>
		</div>
		-->

		<?php if ( $vips ) { ?>
		<!--
		<div class="zwt_groom_askfor">
			<div class="zwt_groom_askft clearfix">
				<h2>向TA提问</h2>
				<a href="#">更多</a>
			</div>
			<ul>
				<li>
					<i class="zwt_close"></i>
					<div class="zwt_groom_img"><a href="#"><img src="<?php echo (C("ASSETS_ROOT")); ?>/images/temp/zwt_01.jpg" alt=""></a><i></i></div>
					<h2>张一鸣</h2>
					<p>今日头条创始人CEO</p>
					<div class="zwt_groom_askjt clearfix">
						<span>¥35</span>
						<em>|</em>
						<span>提问</span>
					</div>
				</li>
			</ul>
		</div>
		-->
		<?php } ?>

		<?php if ( $recommends ) { ?>
		<div class="zwt_jxtitle"><h2>精选问答</h2></div>
		<?php
foreach ( $recommends as $i => $item ) { if ( $item['answer']['ispay']==1 && $item['user']['ispaid']==0 ) { ?>
        <!-- 需要付费才能查看 <?php echo ($item["object_type"]); ?> -->
<li>
<?php if ( $attentionbar && $item['object']['type']>0 ) { ?>
    <div class="t2">
        <a href="/List/<?php echo ($item["object"]["type_string"]); ?>/?id=<?php echo ($item["object"]["relid"]); ?>">
        <img src="<?php echo ($item["object"]["logo"]); ?>"><?php echo ($item["object"]["name"]); ?>
        </a>
    </div>
<?php } ?>
	<div class="t1"><a href="<?php echo '#'.$item['question']['id']; ?>">
    <?php if ( in_array($current_city['cn'], $item['question']['city']) ) { echo '<em>本地</em> '; } echo $item['question']['title']; ?>
	</a></div>
	<div class="btnBox">
		<a>¥1学习一下</a>
	</div>
	<dl class="y_inf">
        <?php if ( $item['user']['gooded'] ) { ?>
        <dd class="cur zen" data-id="<?php echo ($item["answer"]["id"]); ?>"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
        <?php } else { ?>
        <dd class="zen" data-id="<?php echo ($item["answer"]["id"]); ?>"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
        <?php } ?>
		<dd><i class="ic1"></i><?php echo ((isset($item["answer"]["comments"]) && ($item["answer"]["comments"] !== ""))?($item["answer"]["comments"]):0); ?></dd>
        <?php if ( $item['user']['faved'] ) { ?>
        <dd class="cur fav" data-id="<?php echo ($item["question"]["id"]); ?>"><i class="ic2"></i>已关注</dd>
        <?php } else { ?>
        <dd class="fav" data-id="<?php echo ($item["question"]["id"]); ?>"><i class="ic2"></i>关注问题</dd>
        <?php } ?>
	</dl>
<?php
if ( $attentionbar && $item['object']['type']>0 ) { if ( $item['user']['attent'] ) { ?>
    <div class="cur attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">已关注</div>
<?php } else { ?>
    <div class="attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">关注</div>
<?php
 } } ?>
</li>

        <?php
 } else { if ( isset($item['question']['images']) && count($item['question']['images'])>0 ) { $image_count = count($item['question']['images']); if ( $image_count > 0 && $image_count < 3 ) { ?>
                <!-- 单张图片 <?php echo ($item["object_type"]); ?> -->
<li>
<?php if ( $attentionbar && $item['object']['type']>0 ) { ?>
    <div class="t2">
        <a href="/List/<?php echo ($item["object"]["type_string"]); ?>/?id=<?php echo ($item["object"]["relid"]); ?>">
        <img src="<?php echo ($item["object"]["logo"]); ?>"><?php echo ($item["object"]["name"]); ?>
        </a>
    </div>
<?php } ?>
	<div class="y_Rimg mr15 mrt30"><img src="<?php echo $item['question']['images'][0]; ?>"></div>
	<div class="min mr15">
		<div class="t1"><a href="<?php echo $item['url']; ?>">
        <?php if ( in_array($current_city['cn'], $item['question']['city']) ) { echo '<em>本地</em> '; } echo $item['question']['title']; ?>
		</a></div>
        <?php if ( $item['answer'] ) { ?>
        <div class="t3" data-desc="<?php echo htmlentities($item['answer']['reply'], ENT_QUOTES | ENT_IGNORE, 'UTF-8');?>"><?php echo mystrcut($item['answer']['reply'], 20, '…'); ?></div>
        <?php } else { } ?>
	</div>
	<dl class="y_inf">
		<?php if ( $item['user']['gooded'] ) { ?>
		<dd class="cur zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } else { ?>
		<dd class="zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } ?>
		<dd><i class="ic1"></i><?php echo ((isset($item["answer"]["comments"]) && ($item["answer"]["comments"] !== ""))?($item["answer"]["comments"]):0); ?></dd>
		<?php if ( $item['user']['faved'] ) { ?>
		<dd class="cur fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>已关注</dd>
		<?php } else { ?>
		<dd class="fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>关注问题</dd>
		<?php } ?>
	</dl>
<?php
if ( $attentionbar && $item['object']['type']>0 ) { if ( $item['user']['attent'] ) { ?>
    <div class="cur attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">已关注</div>
<?php } else { ?>
    <div class="attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">关注</div>
<?php
 } } ?>
</li>

                <?php
 } if ( $image_count >= 3 ) { ?>
                <!-- 三张图片 <?php echo ($item["object_type"]); ?> -->
<li>
<?php if ( $attentionbar && $item['object']['type']>0 ) { ?>
    <div class="t2">
        <a href="/List/<?php echo ($item["object"]["type_string"]); ?>/?id=<?php echo ($item["object"]["relid"]); ?>">
        <img src="<?php echo ($item["object"]["logo"]); ?>"><?php echo ($item["object"]["name"]); ?>
        </a>
    </div>
<?php } ?>
	<div class="t1"><a href="<?php echo $item['url']; ?>">
	<?php if ( in_array($current_city['cn'], $item['question']['city']) ) { echo '<em>本地</em> '; } echo ($item["question"]["title"]); ?>
	</a></div>
    <?php if ( $item['answer'] ) { ?>
	<div class="t3" data-desc="<?php echo htmlentities($item['answer']['reply'], ENT_QUOTES | ENT_IGNORE, 'UTF-8');?>"><?php echo mystrcut($item['answer']['reply'], 20, '…'); ?></div>
    <?php } else { } ?>
	<dl class="y_imglist">
		<?php foreach ( $item['question']['images'] as $i => $image ) { if ( $i>=3 ) break; ?>
		<dd><img src="<?php echo ($image); ?>"></dd>
		<?php } ?>
	</dl>
	<dl class="y_inf">
		<?php if ( $item['user']['gooded'] ) { ?>
		<dd class="cur zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } else { ?>
		<dd class="zan"data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } ?>
		<dd><i class="ic1"></i><?php echo ((isset($item["answer"]["comments"]) && ($item["answer"]["comments"] !== ""))?($item["answer"]["comments"]):0); ?></dd>
		<?php if ( $item['user']['faved'] ) { ?>
		<dd class="cur fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>已关注</dd>
		<?php } else { ?>
		<dd class="fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>关注问题</dd>
		<?php } ?>
	</dl>
<?php
if ( $attentionbar && $item['object']['type']>0 ) { if ( $item['user']['attent'] ) { ?>
    <div class="cur attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">已关注</div>
<?php } else { ?>
    <div class="attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">关注</div>
<?php
 } } ?>
</li>

                <?php
 } } else { ?>
            <!-- 没有图片 <?php echo ($item["object_type"]); ?> -->
<li>
<?php if ( $attentionbar && $item['object']['type']>0 ) { ?>
    <div class="t2">
        <a href="/List/<?php echo ($item["object"]["type_string"]); ?>/?id=<?php echo ($item["object"]["relid"]); ?>">
        <img src="<?php echo ($item["object"]["logo"]); ?>"><?php echo ($item["object"]["name"]); ?>
        </a>
    </div>
<?php } ?>
	<div class="t1"><a href="<?php echo $item['url']; ?>">
	<?php if ( $item['question']['city']==$current_city['en'] ) { echo '<em>本地</em> '; } echo ($item["question"]["title"]); ?>
	</a></div>
    <?php if ( $item['answer'] ) { ?>
    <div class="t3" data-desc="<?php echo htmlentities($item['answer']['reply'], ENT_QUOTES | ENT_IGNORE, 'UTF-8');?>"><?php echo mystrcut($item['answer']['reply'], 20, '…'); ?></div>
    <?php } else { } ?>
    <dl class="y_inf">
		<?php if ( $item['user']['gooded'] ) { ?>
		<dd class="cur zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } else { ?>
		<dd class="zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } ?>
		<dd><i class="ic1"></i><?php echo ((isset($item["answer"]["comments"]) && ($item["answer"]["comments"] !== ""))?($item["answer"]["comments"]):0); ?></dd>
		<?php if ( $item['user']['faved'] ) { ?>
		<dd class="cur fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>已关注</dd>
		<?php } else { ?>
		<dd class="fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>关注问题</dd>
		<?php } ?>
	</dl>
<?php
if ( $attentionbar && $item['object']['type']>0 ) { if ( $item['user']['attent'] ) { ?>
    <div class="cur attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">已关注</div>
<?php } else { ?>
    <div class="attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">关注</div>
<?php
 } } ?>
</li>

            <?php
 } } } ?>

		<?php } ?>

		<?php } ?>
		<!-- 这是列表 -->
		<?php
foreach ( $list as $i => $item ) { if ( $item['answer']['ispay']==1 && $item['user']['ispaid']==0 ) { ?>
        <!-- 需要付费才能查看 <?php echo ($item["object_type"]); ?> -->
<li>
<?php if ( $attentionbar && $item['object']['type']>0 ) { ?>
    <div class="t2">
        <a href="/List/<?php echo ($item["object"]["type_string"]); ?>/?id=<?php echo ($item["object"]["relid"]); ?>">
        <img src="<?php echo ($item["object"]["logo"]); ?>"><?php echo ($item["object"]["name"]); ?>
        </a>
    </div>
<?php } ?>
	<div class="t1"><a href="<?php echo '#'.$item['question']['id']; ?>">
    <?php if ( in_array($current_city['cn'], $item['question']['city']) ) { echo '<em>本地</em> '; } echo $item['question']['title']; ?>
	</a></div>
	<div class="btnBox">
		<a>¥1学习一下</a>
	</div>
	<dl class="y_inf">
        <?php if ( $item['user']['gooded'] ) { ?>
        <dd class="cur zen" data-id="<?php echo ($item["answer"]["id"]); ?>"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
        <?php } else { ?>
        <dd class="zen" data-id="<?php echo ($item["answer"]["id"]); ?>"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
        <?php } ?>
		<dd><i class="ic1"></i><?php echo ((isset($item["answer"]["comments"]) && ($item["answer"]["comments"] !== ""))?($item["answer"]["comments"]):0); ?></dd>
        <?php if ( $item['user']['faved'] ) { ?>
        <dd class="cur fav" data-id="<?php echo ($item["question"]["id"]); ?>"><i class="ic2"></i>已关注</dd>
        <?php } else { ?>
        <dd class="fav" data-id="<?php echo ($item["question"]["id"]); ?>"><i class="ic2"></i>关注问题</dd>
        <?php } ?>
	</dl>
<?php
if ( $attentionbar && $item['object']['type']>0 ) { if ( $item['user']['attent'] ) { ?>
    <div class="cur attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">已关注</div>
<?php } else { ?>
    <div class="attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">关注</div>
<?php
 } } ?>
</li>

        <?php
 } else { if ( isset($item['question']['images']) && count($item['question']['images'])>0 ) { $image_count = count($item['question']['images']); if ( $image_count > 0 && $image_count < 3 ) { ?>
                <!-- 单张图片 <?php echo ($item["object_type"]); ?> -->
<li>
<?php if ( $attentionbar && $item['object']['type']>0 ) { ?>
    <div class="t2">
        <a href="/List/<?php echo ($item["object"]["type_string"]); ?>/?id=<?php echo ($item["object"]["relid"]); ?>">
        <img src="<?php echo ($item["object"]["logo"]); ?>"><?php echo ($item["object"]["name"]); ?>
        </a>
    </div>
<?php } ?>
	<div class="y_Rimg mr15 mrt30"><img src="<?php echo $item['question']['images'][0]; ?>"></div>
	<div class="min mr15">
		<div class="t1"><a href="<?php echo $item['url']; ?>">
        <?php if ( in_array($current_city['cn'], $item['question']['city']) ) { echo '<em>本地</em> '; } echo $item['question']['title']; ?>
		</a></div>
        <?php if ( $item['answer'] ) { ?>
        <div class="t3" data-desc="<?php echo htmlentities($item['answer']['reply'], ENT_QUOTES | ENT_IGNORE, 'UTF-8');?>"><?php echo mystrcut($item['answer']['reply'], 20, '…'); ?></div>
        <?php } else { } ?>
	</div>
	<dl class="y_inf">
		<?php if ( $item['user']['gooded'] ) { ?>
		<dd class="cur zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } else { ?>
		<dd class="zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } ?>
		<dd><i class="ic1"></i><?php echo ((isset($item["answer"]["comments"]) && ($item["answer"]["comments"] !== ""))?($item["answer"]["comments"]):0); ?></dd>
		<?php if ( $item['user']['faved'] ) { ?>
		<dd class="cur fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>已关注</dd>
		<?php } else { ?>
		<dd class="fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>关注问题</dd>
		<?php } ?>
	</dl>
<?php
if ( $attentionbar && $item['object']['type']>0 ) { if ( $item['user']['attent'] ) { ?>
    <div class="cur attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">已关注</div>
<?php } else { ?>
    <div class="attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">关注</div>
<?php
 } } ?>
</li>

                <?php
 } if ( $image_count >= 3 ) { ?>
                <!-- 三张图片 <?php echo ($item["object_type"]); ?> -->
<li>
<?php if ( $attentionbar && $item['object']['type']>0 ) { ?>
    <div class="t2">
        <a href="/List/<?php echo ($item["object"]["type_string"]); ?>/?id=<?php echo ($item["object"]["relid"]); ?>">
        <img src="<?php echo ($item["object"]["logo"]); ?>"><?php echo ($item["object"]["name"]); ?>
        </a>
    </div>
<?php } ?>
	<div class="t1"><a href="<?php echo $item['url']; ?>">
	<?php if ( in_array($current_city['cn'], $item['question']['city']) ) { echo '<em>本地</em> '; } echo ($item["question"]["title"]); ?>
	</a></div>
    <?php if ( $item['answer'] ) { ?>
	<div class="t3" data-desc="<?php echo htmlentities($item['answer']['reply'], ENT_QUOTES | ENT_IGNORE, 'UTF-8');?>"><?php echo mystrcut($item['answer']['reply'], 20, '…'); ?></div>
    <?php } else { } ?>
	<dl class="y_imglist">
		<?php foreach ( $item['question']['images'] as $i => $image ) { if ( $i>=3 ) break; ?>
		<dd><img src="<?php echo ($image); ?>"></dd>
		<?php } ?>
	</dl>
	<dl class="y_inf">
		<?php if ( $item['user']['gooded'] ) { ?>
		<dd class="cur zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } else { ?>
		<dd class="zan"data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } ?>
		<dd><i class="ic1"></i><?php echo ((isset($item["answer"]["comments"]) && ($item["answer"]["comments"] !== ""))?($item["answer"]["comments"]):0); ?></dd>
		<?php if ( $item['user']['faved'] ) { ?>
		<dd class="cur fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>已关注</dd>
		<?php } else { ?>
		<dd class="fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>关注问题</dd>
		<?php } ?>
	</dl>
<?php
if ( $attentionbar && $item['object']['type']>0 ) { if ( $item['user']['attent'] ) { ?>
    <div class="cur attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">已关注</div>
<?php } else { ?>
    <div class="attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">关注</div>
<?php
 } } ?>
</li>

                <?php
 } } else { ?>
            <!-- 没有图片 <?php echo ($item["object_type"]); ?> -->
<li>
<?php if ( $attentionbar && $item['object']['type']>0 ) { ?>
    <div class="t2">
        <a href="/List/<?php echo ($item["object"]["type_string"]); ?>/?id=<?php echo ($item["object"]["relid"]); ?>">
        <img src="<?php echo ($item["object"]["logo"]); ?>"><?php echo ($item["object"]["name"]); ?>
        </a>
    </div>
<?php } ?>
	<div class="t1"><a href="<?php echo $item['url']; ?>">
	<?php if ( $item['question']['city']==$current_city['en'] ) { echo '<em>本地</em> '; } echo ($item["question"]["title"]); ?>
	</a></div>
    <?php if ( $item['answer'] ) { ?>
    <div class="t3" data-desc="<?php echo htmlentities($item['answer']['reply'], ENT_QUOTES | ENT_IGNORE, 'UTF-8');?>"><?php echo mystrcut($item['answer']['reply'], 20, '…'); ?></div>
    <?php } else { } ?>
    <dl class="y_inf">
		<?php if ( $item['user']['gooded'] ) { ?>
		<dd class="cur zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } else { ?>
		<dd class="zan" data-id="<?php echo ((isset($item["answer"]["id"]) && ($item["answer"]["id"] !== ""))?($item["answer"]["id"]):0); ?>" data-api="good"><i class="ic0"></i><?php echo ((isset($item["answer"]["agrees"]) && ($item["answer"]["agrees"] !== ""))?($item["answer"]["agrees"]):0); ?></dd>
		<?php } ?>
		<dd><i class="ic1"></i><?php echo ((isset($item["answer"]["comments"]) && ($item["answer"]["comments"] !== ""))?($item["answer"]["comments"]):0); ?></dd>
		<?php if ( $item['user']['faved'] ) { ?>
		<dd class="cur fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>已关注</dd>
		<?php } else { ?>
		<dd class="fav" data-id="<?php echo ((isset($item["question"]["id"]) && ($item["question"]["id"] !== ""))?($item["question"]["id"]):0); ?>" data-api="favq"><i class="ic2"></i>关注问题</dd>
		<?php } ?>
	</dl>
<?php
if ( $attentionbar && $item['object']['type']>0 ) { if ( $item['user']['attent'] ) { ?>
    <div class="cur attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">已关注</div>
<?php } else { ?>
    <div class="attent atten" data-id="<?php echo ($item["object"]["relid"]); ?>" data-type="<?php echo ($item["object"]["type_string"]); ?>">关注</div>
<?php
 } } ?>
</li>

            <?php
 } } } ?>


		<li class="pd0<?php
 if ( $pager['next']==false || $pager['count']==0 ) { echo ' none'; } ?>" id="js_getmore" data-column="<?php echo ($column); ?>" data-next="<?php echo (intval($pager["next"])); ?>"
		data-page="<?php echo ($pager["page"]); ?>" data-size="<?php echo ($pager["size"]); ?>"
		data-total="<?php echo ($pager["total"]); ?>" data-count="<?php echo ($pager["count"]); ?>">
			<div class="y_more01">查看更多</div>
		</li>
	</ul>
</div>

	</div>
	<!-- 所有的弹层放在 scrollBox外面 -->
	<!-- 这是搜索浮层 -->
<div class="b_searchWrapper none">
	<div class="b_searchBox cur">
		<form id="search_form" action="<?php echo url('Search',['keyword'=>false]);?>" method="get" target="_blank">
			<div class="b_inpBox">
				<input type="search" name="keyword" placeholder="请输入问题名称和用户">
				<a href="#" class="search"><i></i></a>
				<a href="#" class="del"></a>
			</div>
		</form>
		<a href="#" class="close"></a>
	</div>
	<div class="b_infoBox">
		<h2>热门搜索</h2>
		<div class="label zwt_label">
		<?php foreach ( $search_ranks as $i => $house ) { ?>
			<a href="/list/house/?id=<?php echo ($house["hid"]); ?>"><?php echo ($house["title"]); ?></a>
		<?php } ?>
		</div>
	</div>
	<b class="b_border"></b>
	<div class="b_infoBox">
		<h2 class="history">搜索历史<a href="#">清空</a></h2>
		<ul class="b_list001"></ul>
	</div>
</div>

	<?php
if ( ( $p_ctl=='index' && in_array($p_act, ['local_hots', 'topics', 'favourites', 'getrecommendobjects', 'test']) ) || ( $p_ctl=='ask' && in_array($p_act, ['index', ]) ) || ( $p_ctl=='answer' && in_array($p_act, ['answer', 'edit', 'detail']) ) || ( $p_ctl=='question' && in_array($p_act, ['detail', ]) ) || $disallow_ask ) { } else { ?>
<a href="/ask/" class="zwt_toask"></a>
<?php } ?>

	<?php
if ( ( $show_feed_attent===true && $p_ctl=='index' && in_array($p_act, ['index', 'favourites', 'test', ]) ) ) { ?>
<a href="" class="zwt_submit zwt_sure">确定</a>
<?php } ?>

	<?php
if ( ( $p_ctl=='question' && in_array($p_act, ['detail']) ) ) { ?>
<div class="h90"></div>
<ul class="y_tools">
    <?php
 $cover = isset($question['extra']['images'][0]) ? $question['extra']['images'][0] : ''; $share = [ 'url' => 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'], 'img' => $cover, 'title' => $question['title'], 'desc' => trim($question['extra']['desc']), ]; ?>
	<li class="share-btn" data-lejushare='<?php echo json_encode($share); ?>'>
		<i class="ic01"></i> <h2>分享问题</h2>
	</li>
	<li>
		<i class="ic02"></i>
		<h2><a href="/answer/answer?questionid=<?php echo ($question["id"]); ?>">添加回答</a></h2>
	</li>
	<?php if ( $question['_flags']['faved'] ) { ?>
	<li class="fav bottom" data-id="<?php echo ((isset($question["id"]) && ($question["id"] !== ""))?($question["id"]):0); ?>" data-api="favq"><i class="ic03 "></i><h2>已关注</h2></li>
	<?php } else { ?>
	<li class="fav bottom" data-id="<?php echo ((isset($question["id"]) && ($question["id"] !== ""))?($question["id"]):0); ?>" data-api="favq"><i class="ic03"></i><h2>关注问题</h2></li>
	<?php } ?>
</ul>
<?php } ?>

	<?php
if ( ( $p_ctl=='answer' && in_array($p_act, ['detail']) ) ) { if ( $recommends ) { ?>
<!-- 推荐阅读 -->
<div class="y_list01">
	<h3 class="g_title01">推荐阅读</h3>
	<ul>
		<li>
			<div class="t1"><a href=""><span>万达</span>楼盘怎么样？</a></div>
			<div class="t3">觉得是社交软件中的撤回功能，撤回消息之后会有一个提示，你撤回了一条信息，一直觉得很蠢啊有木有，撤回就干干净净的撤回嘛，为什么非得要加…</div>
			<dl class="y_imglist">
				<dd><img src="images/temp/2.png"></dd>
				<dd><img src="images/temp/2.png"></dd>
				<dd><img src="images/temp/2.png"></dd>
			</dl>
			<div class="y_userTell">
				<div class="m1"><img src="images/temp/2.png">手机用户64313398981</div>
				<div class="m2">20回答<em>丨</em>65关注</div>
			</div>

		</li>
		<li>
			<div class="t1"><a href=""><em>精华</em>万达楼盘怎么样？万达楼盘怎么样？万达楼盘怎么样？万么</a></div>
			<div class="y_Rimg"><img src="images/temp/2.png"></div>
			<div class="t3">觉得是社交软件中的撤回功能，撤回消息之后会有一个提示，你撤回了一条信息，一直觉得很蠢啊有木有，撤回就干干净净的撤回嘛，为什么非得要加…</div>

			<div class="y_userTell">
				<div class="m1"><img src="images/temp/2.png">手机用户64313398981</div>
				<div class="m2">20回答<em>丨</em>65关注</div>
			</div>
		</li>
		<li>
			<div class="t1"><a href=""><span>万达</span>楼盘怎么样？</a></div>
			<div class="t3">影响房价的因素有不少，城市地位提升、产业经济发展各种利好配套等都是诱因。</div>

			<div class="y_userTell">
				<div class="m1"><img src="images/temp/2.png">手机用户64313398981</div>
				<div class="m2">20回答<em>丨</em>65关注</div>
			</div>

		</li>


	</ul>
</div>
<?php
 } } ?>

	<?php
if ( ( $p_ctl=='answer' && in_array($p_act, ['detail']) ) ) { ?>
<ul class="y_tools">
	<li class="zan" data-id="<?php echo ($answer["id"]); ?>" data-type="answer">
		<i class="ic05"></i> <h2>赞同 <?php echo ((isset($answer["i_goods"]) && ($answer["i_goods"] !== ""))?($answer["i_goods"]):0); ?></h2>
	</li>
	<li data-url="<?php echo ($nexturl); ?>">
        <a href="<?php echo ($nexturl); ?>">
    		<i class="ic06"></i> <h2>下个回答</h2>
        </a>
	</li>
    <?php
 $cover = isset($answer['extra']['images'][0]) ? $answer['extra']['images'][0] : ''; $share = [ 'url' => $answer['url'], 'img' => $cover, 'title' => $question['title'], 'desc' => trim($answer['reply']), ]; ?>
	<li class="share-btn" data-lejushare='<?php echo json_encode($share); ?>'>
		<i class="ic01"></i>
		<h2>分享问题</h2>
	</li>
</ul>
<?php } ?>

</body>
</html>