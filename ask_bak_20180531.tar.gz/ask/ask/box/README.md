# 镜像构造

## Nginx

Nginx 版本
  1.12 => @/nginx

## PHP-fpm

PHP-fpm 版本:
  5.6 => @/phpfpm56
  7.1 => @/phpfpm71
