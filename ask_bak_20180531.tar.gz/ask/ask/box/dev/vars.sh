#!/bin/bash

if [ -z $ROOTDIR ];then
    export ROOTDIR="/Volumes/Data/docker/leju/ask"
fi
