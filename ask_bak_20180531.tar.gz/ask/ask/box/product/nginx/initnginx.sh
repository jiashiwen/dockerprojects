#!/bin/sh
# 初始化 Nginx 运行时环境
# 更新虚拟主机配置
`rm -f /etc/nginx/conf.d/*.conf && cp /config/conf.d/*.conf /etc/nginx/conf.d/`
# 更新虚拟主机的环境变量配置
`cat /config/fastcgi_params >> /etc/nginx/fastcgi_params`
# 启动 Nginx 服务
`/usr/sbin/nginx -g "daemon off;"`
