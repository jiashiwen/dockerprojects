
## Web服务器部署

将 ask 的代码部署在 10.204.12.{21,22,23} 三台主机上
通过 Docker 进行部署
默认 每台主机启动 1*Nginx + 3*PHP-Fpm


## 域名及主机

1. 域名解析
- `ask.leju.com` 不能做域名解析，之前的老的问答还在线支持财经touch端，在需要的服务器上进行 Hosts 绑定 或其它逻辑处理
- `admin.ask.leju.com` 域名解析至 10.204.12.{21,22,23} 三台主机上 或 独立部署也可以


2. 反向代理 [可选项]

3. 前台业务绑定触屏二级页面入口

部署时需要在 m.leju.com 域配置以下内容
可以联系赵航

```
location ^~ /ask/ {
    proxy_pass http://ask.leju.com/;
    proxy_set_header My-Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
}
```


## 数据库使用运维提供的主从 MySQL 数据库

必要时可以联系赵航

host :
10.204.11.85        m3438.yz.askleju.grid.house.sina.com.cn
10.204.11.87        s3438.yz.askleju.grid.house.sina.com.cn
mysql Master: m3438.yz.askleju.grid.house.sina.com.cn
mysql Slave:  s3438.yz.askleju.grid.house.sina.com.cn
database: ask_leju_com
user: askleju
passwd: OIHsfaUfDferiq
port: 3438


## 缓存服务使用运维提供的双主 Redis 缓存

必要时可以联系赵航

hosts :
10.204.14.189        m7587.yz.askleju.grid.house.sina.com.cn
redis host: m7587.yz.askleju.grid.house.sina.com.cn
redis port: 7587
密码认证：无
分配空间4G，缓存过期策略LRU



## 敏感词服务配置

必要时可以联系 常利伟

地址:10.204.12.21, 10.204.12.22, 10.204.12.23
端口:8110
用户名/密码:dev/123456


## 脚本入口

以下初始化，在部署之后，仅需执行一次即可，且 `导入问答垫底数据` 依赖 `初始化伪用户` 的操作。

- [初始化伪用户](http://admin.ask.leju.com/Utils/importFakeMembers)
- [导入问答垫底数据](http://admin.ask.leju.com/Utils/initBaseQuestions)

## 外部

### 从新闻池同步楼盘、百科中的地产公司和地产人物数据

- [启动从新闻池同步客体数据的脚本](http://admin.ask.leju.com/Utils/syncObjects)
    - 参数
        - type string 要同步的数据类型 company=>地产公司 person=>地产人物 house=>楼盘, 必填，且为前面三个值中的一个
        - page = int 页码, 必填
        - pagesize = int 每页信息数 建议使用 1000, 必填
    - 返回
        int 当前同步的数据量，当这个值为0时，说明已经同步完成

### 乐道问答数据导入接口

- [启动从乐道同步至新问答的脚本](http://ask.leju.com/api/syncFromLedao)
    - 参数
        - page = int 页码, 必填
        - pagesize = int 每页信息数, 必填
        - after = date_str 可以设置信息起始时间，为空时同步全量，不空为时，为设置的时间字符串对应的时间之后的数据 格式 2018-09-30(Y-m-d)

### 乐道方提供的读取接口

由 `启动从乐道同步至新问答的脚本` 接口自动调用，这里提出仅供参考

- [导入地产公司问答](http://api.baike.leju.com/read/company/?page=1&pagesize=5)
- [导入地产人物问答](http://api.baike.leju.com/read/person/?page=1&pagesize=5)
