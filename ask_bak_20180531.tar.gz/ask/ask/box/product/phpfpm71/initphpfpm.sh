#!/bin/sh
# 初始化 PHP-fpm 运行时环境

# 更新 php-fpm 进程配置信息
`rm -f /usr/local/etc/php-fpm.conf && cp /config/php71/php-fpm.conf /usr/local/etc/php-fpm.conf`
# 启动 php-fpm 服务
`/usr/local/sbin/php-fpm -c /config/php71/php.ini`
