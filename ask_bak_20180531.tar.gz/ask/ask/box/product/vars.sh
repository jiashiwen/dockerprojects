#!/bin/bash

if [ -z $ROOTDIR ];then
    export ROOTDIR="{TODO MODIFY}"
fi
