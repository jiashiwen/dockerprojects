#!/bin/bash

export ROOTDIR="/data/vhosts/test-ask"
