
# 数据库字典


#### 问题数据表

```
CREATE TABLE `questions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '问题编号',
  `source` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '来源 0乐居问答入口',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '问题的状态 0开启 1关闭',
  `title` varchar(100) NOT NULL COMMENT '问题标题',
  `city` varchar(20) NOT NULL DEFAULT '' COMMENT '问题所属城市',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '问答业务数据创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '问答业务数据的更新时间',
  `userid` bigint(20) NOT NULL COMMENT '提问者用户编号',
  `is_anonymous` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否匿名提问 0未匿名 1匿名',
  `is_paid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否付费提问 0非付费 1待付费 2已付费',
  `i_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总访问数量',
  `i_favors` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '总关注数据',
  `i_answers` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '总问题数',
  `is_company` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否是公司问答 不是为0，大于0表示问题相关的公司个数',
  `is_person` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否是人物问答 不是为0，大于0表示问题相关的人物个数',
  `is_house` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否是楼盘问答 不是为0，大于0表示问题相关的楼盘个数',
  `recommend_answer`
  `extra` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '扩展数据',
  PRIMARY KEY (`id`),
  KEY `INX_STATUS` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='问题数据表';
```

DICT status

`可见` : 并存在于新闻池、搜索引擎等业务(可同步)
`不可见` : 即新闻池、搜索引擎等业务清除，或置删除态为真

- `0`   正常态 问题可见
- `99`  删除态 问题不可见
- `11`  需审核 问题不可见


扩展字段说明

```
questions.extra 包括
json:{
    'desc': string, // 问题的详细描述
    'usernick': string, // 提问者用户昵称
    'avatar': string, // 提问者用户头像
    'images': [string], // 提问时上传的图片 最多3张
    'video': string, // 提问时上传的视频
    'tags': [{'tag':string,'id':int}], // 问题关联的标签，用于展示，在更新问题时对其进行更新
    'objects': [{'type':int, 'id':int}], // 存储客体关联关系
    'sensitive': [{'word': string禁词, 'reason': string禁词类别}], // 如果识别出敏感词，就将敏感词保存起来
}
```

Indeces Questions
_id => id
_title => title
_content => content
_deleted => status!=0
_tags => tag.id[]
_scope => city[]
_multi =>

_answers


Indeces Tags

_id => tag.id
_title => tag.name
_cate => 普通 公司 人物 楼盘 话题


map to cache
question_count 有效问题数量
answer_count 有效回答数量
favor_count 收藏数量


#### 问题与客体关联数据表

场景，前台使用
ZSET


CREATE TABLE `object_question_mapping` (
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '客体类型',
  `objectid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '客体编号',
  `questionid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '问题编号',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '客体与问题绑定时间',
  PRIMARY KEY (`id`, `objectid`, `questionid`),
  KEY `INX_QUESTION_OBJECTS` (`questionid`, `type`, `objectid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='问题与客体关联关系表';

查找与客体关联 objectid 的问题列表
select * from object_question_mapping om
inner join questions q
on om.questionid = q.id and q.status = ( ? )
where
o.type = '?' and o.objectid = '?'
and q.city in ( ? )

#### 问题与标签关联数据表

CREATE TABLE `tag_question_mapping` (
  `tagid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '标签编号',
  `questionid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '问题编号',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '标签与问题绑定时间',
  PRIMARY KEY (`tagid`, `questionid`),
  KEY `INX_QUESTION_OBJECTS` (`questionid`, `tagid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='标签与客体关联关系表';


查找一组tagid的问题列表
select * from tag_question_mapping tm
inner join questions q
on tm.questionid = q.id and q.status = ( ? )
where
tm.tagid in ( ? )
and q.city in ( ? )



#### 问题回答数据表

```
DROP TABLE IF EXISTS `answers`;
CREATE TABLE IF NOT EXISTS `answers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '回答编号',
  `questionid` int(10) unsigned DEFAULT NULL COMMENT '问题编号 FK(questions.id)',
  `userid` bigint(20) NOT NULL DEFAULT '0' COMMENT '回答的用户编号',
  `ctime` int(10) unsigned NOT NULL COMMENT '回答时间',
  `status` tinyint(3) unsigned DEFAULT '0' COMMENT '回答状态 0正常 1未审核(不显示) 9已删除(不显示)',
  `is_anonymous` tinyint(3) unsigned DEFAULT '0' COMMENT '是否匿名回答 1匿名 0未匿名',
  `is_invite` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '是否是邀请回答 1付费 0非付费',
  `i_favors` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '总关注数据',
  `i_agrees` smallint(5) unsigned DEFAULT '0' COMMENT '赞同数量',
  `i_comments` smallint(5) unsigned DEFAULT '0' COMMENT '评论数量',
  `i_speed` tinyint(3) unsigned DEFAULT '0' COMMENT '回答速度得分',
  `f_quality` smallint(5) unsigned DEFAULT '0' COMMENT '质量平均分',
  `f_score` float unsigned NOT NULL DEFAULT '0' COMMENT '综合评分',
  `extra` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '扩展数据',
  PRIMARY KEY (`id`),
  KEY `FK_QUESTIONID` (`questionid`),
  KEY `INX_STATUS` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='问题回答数据表';
```

扩展字段说明

```
answers.extra 包括
json:{
    'reply': string, // 回答的内容 限制在1000字以内
    'usernick': string, // 回答者用户昵称
    'avatar': string, // 回答者用户头像
    'images': [string], // 回答时上传的图片 最多3张
    'video': string, // 回答时上传的视频
    'comment': string, // 提问者对付费回答的评价内容
}
```


#### 问答业务类型数据表


```
CREATE TABLE `question_objects` (
  `id` int(10) unsigned NOT NULL COMMENT '业务类型编号',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '业务类别字典编号',
  `relid` varchar(50) NOT NULL COMMENT '业务数据的原始编号',
  `title` varchar(30) NOT NULL COMMENT '业务数据原始名称',
  `city` varchar(20) NOT NULL DEFAULT '' COMMENT '业务数据所属城市',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '问答业务数据创建时间',
  `otime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '问答业务数据的开启时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '问答业务数据的更新时间',
  `i_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总访问数量',
  `i_favors` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总关注数据',
  `i_questions` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总问题数',
  `i_answers` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总回答数',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '业务数据的状态 0关闭 1开启',
  PRIMARY KEY (`id`),
  KEY `UNQ_OBJECTID` (`type`, `relid`),
  KEY `INX_STATUS` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='问答业务类型数据表';
```


#### 记录问题相关的回答和绑定的信息(新闻/文章)

用例：
问题详情页，用于显示问题相关的信息流
数据类型包括有效的回复和绑定的新闻


CREATE TABLE `question_feeds` (
  `questionid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '问题编号',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '信息类别 0为回答 1为新闻',
  `relid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '信息编号',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联时间',
  PRIMARY KEY (`questionid`, `type`, `relid` ),
  KEY `INX_TIME` ( `questionid`, `ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='问题信息流';



#### 问答业务使用的乐居标签库中定义的标签

CREATE TABLE `infos_tags` (
  `id` bigint(20) unsigned NOT NULL COMMENT '标签编号',
  `tag` varchar(50) NOT NULL COMMENT '标签名称',
  `cid` bigint(20) unsigned NOT NULL COMMENT '标签分类编号',
  `cate` varchar(50) NOT NULL COMMENT '标签分类名称',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '标签更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '标签状态 0为可用 1为不可用',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNI_TAG` (`tag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='问答业务使用的乐居标签';



#### 问答业务使用的乐居新闻

CREATE TABLE `infos_news` (
  `id` bigint(20) unsigned NOT NULL COMMENT '新闻编号',
  `source` tinyint(3) unsigned NOT NULL COMMENT '新闻来源',
  `title` varchar(250) NOT NULL COMMENT '新闻标题名称',
  `cover` varchar(250) NOT NULL COMMENT '新闻配图',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '新闻更新时间',
  `rel_questions` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '新闻关联的问题编号',
  PRIMARY KEY (`id`),
  KEY `INX_NEWS` (`utime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='问答业务使用的乐居标签';


#### 话题数据表

```
CREATE TABLE `topics` (
  `id` int(10) unsigned NOT NULL COMMENT '话题编号',
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT '话题标题',
  `city` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_' COMMENT '话题所属城市 city_en, _为全国',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '话题创建时间',
  `utime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '话题最后更新时间',
  `status` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '话题的状态 0开启 1关闭 9删除',
  `allow_comment` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '话题是否允许评论 0不允许 1允许',
  `i_questions` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '总问题数量',
  `i_answers` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总回答数量',
  `i_comments` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '总评论数量',
  `i_attents` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT '总关注数量',
  `i_hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '总访问数量',
  `extra` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '扩展数据',
  PRIMARY KEY (`id`),
  KEY `INX_STATUS` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='话题数据表';
```

扩展字段说明

```
topics.extra 包括
{
  content : 话题内容<string>,
  images: 话题图片<string|[]>,
  video: 话题的视频<string|{}>,
  creator : {opid: 管理员编号<int>, truename:管理员姓名<string> },
  operator: [
    { opid: 管理员编号<int>, act: 操作<int>, time: 操作时间<int,timestamp> },
  ]
}
```

#### 话题问答关联数据表

```
CREATE TABLE `topic_rels` (
  `topicid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '话题编号',
  `relid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '关联编号',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '1' COMMENT '与话题关联的类型 0保留 1问题 2回答',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '与话题关联的时间',
  PRIMARY KEY (`topicid`, `type`, `relid`),
  KEY `INX_RELTOPIC` (`type`, `relid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='话题问答关联数据表';
```


topicqas
话题与问答关联信息表

type 0 1问题 2回答
topicid 话题编号
relid 关联数据编号
ctime 关联数据创建时间


index 定义
- topic, type, relid 联合索引为主键
- topic, type, ctime 用于用例1
- type, relid 用于用例2

插入数据时，如果数据已经存在，更新 ctime
ON DUPLICATE KEY UPDATE ctime = ?


查询用例

1. 通过话题查找相关问答

select * from topic_rels where topicid = ? [ and type = ? ]

2. 通过问答反向查找已关联的话题

select * from topic_rels where type = ? and relid = ?



#### 问答操作日志表

```
CREATE TABLE `oplogs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '操作日志编号',
  `act` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '操作类型 0:ask 1:answer 2:fav 3:good 4:comment 5:evaluate',
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '操作者即会员用户编号',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '客体类型 1:topic 101:company 102:person 103:house',
  `relid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '客体编号',
  `question_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作对应的问题编号',
  `answer_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作对应的回答编号',
  `comment_id` int(20) unsigned NOT NULL DEFAULT '0' COMMENT '操作对应的评论、评价编号',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='问答业务操作日志表';
```
1	0	0	1	10001	99	0	0	77
2	1	87	101	10101	100	1001	0	88
#### 用户关注操作日志表

```
CREATE TABLE `member_attents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '关注日志编号',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '客体类型 1:topic 2:question 200:member 101:company 102:person 103:house',
  `relid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '客体编号',
  `userid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '操作者即会员用户编号',
  `ctime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '操作时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户关注操作日志表';
```

1	1	100	86	37
2	1	101	87	40
3	101	10101	86	33
4	101	10102	86	33
5	102	10201	86	34
6	103	10301	86	35

select * from (
select oplogs.act, oplogs.type, oplogs.question_id, oplogs.answer_id, oplogs.comment_id, oplogs.ctime
from oplogs
inner join member_attents
on oplogs.type = member_attents.type and oplogs.relid = member_attents.relid
where member_attents.userid=86 and oplogs.ctime > 30
) attent_t

union all

select * from (
select oplogs.act, '2', oplogs.question_id, oplogs.answer_id, oplogs.comment_id, oplogs.ctime
from oplogs
inner join member_attents
on member_attents.type = 2 and oplogs.question_id = member_attents.relid
where member_attents.userid=86 and oplogs.ctime > 30
) attent_q

union all

select * from (
select oplogs.act, '3', oplogs.question_id, oplogs.answer_id, oplogs.comment_id, oplogs.ctime
from oplogs
inner join member_attents
on member_attents.type = 200 and oplogs.userid = member_attents.relid
where member_attents.userid=86 and oplogs.ctime > 30
) attent_m

order by ctime



