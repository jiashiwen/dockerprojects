# 说明

### 乐居内部第三方服务参考

- [标签管理系统API`<文档>`](http://10.207.25.249:4000/)
- [支付系统`<文档>`](http://partner.paycenter.leju.com/doc/)


### 基本规划

- 入口
  - [前台入口](http://ask.leju.com/)
  - [前台入口](http://m.leju.com/ask/)
  - [后台入口](http://admin.ask.leju.com/)

#### 关于前台 SEO Url 规则的邮件及确认


```
tianwei1@leju.com
2018/1/5 10:55
各位 好

经过讨论，也考虑倒以后https切换的问题，建议新版问答触屏页面的url规则如下：
页面类型	触屏URL
首页	m.leju.com/ask/
列表页	m.leju.com/ask/list{cateid}{-page}/
楼盘详情页/话题详情页	m.leju.com/ask/topic/{tagid}{-page}/
问题详情页（默认排序）	m.leju.com/ask/list{cateid}/{问题id}.html
问题详情页（排序）	m.leju.com/ask/list{cateid}/{问题id}/hot.html
回答详情页	m.leju.com/ask/list{cateid}/{id}/{回答id}.html
我的相关页面	m.leju.com/ask/people/{分类id}
```
0. [ ] 域名使用m.leju.com
  1. [ ] 乐居移动触屏服务是否支持接入？找谁？
  2. [ ] sitemap 如何处理？在 /ask/目录下提交相应的xml文件吗？还是要推送到域根下？
1. [ ] 提问页地址不需要地址规则？
2. [ ] 分类列表页地址？
3. [ ] 楼盘详情页/话题详情页 是同一个东西？？
4. [ ] 搜索页面？



### 核心架构参考

- [MVC框架继续采用 ThinkPHP 3.2.3](http://document.thinkphp.cn/manual_3_2.html)
- [模版采用 WRAPKIT v1.0](https://gridgum.com/themes/wrapkit-responsive-admin-template/)
- [USTC blog 强制对 Google 字体加速](https://servers.ustclug.org/2014/07/ustc-blog-force-google-fonts-proxy/)
- [靠谱的国内前端CDN公共库（替代GoogleAPIs的加速节点）](http://www.xxsay.com/archives/678)
- [图标索引](http://fontawesome.io/icons/)


### 参考资料收集

- [flot 图表控件](http://www.flotcharts.org/flot/examples/) [API](https://github.com/flot/flot/blob/master/API.md)

- [PHP SD : SwooleDistributed](http://sd.youwoxing.net/)
- [Yaf](http://www.laruence.com/manual/)

- [跨域资源共享 CORS 详解](http://www.ruanyifeng.com/blog/2016/04/cors.html)
- [Chart.js 中文文档](http://www.bootcss.com/p/chart.js/docs/)
