# ask_feed API 文档

标签（空格分隔）： REST API 文档

---

## 问答日志增删
#### Request
- Method: **POST**
- URL:  ```/api/v1/feed/optaskoptlog```
- Params
  - opt 操作方法 add | delete
  |    参数    | 必填 |参考值|描述|
| ---------- | --- | --- | --- |
| opt |  true |add;delete|操作标识，新增或删除|
|_id       |  true ||索引文档id|
- Headers：
  - Content-Type:application/json
- Body:
```
{
"act": "操作类型 0:ask 1:answer 2:fav 3:good 4:comment 5:evaluate"
"userid": "操作者即会员用户编号"
"type_relid": "该字段为拼接字段，前后两部分分别为 type 客体类型 1:topic 101:company  102:person 103:house relid 客体编号"
"question_id": "操作对应的问题编号"
"answer_id": "操作对应的回答编号"
"comment_id": "操作对应的评论、评价编号"
"ctime": "操作时间"
}
```


#### Response
- Body
```
{
    "index": "ask_oplogs",
    "type": "oplogs",
    "version": 1,
    "status": true
}

```

## 关注日志增删
#### Request
- Method: **POST**
- URL:  ```/api/v1/feed/optmemberattents```
- Params
  - opt 操作方法 add | delete
  |    参数    | 必填 |参考值|描述|
| ---------- | --- | --- | --- |
| opt |  true |add;delete|操作标识，新增或删除|
|_id       |  true ||索引文档id|
- Headers：
  - Content-Type:application/json
- Body:
```
{
"userid": "操作者即会员用户编号"
"type_relid": "该字段为拼接字段，前后两部分分别为 type 客体类型 1:topic 101:company  102:person 103:house relid 客体编号"
"ctime": "操作时间"
}
```


#### Response
- Body
```
{
    "index": "member_attents",
    "type": "member_attents",
    "version": 7,
    "status": true
}

```

## 根据userid查询关注标签
#### Request
- Method: **POST**
- URL:  ```/api/v1/feed/getuserfavflagsbyuserid```
- Params
  - opt 操作方法 add | delete
  |    参数    | 必填 |参考值|描述|
| ---------- | --- | --- | --- |
| userid |  true ||用户id|
- Headers：
  - Content-Type:application/json
- Body:

#### Response
- Body
```
{
    "type": "getuserfavflagsbyuserid",
    "status": "SUCCESS",
    "keywords": null,
    "business": null,
    "cost": 0,
    "total": 4,
    "result": [
        {
            "_index": "member_attents",
            "_type": "member_attents",
            "_id": "id_7",
            "_source": {
                "type_relid": "topic_123",
                "ctime": 1522166400011,
                "userid": "66666"
            }
        },
        {
            "_index": "member_attents",
            "_type": "member_attents",
            "_id": "id_8",
            "_source": {
                "type_relid": "answer_123",
                "ctime": 1522166400011,
                "userid": "66666"
            }
        }
    ]
}

```

## 关注日志增删
#### Request
- Method: **POST**
- URL:  ```/api/v1/feed/optmemberattents```
- Params
  - opt 操作方法 add | delete
  |    参数    | 必填 |参考值|描述|
| ---------- | --- | --- | --- |
| opt |  true |add;delete|操作标识，新增或删除|
|_id       |  true ||索引文档id|
- Headers：
  - Content-Type:application/json
- Body:
```
{
"userid": "操作者即会员用户编号"
"type_relid": "该字段为拼接字段，前后两部分分别为 type 客体类型 1:topic 101:company  102:person 103:house relid 客体编号"
"ctime": "操作时间"
}
```


#### Response
- Body
```
{
    "index": "member_attents",
    "type": "member_attents",
    "version": 7,
    "status": true
}

```

## 通过userid获取关注内容的id
#### Request
- Method: **POST**
- URL:  ```/api/v1/feed/getuserfavbyuserid```
- Params
- Headers：
  - Content-Type:application/json
- Body:
```
{
	"gte":1522166400001, #大于等于某日期，epoch_millis
	"lte":"now", #小于等于某时间点，epoch_millis，"now"为当前时间
	"from":0,#页码起始记录
	"size":20,#页码长度
	"userid":"66666"#用户id
}
```


#### Response
- Body
```
{
    "type": "getuserfavflagsbyuserid",
    "status": "SUCCESS",
    "keywords": null,
    "business": null,
    "cost": 0,
    "total": 2,
    "result": [
        {
            "_index": "ask_oplogs",
            "_type": "oplogs",
            "_id": "id_4",
            "_source": {
                "act": "answer",
                "type_relid": "answer_123",
                "ctime": 1522166400001,
                "answer_id": "123",
                "userid": "456"
            }
        },
        {
            "_index": "ask_oplogs",
            "_type": "oplogs",
            "_id": "id_1",
            "_source": {
                "act": "ask",
                "type_relid": "topic_123",
                "ctime": 1522166400000,
                "question_id": "123",
                "userid": "456"
            }
        }
    ]
}

```

