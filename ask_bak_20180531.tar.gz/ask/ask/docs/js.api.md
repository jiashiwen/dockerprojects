# 前端交互 API 接口说明

## 页面显示

### 栏目列表标识

1. 首页 或 关注 : `favourites`
2. 推荐 : `recommends`
3. 买新房 : `local_house`
4. 买二手房 : `local_2hands`
5. 热议楼盘 :`local_hots`
6. 地产公司 : `companies`
7. 地产人物 : `persons`
8. 家居装修 : `decorates`
9. 海外置业 : `overseas`
10. 话题列表 : `topics`

### 栏目入口

/index/栏目列表标识

比如话题列表入口 即为 `/index/topics`

### 首页和各栏目列表页入口 (下面的将忽略域名)

#### 1. 直接打开页面的方法

1. 首页 或 关注 : /
2. 推荐 : /index/recommends
3. 本地买房 : 无链接，只做展现效果处理，即显示 #nav-sub-column
    3.1 买新房 : /index/local_house
    3.2 买二手房 : /index/local_2hands
    3.3 热议楼盘 : /index/local_hots
4. 地产公司 : /index/companies
5. 地产人物 : /index/persons
6. 家居装修 : /index/decorates
7. 海外置业 : /index/overseas

#### 2. 通过 ajax 加载 `(推荐)`

- 接口 : `/index/loadmore`
- 参数 :
    - column : 栏目代码 必填
        - 首页 或 关注 : favourites
        - 推荐 : recommends
        - 买新房 : local_house
        - 买二手房 : local_2hands
        - 热议楼盘 : local_hots
        - 地产公司 : companies
        - 地产人物 : persons
        - 家居装修 : decorates
        - 海外置业 : overseas
    - page : 页码 *选填* 默认为1
    - pagesize : 每页加载数量 *选填* 默认为10
- 返回结构 :
```
{
    "status":true, // 结果正常
    "pager":{ // 当页分页信息
        "page":2,   // 当前页码
        "pagesize":10,  // 每页信息数量
        "pagecount":3,  // 总页数
        "pagenext":true // 是否还有下一页
    },
    "column":"favourites", // 当前栏目
    "html":"" // 后台渲染好的，可用于显示的html代码片断
}
```
- 备注：

**我在导航中添加了两种 javascript 调用 `@2018-03-12 by Robert`**

- 调用1 : showlist() 直接用于调用 ajax 加载功能(发生ajax请求)
- 调用2 : subcolumns() 用于动态显示本地买房的二级栏目功能(不发生ajax请求)



## 通用接口

>   注意 : 通用接口中，成功后返回的消息是 msg 字段；失败后的文本消息是 reason 字段。

#### * 对一组问答进行点赞操作接口 (点赞针对回答)

- 接口地址 : `/api/good`
- 参数 :
    - id : 待点赞的回答编号
    - direct :
        - 0: 取消点赞
        - 1: 点赞(默认)
- 结果 :
    - 成功时
```
{
    "status":true,
    "msg":"取消点赞/点赞成功",
    "info":{
        "id": <int>, // 被点赞的回答编号
        "good": <int> // 点赞后的总点赞数
    }
}
```
    - 错误或失败时
```
{
    "status":false,
    "reason":"请先登录" // 操作用户未登录的情况
    "reason":"请指定被点赞的回答编号" // 接口调用时，未指定正确的待点赞的回复编号
    "reason":"您已经点过赞了" // 重复点赞的情况
}
```

#### * 对一组问答进行收藏操作接口 (关注或收藏，针对问题)

- 接口地址 : `/api/fav`
- 参数 :
    - id : 待关注的编号
    - type: 关注的类型
        - question 关注问题(收藏问题)
        - answer 关注回答(收藏问题)
    - direct :
        - 0: 取消关注
        - 1: 关注(默认)
- 结果 :
    - 成功时
```
{
    "status":true,
    "msg":"取消关注/关注操作成功",
    "info":{
        "id": <int>, // 被关注的问题编号
        "direct": <int> // 操作方向标志，同参数中的 direct 0为取消关注 1为关注
    }
}
```
- 错误或失败时
```
{
    "status":false,
    "reason":"请先登录" // 操作用户未登录的情况
    "reason":"请指定待关注的问题编号" // 接口调用时，未指定正确的待关注的问题编号
    "reason":"您已经关注过了" // 重复点赞的情况
}
```


#### * 对问答客体(用户、人物、公司、楼盘、话题等)进行关注操作接口

- 接口地址 : `/api/attent`
- 参数 :
    - type : 待关注的类型 (必传)
        - user 用户
        - company 公司
        - person 人物
        - house 楼盘
        - topic 话题
    - id : 待关注的客体编号
    - direct :
        - 0: 取消关注
        - 1: 关注(默认)
- 结果 :
    - 成功时
```
{
    "status":true,
    "msg":"取消关注/关注{类型}操作成功",
    "info":{
        "id": <int>, // 被关注的客体编号
        "type": <str>, // 被关注的客体类型
        "direct": <int> // 操作方向标志，同参数中的 direct 0为取消关注 1为关注
    }
}
```
- 错误或失败时
```
{
    "status":false,
    "reason":"请先登录" // 操作用户未登录的情况
    "reason":"请指定关注的类型" // 没有指定 type 参数，需要强制指定关注类型
    "reason":"请指定待关注的{类型}编号" // 接口调用时，未指定正确的待关注的问题编号
    "reason":"您已经关注过了" // 重复关注的情况
    "reason":"您还没有关注过{类型}" // 重复关注的情况
}
```



#### * 评论成功后调用

    对回答或话题进行评论成功后，由前端发起消息通知，以便于及时更新相关数据的评论数量

- 接口地址 : `/api/comment`
- 参数 :
    - type : 待关注的类型 (必传)
        - answer 回答
        - topic 话题
    - id : 数据编号
- 结果 :
    - 成功时
```
{
    "status": true,
    "msg": "评论同步成功"
}
```
- 错误或失败时
```
{
    "status":false,
    "reason":"请先登录" // 操作用户未登录的情况
    "reason":"请指定有效评论对象类别" // 没有指定 type 参数，需要强制指定评论数据类型
    "reason":"请指定数据编号，评论失败" // 接口调用时，未指定 id 参数
    "reason":"请指定有效的回答，评论失败" // type=answer 时的id不是有效回答数据编号
    "reason":"请指定有效的话题，评论失败" // type=topic 时的id不是有效话题数据编号
    "reason":"您还没有关注过{类型}" // 重复关注的情况
}
```


#### * 提问接口

- 接口地址 : `/ask/save`
- 参数 :
    - type : 待关注的类型 (必传)
        - vip 用户
        - company 公司
        - person 人物
        - house 楼盘
        - topic 话题
    - id : 待关注的客体编号
    - direct :
        - 0: 取消关注
        - 1: 关注(默认)
- 结果 :
    - 成功时
```
{
    "status":true,
    "msg":"取消关注/关注{类型}操作成功",
    "info":{
        "id": <int>, // 被关注的客体编号
        "type": <str>, // 被关注的客体类型
        "direct": <int> // 操作方向标志，同参数中的 direct 0为取消关注 1为关注
    }
}
```
- 错误或失败时
```
{
    "status":false,
    "reason":"请先登录" // 操作用户未登录的情况
    "reason":"请指定关注的类型" // 没有指定 type 参数，需要强制指定关注类型
    "reason":"请指定待关注的{类型}编号" // 接口调用时，未指定正确的待关注的问题编号
    "reason":"您已经关注过了" // 重复关注的情况
    "reason":"您还没有关注过{类型}" // 重复关注的情况
}
```
