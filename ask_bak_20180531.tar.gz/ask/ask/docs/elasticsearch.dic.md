# elasticsearch.dic.md

标签（空格分隔）： 未分类

---
### ask_oplogs
#### 描述
问答操作日志索引

#### ask_oplogs索引fields描述
* _id 
  操作日志编号
* act 
  操作类型 0:ask 1:answer 2:fav 3:good 4:comment 5:evaluate
* userid 
  操作者即会员用户编号
* type_relid
  该字段为拼接字段，前后两部分分别为
  type 客体类型 1:topic 101:company 102:person 103:house'
  relid 客体编号
* question_id
  操作对应的问题编号
* answer_id
  操作对应的回答编号
* comment_id
  操作对应的评论、评价编号
* ctime
  操作时间
#### 创建语句
```
PUT ask_oplogs
{
  "mappings": {
    "oplogs": {
      "dynamic": "strict",
      "_all": {
        "enabled": false
      },
      "properties": {
        "act": {
          "type": "text",
          "store": true,
          "analyzer": "whitespace"
        },
        "userid": {
          "type": "keyword"
        },
        "type_relid": {
          "type": "text",
          "store": true,
          "analyzer": "whitespace"
        },
        "question_id": {
          "type": "keyword",
          "store": true
        },
        "answer_id": {
          "type": "keyword",
          "store": true
        },
        "comment_id": {
          "type": "keyword",
          "store": true
        },
        "ctime": {
          "type": "date",
          "store": true,
          "format": "strict_date_optional_time||epoch_millis||yyyy-MM-dd HH:mm:ss"
        }
      }
    }
  },
  "settings": {
    "index": {
      "number_of_shards": "2",
      "requests": {
        "cache": {
          "enable": "true"
        }
      },
      "number_of_replicas": "1"
    }
  }
}
```

---
### member_attents
#### 描述
用户关注操作日志表

#### member_attents索引fields描述
* _id 
  操作日志编号
* type_relid
  该字段为拼接字段，前后两部分分别为
  type 客体类型 1:topic 101:company 102:person 103:house'
* userid 
  操作者即会员用户编号
* ctime
  操作时间

```
PUT member_attents
{
  "mappings": {
    "member_attents": {
      "dynamic": "strict",
      "_all": {
        "enabled": false
      },
      "properties": {
        "userid": {
          "type": "keyword"
        },
        "type_relid": {
          "type": "text",
          "store": true,
          "analyzer": "whitespace"
        },
        "ctime": {
          "type": "date",
          "store": true,
          "format": "strict_date_optional_time||epoch_millis||yyyy-MM-dd HH:mm:ss"
        }
      }
    }
  },
  "settings": {
    "index": {
      "number_of_shards": "2",
      "requests": {
        "cache": {
          "enable": "true"
        }
      },
      "number_of_replicas": "1"
    }
  }
}
```




