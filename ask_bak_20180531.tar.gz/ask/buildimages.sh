#!/bin/sh

cd nginx
sh build.sh
cd ..

cd phpfpm71
sh build.sh
cd ..

cd phpfpm56
sh build.sh
cd ..
