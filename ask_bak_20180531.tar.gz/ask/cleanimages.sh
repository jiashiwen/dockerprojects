#!/bin/sh
# 清理已经构建的镜像
echo '# 清理 Nginx 1.12 镜像 : [app-nginx:1.12]'
docker rmi app-nginx:1.12
echo '.... done!'

echo ''

echo '# 清理 PHP-fpm 7.1 镜像 : [app-phpfpm:7.1]'
docker rmi app-phpfpm:7.1
echo '.... done!'

echo ''

echo '# 清理 PHP-fpm 5.6 镜像 : [app-phpfpm:5.6]'
docker rmi app-phpfpm:5.6
echo '.... done!'

echo ''
